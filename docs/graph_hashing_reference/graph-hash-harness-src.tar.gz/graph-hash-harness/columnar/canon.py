"""canon/v1: a tagged, length-prefixed canonical byte encoding that Python and Rust both produce.

Rules (all integers little-endian):
  0x00 null | 0x01 false | 0x02 true
  0x03 int    : i64, 8 bytes (out of range -> error; widen the schema, don't silently wrap)
  0x04 float  : f64 IEEE-754 bits, 8 bytes; -0.0 -> +0.0; every NaN -> 0x7ff8000000000000
  0x05 string : NFC-normalise, UTF-8, u64 byte length, bytes
  0x06 bytes  : u64 length, raw bytes
  0x07 list   : u64 count, items in order
  0x08 map    : u64 count, entries sorted by NFC-UTF-8 key bytes (bytewise); duplicate keys after NFC -> error
Domain separation: digest = xxh3_128(b"canon/v1\\x00" + encode(value)).
"""
import struct, unicodedata, math
import xxhash

QNAN = 0x7FF8000000000000

def _str_bytes(s: str) -> bytes:
    return unicodedata.normalize("NFC", s).encode("utf-8")

def encode(v, out: bytearray) -> None:
    if v is None: out += b"\x00"
    elif v is False: out += b"\x01"
    elif v is True: out += b"\x02"
    elif isinstance(v, int):
        if not -(1 << 63) <= v < (1 << 63): raise OverflowError(v)
        out += b"\x03" + struct.pack("<q", v)
    elif isinstance(v, float):
        if math.isnan(v): bits = QNAN
        else: bits = struct.unpack("<Q", struct.pack("<d", 0.0 if v == 0.0 else v))[0]
        out += b"\x04" + struct.pack("<Q", bits)
    elif isinstance(v, str):
        b = _str_bytes(v); out += b"\x05" + struct.pack("<Q", len(b)) + b
    elif isinstance(v, (bytes, bytearray, memoryview)):
        b = bytes(v); out += b"\x06" + struct.pack("<Q", len(b)) + b
    elif isinstance(v, (list, tuple)):
        out += b"\x07" + struct.pack("<Q", len(v))
        for x in v: encode(x, out)
    elif isinstance(v, dict):
        items = {}
        for k, x in v.items():
            if not isinstance(k, str): raise TypeError("map keys must be str")
            kb = _str_bytes(k)
            if kb in items: raise ValueError(f"duplicate key after NFC: {k!r}")
            items[kb] = x
        out += b"\x08" + struct.pack("<Q", len(items))
        for kb in sorted(items):
            out += struct.pack("<Q", len(kb)) + kb
            encode(items[kb], out)
    else:
        raise TypeError(type(v))

def canon_bytes(v) -> bytes:
    out = bytearray(b"canon/v1\x00"); encode(v, out); return bytes(out)

def canon_hash(v) -> str:
    return xxhash.xxh3_128_hexdigest(canon_bytes(v))

def merkle_node(payload, child_digests_hex):
    """Ordered Merkle-DAG node: H(tag || canon(payload) || count || child digests as 16 big-endian bytes)."""
    out = bytearray(b"dagnode/v1\x00"); encode(payload, out)
    out += struct.pack("<Q", len(child_digests_hex))
    for h in child_digests_hex: out += bytes.fromhex(h)
    return xxhash.xxh3_128_hexdigest(bytes(out))
