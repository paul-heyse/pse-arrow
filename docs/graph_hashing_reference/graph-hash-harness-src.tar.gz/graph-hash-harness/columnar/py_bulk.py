import os, time, hashlib, xxhash
big = os.urandom(64 << 20)
for name, f in [("xxh3_64", xxhash.xxh3_64_intdigest), ("xxh3_128", xxhash.xxh3_128_intdigest), ("xxh64", xxhash.xxh64_intdigest),
                ("blake2b-16", lambda d: hashlib.blake2b(d, digest_size=16).digest()), ("sha256", lambda d: hashlib.sha256(d).digest())]:
    best = min((lambda: (lambda t: (f(big), time.perf_counter() - t)[1])(time.perf_counter()))() for _ in range(5))
    print(f"{name:10s} best-of-5 {64/1024/best:6.2f} GiB/s")
