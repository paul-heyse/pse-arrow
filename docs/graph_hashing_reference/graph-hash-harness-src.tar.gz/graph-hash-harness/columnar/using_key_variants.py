"""Is USING KEY slow, or was it the recurring.r anti-probe? Chain of 5000 (acyclic, so plain USING KEY terminates in 1.5.x)."""
import time, duckdb, numpy as np
con = duckdb.connect(); con.execute("SET threads=2")
C = 5000
con.execute(f"CREATE TABLE ee AS SELECT range AS src, range + 1 AS dst FROM range({C - 1})")
qs = {
 "UNION (set semantics, dedup hash table)": "WITH RECURSIVE r(node) AS (SELECT 0::BIGINT UNION SELECT ee.dst FROM r JOIN ee ON ee.src=r.node) SELECT count(*) FROM r",
 "UNION ALL (no dedup)": "WITH RECURSIVE r(node) AS (SELECT 0::BIGINT UNION ALL SELECT ee.dst FROM r JOIN ee ON ee.src=r.node) SELECT count(*) FROM r",
 "USING KEY, no recurring.r reference": "WITH RECURSIVE r(node, depth) USING KEY (node) AS (SELECT 0::BIGINT, 0 UNION SELECT ee.dst, r.depth+1 FROM r JOIN ee ON ee.src=r.node) SELECT count(*), max(depth) FROM r",
 "USING KEY + NOT EXISTS recurring.r": "WITH RECURSIVE r(node, depth) USING KEY (node) AS (SELECT 0::BIGINT, 0 UNION SELECT ee.dst, min(r.depth)+1 FROM r JOIN ee ON ee.src=r.node WHERE NOT EXISTS (SELECT 1 FROM recurring.r rr WHERE rr.node=ee.dst) GROUP BY ee.dst) SELECT count(*), max(depth) FROM r",
}
print("duckdb", duckdb.__version__, f"chain of {C} nodes")
for name, q in qs.items():
    t = time.perf_counter(); v = con.execute(q).fetchone(); print(f"  {name:42s} {(time.perf_counter()-t)*1000:9.1f} ms  {v}")
