use unicode_normalization::UnicodeNormalization;
fn main() {
    let s = "\u{105D2}\u{0307}";
    let n: String = s.nfc().collect();
    println!("rust NFC(U+105D2 U+0307) = {:?}", n.chars().map(|c| format!("U+{:X}", c as u32)).collect::<Vec<_>>());
}
