use std::collections::{HashMap,BTreeMap};
fn main(){let ks=["a","b","c","d","e","f","g","h"];let h:HashMap<_,_>=ks.iter().map(|k|(*k,1)).collect();let b:BTreeMap<_,_>=ks.iter().map(|k|(*k,1)).collect();println!("HashMap  {}",serde_json::to_string(&h).unwrap());println!("BTreeMap {}",serde_json::to_string(&b).unwrap());}
