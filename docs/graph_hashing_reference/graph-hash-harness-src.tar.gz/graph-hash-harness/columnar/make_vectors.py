import json, struct, sys
sys.path.insert(0, sys.argv[1])
from canon import canon_hash, canon_bytes, merkle_node
import rfc8785

def wire(v):  # JSON transport for the Rust side; $f64 carries exact bits, $bytes carries raw bytes
    if isinstance(v, float): return {"$f64": struct.pack("<d", v).hex()}
    if isinstance(v, (bytes, bytearray)): return {"$bytes": bytes(v).hex()}
    if isinstance(v, list): return [wire(x) for x in v]
    if isinstance(v, dict): return {k: wire(x) for k, x in v.items()}
    return v

cases = [
    None, True, False, 0, -1, 2**63 - 1, -(2**63), 1.0, 1, 0.1, -0.0, 0.0, float("nan"), float("inf"),
    "", "abc", "café", "café", "\U0001F600", b"\x00\xff", [], {},
    [1, "a", None, [2.5, {"k": b"v"}]],
    {"b": 1, "a": 2, "": 3, "\U0001F600": 4},
    {"node": "pkg:numpy@2.5.3", "deps": ["pkg:python@3.13"], "attrs": {"weight": 0.5, "pinned": True}},
    {"ab": ["c"]}, {"a": ["bc"]},
]
out = []
for c in cases:
    out.append({"value": wire(c), "py_canon_hex": canon_bytes(c).hex(), "py_xxh3_128": canon_hash(c)})
# JCS cross-check (JSON-safe subset only)
jcs_cases = [{"b": 1, "a": [1.0, 0.1, 1e21, 1e-7, -0.0, "café"]}, {"": 1, "\U0001F600": 2}, {"n": 123456789.125, "s": " \""}]
jcs = [{"json": json.dumps(c, ensure_ascii=False), "py_jcs": rfc8785.dumps(c).decode()} for c in jcs_cases]
leaves = [merkle_node({"file": f"f{i}.py", "content_hash": canon_hash(f"body{i}")}, []) for i in range(3)]
root = merkle_node({"dir": "src"}, leaves)
json.dump({"cases": out, "jcs": jcs, "merkle": {"leaves": leaves, "root": root}}, sys.stdout, ensure_ascii=False, indent=0)
