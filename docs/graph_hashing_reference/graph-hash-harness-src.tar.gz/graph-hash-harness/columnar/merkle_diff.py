"""Merkle diff vs deep-equality diff on a 3-level tree (fanout 64 -> 262,144 leaves), one leaf changed."""
import sys, time, copy, struct
sys.path.insert(0, sys.argv[1])
import xxhash
from canon import canon_hash

F = 64
def build():
    return {f"d{i}": {f"s{j}": {f"f{k}": {"size": i * j + k, "body": f"x{i}-{j}-{k}"} for k in range(F)} for j in range(F)} for i in range(F)}

def merkle(tree):
    """Return (digest, children-map) nested structure; leaves hashed via canon/v1, dirs hash sorted (name, child digest)."""
    if "body" in tree:
        return (canon_hash(tree), None)
    kids = {k: merkle(v) for k, v in tree.items()}
    h = xxhash.xxh3_128()
    h.update(b"dir/v1\x00" + struct.pack("<Q", len(kids)))
    for k in sorted(kids):
        kb = k.encode(); h.update(struct.pack("<Q", len(kb)) + kb + bytes.fromhex(kids[k][0]))
    return (h.hexdigest(), kids)

def merkle_diff(a, b, path=(), out=None, visited=None):
    out = [] if out is None else out
    visited[0] += 1
    if a[0] == b[0]: return out
    if a[1] is None or b[1] is None: out.append(path); return out
    for k in a[1].keys() | b[1].keys():
        if k not in a[1] or k not in b[1]: out.append(path + (k,)); continue
        merkle_diff(a[1][k], b[1][k], path + (k,), out, visited)
    return out

def deep_diff(a, b, path=(), out=None, visited=None):
    out = [] if out is None else out
    visited[0] += 1
    if isinstance(a, dict) and isinstance(b, dict) and "body" not in a:
        for k in a.keys() | b.keys():
            if k not in a or k not in b: out.append(path + (k,))
            else: deep_diff(a[k], b[k], path + (k,), out, visited)
    elif a != b: out.append(path)
    return out

t0 = build(); t1 = copy.deepcopy(t0); t1["d7"]["s9"]["f3"]["body"] = "changed"
s = time.perf_counter(); m0 = merkle(t0); t_build = time.perf_counter() - s
m1 = merkle(t1)
v = [0]; s = time.perf_counter(); d = merkle_diff(m0, m1, visited=v); t_md = time.perf_counter() - s
w = [0]; s = time.perf_counter(); dd = deep_diff(t0, t1, visited=w); t_dd = time.perf_counter() - s
print(f"leaves={F**3}  full Merkle build={t_build*1000:.0f} ms (one-off; incremental update rehashes only {3+1} nodes on the path)")
print(f"merkle_diff: {t_md*1e6:.0f} us, nodes visited={v[0]}, diff={d}")
print(f"deep_diff:   {t_dd*1000:.0f} ms, nodes visited={w[0]}, diff={dd}")
print(f"root digests equal? {m0[0]==m1[0]}  (O(1) 'anything changed?' check)")
