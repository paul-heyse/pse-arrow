"""python-xxhash vs hashlib costs, and whether the hash dominates networkx's WL graph hash."""
import time, hashlib, os, sys
import xxhash, networkx as nx
import networkx.algorithms.graph_hashing as gh

def per_call(fn, data, n):
    t = time.perf_counter()
    for _ in range(n): fn(data)
    return (time.perf_counter() - t) / n

small = b"pkg:numpy@2.5.3"            # 15 B
big = os.urandom(64 << 20)            # 64 MiB
print("python", sys.version.split()[0], "xxhash", xxhash.VERSION, "libxxhash", xxhash.XXHASH_VERSION, "networkx", nx.__version__)
rows = [
    ("xxh3_64_intdigest", lambda d: xxhash.xxh3_64_intdigest(d)),
    ("xxh3_128_hexdigest", lambda d: xxhash.xxh3_128_hexdigest(d)),
    ("xxh64_intdigest", lambda d: xxhash.xxh64_intdigest(d)),
    ("blake2b(digest_size=16).hexdigest", lambda d: hashlib.blake2b(d, digest_size=16).hexdigest()),
    ("sha256().hexdigest", lambda d: hashlib.sha256(d).hexdigest()),
    ("builtin hash(bytes)  [salted per process]", lambda d: hash(d)),
]
print(f"{'function':44s} {'15 B ns/call':>14s} {'64 MiB GiB/s':>14s}")
for name, f in rows:
    ns = per_call(f, small, 300_000) * 1e9
    t = time.perf_counter(); f(big); gibs = (64 / 1024) / (time.perf_counter() - t)
    print(f"{name:44s} {ns:14.0f} {gibs:14.2f}")
h = xxhash.xxh3_128(); [h.update(big[i:i + (1 << 16)]) for i in range(0, len(big), 1 << 16)]
assert h.hexdigest() == xxhash.xxh3_128_hexdigest(big)
print("streaming xxh3_128 over 64 KiB chunks == one-shot: OK")

G = nx.gnm_random_graph(20_000, 100_000, seed=7, directed=False)
for n in G: G.nodes[n]["kind"] = "pkg" if n % 3 else "file"
def wl(): return nx.weisfeiler_lehman_graph_hash(G, node_attr="kind", iterations=3)
t = time.perf_counter(); h_b2 = wl(); t_b2 = time.perf_counter() - t
orig = gh._hash_label
gh._hash_label = lambda label, digest_size: xxhash.xxh3_128_hexdigest(label.encode("ascii"))
t = time.perf_counter(); h_x = wl(); t_x = time.perf_counter() - t
gh._hash_label = orig
print(f"WL graph hash, |V|=20000 |E|=100000, 3 iters: blake2b {t_b2*1000:.0f} ms ({h_b2[:12]}..), xxh3_128 patched {t_x*1000:.0f} ms ({h_x[:12]}..)")
