import sys, time, json, struct
sys.path.insert(0, sys.argv[1])
import canon, canon_py
d = json.load(open(sys.argv[1] + "/vectors.json"))
def unwire(v):
    if isinstance(v, dict) and set(v) == {"$f64"}: return struct.unpack("<d", bytes.fromhex(v["$f64"]))[0]
    if isinstance(v, dict) and set(v) == {"$bytes"}: return bytes.fromhex(v["$bytes"])
    if isinstance(v, list): return [unwire(x) for x in v]
    if isinstance(v, dict): return {k: unwire(x) for k, x in v.items()}
    return v
vals = [unwire(c["value"]) for c in d["cases"]]
same = sum(canon_py.canon_hash(v) == c["py_xxh3_128"] for v, c in zip(vals, d["cases"]))
print(f"PyO3 canon_hash == pure-Python canon_hash on {same}/{len(vals)} vectors")
rec = {"node": "pkg:numpy@2.5.3", "deps": [f"pkg:dep{i}@1.{i}" for i in range(20)], "attrs": {"weight": 0.5, "pinned": True, "tags": ["a", "b", "c"]}}
recs = [dict(rec, node=f"pkg:{i}") for i in range(20_000)]
for name, f in [("pure-Python canon.canon_hash", canon.canon_hash), ("PyO3 canon_py.canon_hash", canon_py.canon_hash)]:
    t = time.perf_counter(); hs = [f(r) for r in recs]; dt = time.perf_counter() - t
    print(f"{name:30s} {dt/len(recs)*1e6:7.2f} us/record  ({len(recs)} records)")
assert [canon.canon_hash(r) for r in recs[:100]] == [canon_py.canon_hash(r) for r in recs[:100]]
