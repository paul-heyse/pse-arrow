//! FastCDC v2020 chunking cost vs per-chunk fingerprint cost, and boundary-shift resistance vs fixed-size chunks.
use std::collections::HashSet;
use std::time::Instant;

fn rand_bytes(n: usize, mut s: u64) -> Vec<u8> {
    let mut v = Vec::with_capacity(n);
    while v.len() < n { s ^= s << 13; s ^= s >> 7; s ^= s << 17; v.extend_from_slice(&s.to_le_bytes()); }
    v.truncate(n); v
}

fn best<F: FnMut() -> u64>(reps: usize, mut f: F) -> (f64, u64) {
    let mut b = f64::MAX; let mut out = 0;
    for _ in 0..reps { let t = Instant::now(); out = f(); b = b.min(t.elapsed().as_secs_f64()); }
    (b, out)
}

fn main() {
    const N: usize = 256 << 20; // 256 MiB
    let (min, avg, max) = (4096usize, 16384usize, 65536usize);
    let data = rand_bytes(N, 0x9e3779b97f4a7c15);
    let gib = N as f64 / (1u64 << 30) as f64;
    let chunks: Vec<(usize, usize)> = fastcdc::v2020::FastCDC::new(&data, min, avg, max).map(|c| (c.offset, c.length)).collect();
    println!("input {} MiB random, FastCDC v2020 min/avg/max = {min}/{avg}/{max}: {} chunks, mean {} B", N >> 20, chunks.len(), N / chunks.len());
    let (t, n) = best(3, || fastcdc::v2020::FastCDC::new(&data, min, avg, max).count() as u64);
    println!("  {:44} {:6.2} GiB/s ({n} chunks)", "FastCDC v2020 boundary scan only", gib / t);
    let fp = |name: &str, f: &dyn Fn(&[u8]) -> u64| {
        let (t, x) = best(3, || chunks.iter().fold(0u64, |a, &(o, l)| a ^ f(&data[o..o + l])));
        println!("  {:44} {:6.2} GiB/s (xor {x:016x})", name, gib / t);
    };
    fp("per-chunk xxhash-rust xxh3_128", &|b| xxhash_rust::xxh3::xxh3_128(b) as u64);
    fp("per-chunk twox-hash XxHash3_128::oneshot", &|b| twox_hash::XxHash3_128::oneshot(b) as u64);
    fp("per-chunk blake3 (single-thread)", &|b| u64::from_le_bytes(blake3::hash(b).as_bytes()[..8].try_into().unwrap()));
    fp("per-chunk sha2-256", &|b| { use sha2::Digest; u64::from_le_bytes(sha2::Sha256::digest(b)[..8].try_into().unwrap()) });

    // Boundary-shift resistance: insert 100 bytes at the 1/3 point and count reusable chunks.
    let mut edited = data[..N / 3].to_vec(); edited.extend_from_slice(&[0xAB; 100]); edited.extend_from_slice(&data[N / 3..]);
    let ids = |buf: &[u8], cdc: bool| -> HashSet<u128> {
        if cdc { fastcdc::v2020::FastCDC::new(buf, min, avg, max).map(|c| xxhash_rust::xxh3::xxh3_128(&buf[c.offset..c.offset + c.length])).collect() }
        else { buf.chunks(avg).map(xxhash_rust::xxh3::xxh3_128).collect() }
    };
    for (label, cdc) in [("FastCDC", true), ("fixed 16 KiB", false)] {
        let (a, b) = (ids(&data, cdc), ids(&edited, cdc));
        let new = b.difference(&a).count();
        println!("  after 100-byte insert, {label:12}: {new} new chunks of {} ({:.2}% must be re-stored)", b.len(), 100.0 * new as f64 / b.len() as f64);
    }
}
