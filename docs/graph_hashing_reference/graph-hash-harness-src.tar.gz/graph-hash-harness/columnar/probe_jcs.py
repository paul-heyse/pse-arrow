import rfc8785, json
def show(label, obj):
    try: print(label, rfc8785.dumps(obj))
    except Exception as e: print(label, '->', type(e).__name__, e)
show('mixed   ', {'b': 1, 'a': [1.0, 0.1, 1e21, 1e-7, -0.0, 'é']})
show('2**53+1 ', {'x': 2**53 + 1})
show('NaN     ', {'x': float('nan')})
show('keys    ', {'': 1, '\U0001F600': 2})
print('json.dumps(sort_keys) keys', json.dumps({'': 1, '\U0001F600': 2}, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode())
print('json.dumps floats ', json.dumps([1.0, 1e21, 1e-7, -0.0]))
