"""Cost of getting INTO a native structure (excluded from the W1-W3 timings)."""
import time, numpy as np, polars as pl, scipy.sparse as sp, rustworkx as rx
rng = np.random.default_rng(1); N, M = 200_000, 1_000_000
s_, d_ = rng.integers(0, N, M), rng.integers(0, N, M); k = s_ != d_
e = pl.DataFrame({"src": s_[k], "dst": d_[k]}).unique()
src, dst = e["src"].to_numpy(), e["dst"].to_numpy()
t = time.perf_counter(); A = sp.csr_matrix((np.ones(len(src), dtype=np.int32), (src, dst)), shape=(N, N)); t_csr = time.perf_counter() - t
t = time.perf_counter(); g = rx.PyDiGraph(); g.add_nodes_from(range(N)); g.add_edges_from_no_data(list(zip(src.tolist(), dst.tolist()))); t_rx = time.perf_counter() - t
# string-keyed nodes: the realistic case for package/task graphs -> need a dictionary-encoding pass first
names = pl.Series([f"pkg:{i}" for i in range(N)])
es = pl.DataFrame({"s": names.gather(e["src"]), "d": names.gather(e["dst"])})
t = time.perf_counter()
ids = pl.concat([es["s"], es["d"]]).unique(maintain_order=True)
enc = pl.DataFrame({"name": ids, "id": pl.arange(0, ids.len(), eager=True)})
coded = es.join(enc, left_on="s", right_on="name").join(enc, left_on="d", right_on="name", suffix="_d")
t_dict = time.perf_counter() - t
print(f"|E|={e.height}: scipy CSR build {t_csr*1000:.0f} ms | rustworkx PyDiGraph build {t_rx*1000:.0f} ms | string->dense-id dictionary encoding via 2 hash joins {t_dict*1000:.0f} ms")
