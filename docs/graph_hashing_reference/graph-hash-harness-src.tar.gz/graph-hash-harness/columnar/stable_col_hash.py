import polars as pl, polars_hash as plh, xxhash, duckdb, sys
df = pl.DataFrame({"k": ["pkg:numpy@2.5.3", "pkg:python@3.13", ""]})
native = df.select(pl.col("k").hash(seed=0))["k"].to_list()
plugin = df.select(plh.col("k").nchash.xxh3_64())["k"].to_list()
ref = [xxhash.xxh3_64_intdigest(s.encode()) for s in df["k"]]
print("polars", pl.__version__, "Series.hash(seed=0):", native)
print("polars_hash xxh3_64 == python-xxhash:", plugin == ref, plugin[:1])
con = duckdb.connect(); con.execute("LOAD hashfuncs")
duck = [r[0] for r in con.execute("SELECT xxh3_64(k) FROM df").fetchall()]
print("duckdb hashfuncs xxh3_64 == python-xxhash:", duck == ref, "| duckdb hash():", [r[0] for r in con.execute("SELECT hash(k) FROM df").fetchall()][:1])
