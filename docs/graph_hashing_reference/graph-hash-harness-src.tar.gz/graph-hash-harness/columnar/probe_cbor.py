import cbor2, importlib.metadata as md
print("cbor2", md.version("cbor2"))
m = {False: 0, "aa": 1, "z": 2, -1: 3, 100: 4, 10: 5}
enc = cbor2.dumps(m, canonical=True)
order = list(cbor2.loads(enc).keys())
print("canonical=True key order:", order, " (RFC 8949 4.2.1 bytewise order: [10, 100, -1, 'z', 'aa', False])")
print("1.5 ->", cbor2.dumps(1.5, canonical=True).hex(), "| 1000000.5 ->", cbor2.dumps(1000000.5, canonical=True).hex(), "| -0.0 ->", cbor2.dumps(-0.0, canonical=True).hex(), "| nan ->", cbor2.dumps(float('nan'), canonical=True).hex())
print("non-canonical 1.5 ->", cbor2.dumps(1.5).hex())
# Does the divergence matter for string-only keys? Compare cbor2 order with an explicit RFC 8949 bytewise sort.
import random
random.seed(3)
keys = ["".join(random.choice("abé") for _ in range(random.randint(0, 30))) for _ in range(300)]
keys = list(dict.fromkeys(keys))
got = list(cbor2.loads(cbor2.dumps({k: 0 for k in keys}, canonical=True)).keys())
want = sorted(keys, key=lambda k: cbor2.dumps(k))
print("string-only keys: cbor2 canonical order == RFC 8949 bytewise order:", got == want)
ik = [10, 100, -1, -100, 24, 23, 1000, -25]
got_i = list(cbor2.loads(cbor2.dumps({k: 0 for k in ik}, canonical=True)).keys())
want_i = sorted(ik, key=lambda k: cbor2.dumps(k))
print("int keys: cbor2", got_i, "| RFC 8949 bytewise", want_i)
