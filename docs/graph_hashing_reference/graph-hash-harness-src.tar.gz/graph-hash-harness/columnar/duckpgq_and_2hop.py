"""(a) materialised distinct 2-hop pairs: hash join (DuckDB, Polars) vs sparse matmul (scipy CSR);
(b) DuckPGQ (needs DuckDB 1.5.4: no community build for 1.5.5/1.5.6 on 2026-10-08) ANY SHORTEST vs rustworkx."""
import sys, time, gc
if len(sys.argv) > 1: sys.path.insert(0, sys.argv[1])   # optional path to a duckdb==1.5.4 install
import duckdb, numpy as np, polars as pl, scipy.sparse as sp, rustworkx as rx

def t(f, reps=3):
    best = 1e9
    for _ in range(reps):
        gc.collect(); s = time.perf_counter(); out = f(); best = min(best, time.perf_counter() - s)
    return best * 1000, out

rng = np.random.default_rng(1); N, M = 200_000, 1_000_000
s_, d_ = rng.integers(0, N, M), rng.integers(0, N, M); k = s_ != d_
e = pl.DataFrame({"src": s_[k], "dst": d_[k]}).unique()
print("duckdb", duckdb.__version__, "polars", pl.__version__, "|E|", e.height)
con = duckdb.connect(); con.execute("SET threads=2"); con.register("e_df", e.to_arrow()); con.execute("CREATE TABLE e AS SELECT * FROM e_df")
A = sp.csr_matrix((np.ones(e.height, dtype=np.int32), (e["src"].to_numpy(), e["dst"].to_numpy())), shape=(N, N))
print("(a) distinct 2-hop pairs (src, dst2), self-pairs included")
for name, f in [
    ("duckdb join + DISTINCT", lambda: con.execute("SELECT count(*) FROM (SELECT DISTINCT a.src, b.dst FROM e a JOIN e b ON a.dst=b.src)").fetchone()[0]),
    ("polars lazy join + unique", lambda: e.lazy().join(e.lazy(), left_on="dst", right_on="src").select("src", "dst_right").unique().select(pl.len()).collect().item()),
    ("scipy CSR A@A (nnz)", lambda: (A @ A).nnz),
]:
    ms, v = t(f); print(f"  {name:32s} {ms:9.1f} ms  result={v}")
try:
    con.execute("INSTALL duckpgq FROM community"); con.execute("LOAD duckpgq")
except Exception as ex:
    print("(b) duckpgq unavailable:", str(ex).splitlines()[0]); sys.exit(0)
con.execute("CREATE TABLE v AS SELECT range AS id FROM range(%d)" % N)
con.execute("""CREATE PROPERTY GRAPH g VERTEX TABLES (v) EDGE TABLES (e SOURCE KEY (src) REFERENCES v (id) DESTINATION KEY (dst) REFERENCES v (id) LABEL knows)""")
g = rx.PyDiGraph(); g.add_nodes_from(range(N)); g.add_edges_from_no_data(list(zip(e["src"].to_list(), e["dst"].to_list())))
targets = list(range(1, 101))
def pgq():
    q = f"""FROM GRAPH_TABLE (g MATCH p = ANY SHORTEST (a:v WHERE a.id = 0)-[k:knows]->*(b:v WHERE b.id < 101 AND b.id > 0)
            COLUMNS (b.id AS dst, path_length(p) AS hops)) ORDER BY dst"""
    return con.execute(q).fetchall()
def rxw():
    d = rx.digraph_distance_matrix  # not used; BFS lengths below
    lens = rx.dijkstra_shortest_path_lengths(g, 0, lambda _: 1.0)
    return [(tt, int(lens[tt])) for tt in targets if tt in lens]
ms1, r1 = t(pgq, 1); ms2, r2 = t(rxw)
print(f"(b) single-source shortest hop counts to 100 targets\n  duckpgq ANY SHORTEST ->*        {ms1:9.1f} ms  rows={len(r1)}\n  rustworkx dijkstra lengths      {ms2:9.1f} ms  rows={len(r2)}")
print("  same hop counts:", [tuple(x) for x in r1] == r2)
print("  duckpgq version:", con.execute("SELECT extension_version FROM duckdb_extensions() WHERE extension_name='duckpgq'").fetchone())
