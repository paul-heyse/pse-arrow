# Compare Python unicodedata NFD table with Rust unicode-normalization (output of nfcdiff dump mode, see nfcdiff/README in notes)
import unicodedata, sys
rust = {int(l.split()[1], 16): l.split()[2:] for l in open(sys.argv[1])}
py = {cp: [f"{ord(x):X}" for x in unicodedata.normalize('NFD', chr(cp))] for cp in range(0x110000)
      if not 0xD800 <= cp <= 0xDFFF and unicodedata.normalize('NFD', chr(cp)) != chr(cp)}
print('python unidata', unicodedata.unidata_version, 'decomposable', len(py), '| rust decomposable', len(rust))
print('only in Rust:', len(set(rust) - set(py)), '| only in Python:', len(set(py) - set(rust)), '| differing:', sum(py[c] != rust[c] for c in set(py) & set(rust)))
