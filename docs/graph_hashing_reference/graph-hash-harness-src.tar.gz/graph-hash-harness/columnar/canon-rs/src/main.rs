//! canon/v1 in Rust: must produce byte-identical output to canon.py (see that file for the rules).
use serde_json::Value;
use unicode_normalization::UnicodeNormalization;
use xxhash_rust::xxh3::xxh3_128;

const QNAN: u64 = 0x7ff8_0000_0000_0000;

fn nfc(s: &str) -> Vec<u8> { s.nfc().collect::<String>().into_bytes() }

fn put_len(out: &mut Vec<u8>, n: usize) { out.extend_from_slice(&(n as u64).to_le_bytes()); }

fn put_f64(out: &mut Vec<u8>, v: f64) {
    let bits = if v.is_nan() { QNAN } else if v == 0.0 { 0u64 } else { v.to_bits() };
    out.push(0x04);
    out.extend_from_slice(&bits.to_le_bytes());
}

fn encode(v: &Value, out: &mut Vec<u8>) {
    match v {
        Value::Null => out.push(0x00),
        Value::Bool(false) => out.push(0x01),
        Value::Bool(true) => out.push(0x02),
        Value::Number(n) => {
            let i = n.as_i64().expect("int outside i64 (floats travel as $f64)");
            out.push(0x03);
            out.extend_from_slice(&i.to_le_bytes());
        }
        Value::String(s) => { let b = nfc(s); out.push(0x05); put_len(out, b.len()); out.extend_from_slice(&b); }
        Value::Array(xs) => { out.push(0x07); put_len(out, xs.len()); for x in xs { encode(x, out); } }
        Value::Object(m) => {
            if let (1, Some(Value::String(h))) = (m.len(), m.get("$f64")) {
                let raw = u64::from_le_bytes(hex(h).try_into().unwrap());
                return put_f64(out, f64::from_bits(raw));
            }
            if let (1, Some(Value::String(h))) = (m.len(), m.get("$bytes")) {
                let b = hex(h); out.push(0x06); put_len(out, b.len()); out.extend_from_slice(&b); return;
            }
            let mut entries: Vec<(Vec<u8>, &Value)> = m.iter().map(|(k, x)| (nfc(k), x)).collect();
            entries.sort_by(|a, b| a.0.cmp(&b.0));
            for w in entries.windows(2) { assert!(w[0].0 != w[1].0, "duplicate key after NFC"); }
            out.push(0x08); put_len(out, entries.len());
            for (kb, x) in entries { put_len(out, kb.len()); out.extend_from_slice(&kb); encode(x, out); }
        }
    }
}

fn hex(s: &str) -> Vec<u8> { (0..s.len()).step_by(2).map(|i| u8::from_str_radix(&s[i..i + 2], 16).unwrap()).collect() }
fn to_hex(b: &[u8]) -> String { b.iter().map(|x| format!("{x:02x}")).collect() }

fn canon_bytes(v: &Value) -> Vec<u8> { let mut out = b"canon/v1\x00".to_vec(); encode(v, &mut out); out }

fn merkle_node(payload: &Value, children: &[String]) -> String {
    let mut out = b"dagnode/v1\x00".to_vec();
    encode(payload, &mut out);
    put_len(&mut out, children.len());
    for c in children { out.extend_from_slice(&hex(c)); }
    format!("{:032x}", xxh3_128(&out))
}

fn main() {
    let path = std::env::args().nth(1).expect("vectors.json");
    let d: Value = serde_json::from_str(&std::fs::read_to_string(path).unwrap()).unwrap();
    let (mut ok, mut bad) = (0, 0);
    for c in d["cases"].as_array().unwrap() {
        let b = canon_bytes(&c["value"]);
        let h = format!("{:032x}", xxh3_128(&b));
        let same = to_hex(&b) == c["py_canon_hex"].as_str().unwrap() && h == c["py_xxh3_128"].as_str().unwrap();
        if same { ok += 1 } else { bad += 1; println!("MISMATCH {} rust={h}", c["value"]); }
    }
    println!("canon/v1 cases: {ok} identical, {bad} mismatched");
    // Merkle root rebuilt in Rust from the same payloads
    let leaves: Vec<String> = (0..3).map(|i| {
        let content = format!("{:032x}", xxh3_128(&canon_bytes(&Value::String(format!("body{i}")))));
        merkle_node(&serde_json::json!({"file": format!("f{i}.py"), "content_hash": content}), &[])
    }).collect();
    let root = merkle_node(&serde_json::json!({"dir": "src"}), &leaves);
    println!("merkle root rust={root} python={} equal={}", d["merkle"]["root"].as_str().unwrap(), root == d["merkle"]["root"].as_str().unwrap());
    // RFC 8785 cross-check: serde_jcs vs python rfc8785
    for j in d["jcs"].as_array().unwrap() {
        let v: Value = serde_json::from_str(j["json"].as_str().unwrap()).unwrap();
        let r = serde_jcs::to_string(&v).unwrap();
        let p = j["py_jcs"].as_str().unwrap();
        println!("JCS equal={} rust={r}{}", r == p, if r == p { String::new() } else { format!("  python={p}") });
    }
}
