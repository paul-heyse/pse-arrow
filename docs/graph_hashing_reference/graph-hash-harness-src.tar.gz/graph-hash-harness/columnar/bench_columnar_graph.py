"""Edge-table + hash-join graph work (Polars, DuckDB) vs native graph libs (rustworkx, networkx, scipy CSR).

Workloads
  W1 bulk: 2-hop path counts per source node (many-to-many self-join of the edge table)
  W2 deep: single-source reachability on (a) a random sparse graph (shallow, ~log n levels)
           and (b) a long chain graph (deep, one new node per BFS level)
  W3 global: weakly connected components
Run: python3 -I bench_columnar_graph.py
"""
import os, sys, time, gc
import numpy as np
import polars as pl
import duckdb
import rustworkx as rx
import scipy.sparse as sp
from scipy.sparse.csgraph import connected_components, breadth_first_order

THREADS = 2
os.environ.setdefault("POLARS_MAX_THREADS", str(THREADS))


def timeit(fn, reps=3):
    best = float("inf"); out = None
    for _ in range(reps):
        gc.collect(); t = time.perf_counter(); out = fn(); best = min(best, time.perf_counter() - t)
    return best, out


def random_edges(n, m, seed=1):
    rng = np.random.default_rng(seed)
    src = rng.integers(0, n, m, dtype=np.int64); dst = rng.integers(0, n, m, dtype=np.int64)
    keep = src != dst
    e = pl.DataFrame({"src": src[keep], "dst": dst[keep]}).unique()
    return e


def chain_edges(n):
    return pl.DataFrame({"src": np.arange(n - 1, dtype=np.int64), "dst": np.arange(1, n, dtype=np.int64)})


def report(name, secs, val):
    print(f"  {name:48s} {secs*1000:10.1f} ms   result={val}")


def w1_two_hop(e, con):
    print(f"W1 two-hop path counts: |E|={e.height}")
    def polars_join():
        return (e.lazy().join(e.lazy(), left_on="dst", right_on="src", suffix="_2")
                 .group_by("src").agg(pl.len().alias("paths2")).select(pl.col("paths2").sum()).collect().item())
    def duck_join():
        return con.execute("""SELECT count(*) FROM e a JOIN e b ON a.dst = b.src""").fetchone()[0]
    n = int(max(e["src"].max(), e["dst"].max())) + 1
    A = sp.csr_matrix((np.ones(e.height, dtype=np.int64), (e["src"].to_numpy(), e["dst"].to_numpy())), shape=(n, n))
    def scipy_spmm():
        # sum of (A@A) entries = number of 2-hop paths; use A @ (A @ 1) to stay O(E)
        return int((A @ (A @ np.ones(n, dtype=np.int64))).sum())
    g = rx.PyDiGraph(); g.add_nodes_from(range(n)); g.add_edges_from_no_data(list(zip(e["src"].to_list(), e["dst"].to_list())))
    def rustworkx_loop():
        od = [g.out_degree(i) for i in range(n)]
        return sum(od[v] for (_, v) in g.edge_list())
    for name, f in [("polars lazy self-join + group_by", polars_join), ("duckdb self-join count(*)", duck_join),
                    ("scipy CSR A@(A@1)", scipy_spmm), ("rustworkx python loop over edge_list", rustworkx_loop)]:
        s, v = timeit(f); report(name, s, v)
    return g, A, n


def w2_reach(e, con, g, A, n, label):
    print(f"W2 single-source reachability [{label}]: |V|={n} |E|={e.height}")
    con.register("e_df", e.to_arrow() if hasattr(e, 'to_arrow') else e)
    con.execute("CREATE OR REPLACE TABLE ee AS SELECT * FROM e_df")
    def duck_union():
        return con.execute("""
            WITH RECURSIVE r(node) AS (SELECT 0::BIGINT UNION SELECT ee.dst FROM r JOIN ee ON ee.src = r.node)
            SELECT count(*) FROM r""").fetchone()[0]
    def duck_using_key():
        return con.execute("""
            WITH RECURSIVE r(node, depth) USING KEY (node) AS (
                SELECT 0::BIGINT, 0
                UNION
                SELECT ee.dst, min(r.depth) + 1 FROM r JOIN ee ON ee.src = r.node
                WHERE NOT EXISTS (SELECT 1 FROM recurring.r rr WHERE rr.node = ee.dst)
                GROUP BY ee.dst)
            SELECT count(*), max(depth) FROM r""").fetchone()
    el = e.lazy()
    def polars_frontier():
        seen = pl.DataFrame({"node": [0]}, schema={"node": pl.Int64}); frontier = seen; levels = 0
        while frontier.height:
            nxt = (frontier.lazy().join(el, left_on="node", right_on="src").select(pl.col("dst").alias("node")).unique()
                   .join(seen.lazy(), on="node", how="anti").collect())
            seen = pl.concat([seen, nxt]); frontier = nxt; levels += 1
        return seen.height, levels
    def rustworkx_desc():
        return len(rx.descendants(g, 0)) + 1
    def scipy_bfs():
        return len(breadth_first_order(A, 0, directed=True, return_predecessors=False))
    runs = [("rustworkx descendants()", rustworkx_desc), ("scipy csgraph breadth_first_order", scipy_bfs),
            ("polars frontier loop (join + anti-join/level)", polars_frontier),
            ("duckdb WITH RECURSIVE ... UNION", duck_union),
            ("duckdb WITH RECURSIVE ... USING KEY", duck_using_key)]
    for name, f in runs:
        reps = 1 if label.startswith("chain") and ("duckdb" in name or "polars" in name) else 3
        s, v = timeit(f, reps); report(name, s, v)


def w3_wcc(e, con, g, A, n):
    print(f"W3 weakly connected components: |V|={n} |E|={e.height}")
    def scipy_cc():
        return connected_components(A, directed=True, connection="weak")[0]
    def rustworkx_wcc():
        return rx.number_weakly_connected_components(g)
    und = pl.concat([e, e.select(pl.col("dst").alias("src"), pl.col("src").alias("dst"))]).lazy()
    def polars_label_prop():
        lab = pl.DataFrame({"node": np.arange(n, dtype=np.int64), "c": np.arange(n, dtype=np.int64)})
        it = 0
        while True:
            it += 1
            new = (und.join(lab.lazy(), left_on="src", right_on="node").group_by("dst").agg(pl.col("c").min().alias("m"))
                   .join(lab.lazy(), left_on="dst", right_on="node", how="right")
                   .select(pl.col("node"), pl.min_horizontal("c", "m").alias("c")).collect())
            changed = new.join(lab, on="node").filter(pl.col("c") != pl.col("c_right")).height
            lab = new
            if changed == 0:
                return lab["c"].n_unique(), it
    for name, f in [("scipy csgraph connected_components", scipy_cc), ("rustworkx number_weakly_connected_components", rustworkx_wcc),
                    ("polars min-label propagation (join+group_by loop)", polars_label_prop)]:
        s, v = timeit(f, 1 if "polars" in name else 3); report(name, s, v)


if __name__ == "__main__":
    print(sys.version.split()[0], "polars", pl.__version__, "duckdb", duckdb.__version__, "rustworkx", rx.__version__,
          "numpy", np.__version__, "threads", THREADS)
    con = duckdb.connect(); con.execute(f"SET threads={THREADS}")
    N, M = 200_000, 1_000_000
    e = random_edges(N, M)
    con.register("e_src", e.to_arrow() if hasattr(e, "to_arrow") else e); con.execute("CREATE TABLE e AS SELECT * FROM e_src")
    g, A, n = w1_two_hop(e, con)
    w2_reach(e, con, g, A, n, "random sparse, shallow")
    w3_wcc(e, con, g, A, n)
    C = 5_000
    ce = chain_edges(C)
    cg = rx.PyDiGraph(); cg.add_nodes_from(range(C)); cg.add_edges_from_no_data(list(zip(ce["src"].to_list(), ce["dst"].to_list())))
    CA = sp.csr_matrix((np.ones(ce.height), (ce["src"].to_numpy(), ce["dst"].to_numpy())), shape=(C, C))
    w2_reach(ce, con, cg, CA, C, f"chain of {C} nodes, deep")
