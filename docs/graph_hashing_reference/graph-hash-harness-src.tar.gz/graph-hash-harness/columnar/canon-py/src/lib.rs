//! canon/v1 encoder exposed to Python: the same Rust code a Rust service would link directly.
use pyo3::exceptions::{PyOverflowError, PyTypeError, PyValueError};
use pyo3::prelude::*;
use pyo3::types::{PyBool, PyBytes, PyDict, PyFloat, PyInt, PyList, PyString, PyTuple};
use unicode_normalization::UnicodeNormalization;

fn put_len(out: &mut Vec<u8>, n: usize) { out.extend_from_slice(&(n as u64).to_le_bytes()); }
fn nfc(s: &str) -> Vec<u8> { s.nfc().collect::<String>().into_bytes() }

fn encode(v: &Bound<'_, PyAny>, out: &mut Vec<u8>) -> PyResult<()> {
    if v.is_none() { out.push(0x00); }
    else if let Ok(b) = v.cast::<PyBool>() { out.push(if b.is_true() { 0x02 } else { 0x01 }); }
    else if v.is_instance_of::<PyInt>() {
        let i: i64 = v.extract().map_err(|_| PyOverflowError::new_err("int outside i64"))?;
        out.push(0x03); out.extend_from_slice(&i.to_le_bytes());
    } else if let Ok(f) = v.cast::<PyFloat>() {
        let x = f.value();
        let bits = if x.is_nan() { 0x7ff8_0000_0000_0000u64 } else if x == 0.0 { 0 } else { x.to_bits() };
        out.push(0x04); out.extend_from_slice(&bits.to_le_bytes());
    } else if let Ok(s) = v.cast::<PyString>() {
        let b = nfc(&s.to_cow()?); out.push(0x05); put_len(out, b.len()); out.extend_from_slice(&b);
    } else if let Ok(b) = v.cast::<PyBytes>() {
        let b = b.as_bytes(); out.push(0x06); put_len(out, b.len()); out.extend_from_slice(b);
    } else if v.is_instance_of::<PyList>() || v.is_instance_of::<PyTuple>() {
        let n = v.len()?; out.push(0x07); put_len(out, n);
        for x in v.try_iter()? { encode(&x?, out)?; }
    } else if let Ok(d) = v.cast::<PyDict>() {
        let mut items: Vec<(Vec<u8>, Bound<'_, PyAny>)> = Vec::with_capacity(d.len());
        for (k, x) in d.iter() {
            let k = k.cast::<PyString>().map_err(|_| PyTypeError::new_err("map keys must be str"))?;
            items.push((nfc(&k.to_cow()?), x));
        }
        items.sort_by(|a, b| a.0.cmp(&b.0));
        if items.windows(2).any(|w| w[0].0 == w[1].0) { return Err(PyValueError::new_err("duplicate key after NFC")); }
        out.push(0x08); put_len(out, items.len());
        for (kb, x) in &items { put_len(out, kb.len()); out.extend_from_slice(kb); encode(x, out)?; }
    } else { return Err(PyTypeError::new_err(format!("unsupported type {}", v.get_type().name()?))); }
    Ok(())
}

#[pyfunction]
fn canon_bytes<'py>(py: Python<'py>, v: &Bound<'py, PyAny>) -> PyResult<Bound<'py, PyBytes>> {
    let mut out = b"canon/v1\x00".to_vec(); encode(v, &mut out)?; Ok(PyBytes::new(py, &out))
}

#[pyfunction]
fn canon_hash(v: &Bound<'_, PyAny>) -> PyResult<String> {
    let mut out = b"canon/v1\x00".to_vec(); encode(v, &mut out)?;
    Ok(format!("{:032x}", xxhash_rust::xxh3::xxh3_128(&out)))
}

#[pymodule]
fn canon_py(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(canon_bytes, m)?)?;
    m.add_function(wrap_pyfunction!(canon_hash, m)?)?;
    Ok(())
}
