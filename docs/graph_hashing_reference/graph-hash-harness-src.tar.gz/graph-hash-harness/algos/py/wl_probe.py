import warnings, networkx as nx
warnings.simplefilter("ignore")
h = nx.weisfeiler_lehman_graph_hash
# 1) Known WL failure: 2 disjoint triangles vs 6-cycle (both 2-regular, 6 nodes)
G1 = nx.disjoint_union(nx.cycle_graph(3), nx.cycle_graph(3)); G2 = nx.cycle_graph(6)
print("2xC3 vs C6 isomorphic:", nx.is_isomorphic(G1, G2), "| WL equal:", h(G1, iterations=10) == h(G2, iterations=10))
# 2) Strongly regular: Shrikhande vs 4x4 rook's graph (both srg(16,6,2,2))
rook = nx.cartesian_product(nx.complete_graph(4), nx.complete_graph(4))
shr = nx.Graph()
for a in range(4):
    for b in range(4):
        for da, db in [(1,0),(0,1),(1,1)]:
            shr.add_edge((a,b), ((a+da)%4, (b+db)%4))
print("rook4x4 vs Shrikhande isomorphic:", nx.is_isomorphic(rook, shr), "| WL equal:", h(rook, iterations=10) == h(shr, iterations=10),
      "| degrees", set(d for _,d in rook.degree()), set(d for _,d in shr.degree()))
# 3) Separator-free concatenation ambiguity with node_attr (iteration 1 sees raw strings)
A = nx.Graph(); A.add_node(0, l="1"); A.add_node(1, l="12"); A.add_edge(0, 1)
B = nx.Graph(); B.add_node(0, l="11"); B.add_node(1, l="2"); B.add_edge(0, 1)
print("label-concat probe: isomorphic-as-labelled:", nx.is_isomorphic(A, B, node_match=lambda x,y: x["l"]==y["l"]),
      "| WL equal (iters=1):", h(A, node_attr="l", iterations=1) == h(B, node_attr="l", iterations=1),
      "| WL equal (iters=3):", h(A, node_attr="l", iterations=3) == h(B, node_attr="l", iterations=3))
# 4) Directed + edge_attr: does WL distinguish in- vs out- edges?
D1 = nx.DiGraph(); D1.add_edge(0, 1, t="x"); D1.add_edge(0, 2, t="x")   # out-star
D2 = nx.DiGraph(); D2.add_edge(1, 0, t="x"); D2.add_edge(2, 0, t="x")   # in-star
print("out-star vs in-star iso:", nx.is_isomorphic(D1, D2), "| WL(edge_attr) equal:", h(D1, edge_attr="t") == h(D2, edge_attr="t"),
      "| WL(no attr) equal:", h(D1) == h(D2))
D3 = nx.DiGraph(); D3.add_edge(0,1,t="x"); D3.add_edge(1,2,t="x")  # path 0->1->2
D4 = nx.DiGraph(); D4.add_edge(1,0,t="x"); D4.add_edge(1,2,t="x")  # 0<-1->2
print("path vs out-fork iso:", nx.is_isomorphic(D3, D4), "| WL(edge_attr) equal:", h(D3, edge_attr="t", iterations=5) == h(D4, edge_attr="t", iterations=5))
