import warnings, networkx as nx
warnings.simplefilter("ignore")
h = nx.weisfeiler_lehman_graph_hash
def lab(pairs):
    G = nx.Graph()
    for i, l in enumerate(pairs): G.add_node(i, l=l)
    G.add_edge(0, 1); return G
A, B = lab([1, 1111]), lab([11, 111])   # concat of either order is "11111" in both graphs
nm = lambda x, y: x["l"] == y["l"]
for it in (1, 3, 5):
    print(f"labels (1,1111) vs (11,111), iters={it}: iso={nx.is_isomorphic(A,B,node_match=nm)} WL-equal={h(A,node_attr='l',iterations=it)==h(B,node_attr='l',iterations=it)}")
