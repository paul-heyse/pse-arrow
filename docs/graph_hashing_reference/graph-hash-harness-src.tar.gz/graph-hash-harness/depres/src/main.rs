// depres: internal dependency graph -> computed resolution (pubgrub 0.4.0)
//         -> topo order / cycle detection -> Merkle-fingerprinted lock (XXH3-128)
//         + SHA-256 artifact integrity -> lock diff -> "why is X included".
// Also: small measurements (interned vs String package ids; hash-table hashers;
// XXH3-128 vs SHA-256 throughput).
use std::collections::{BTreeMap, BTreeSet, HashMap, VecDeque};
use std::hash::{BuildHasher, Hash};
use std::hint::black_box;
use std::time::Instant;

use pubgrub::{
    DefaultStringReporter, Dependencies, DependencyProvider, OfflineDependencyProvider,
    PubGrubError, Ranges, Reporter, SemanticVersion, resolve,
};
use sha2::{Digest, Sha256};
use xxhash_rust::xxh3::xxh3_128;

type VS = Ranges<SemanticVersion>;
type Dp = OfflineDependencyProvider<String, VS>;

fn v(a: u32, b: u32, c: u32) -> SemanticVersion {
    SemanticVersion::new(a, b, c)
}
/// [lo, hi)
fn r(lo: (u32, u32, u32), hi: (u32, u32, u32)) -> VS {
    Ranges::between(lo, hi)
}
fn s(x: &str) -> String {
    x.to_string()
}

/// Internal "plugin / data-product" registry. In a real codebase this is
/// generated from each module's manifest, not hand-ordered.
fn internal_registry() -> Dp {
    let mut dp = Dp::new();
    dp.add_dependencies(s("app"), v(1, 0, 0), [
        (s("ingest"), r((2, 0, 0), (3, 0, 0))),
        (s("features"), r((1, 0, 0), (2, 0, 0))),
        (s("report"), r((1, 0, 0), (2, 0, 0))),
    ]);
    // app 2.0.0 asks for something impossible: schema 4 + ingest 2 (ingest 2 needs schema 3)
    dp.add_dependencies(s("app"), v(2, 0, 0), [
        (s("ingest"), r((2, 0, 0), (3, 0, 0))),
        (s("schema"), r((4, 0, 0), (5, 0, 0))),
    ]);
    dp.add_dependencies(s("ingest"), v(2, 0, 0), [
        (s("schema"), r((3, 0, 0), (4, 0, 0))),
        (s("logging"), r((1, 0, 0), (2, 0, 0))),
    ]);
    dp.add_dependencies(s("ingest"), v(2, 1, 0), [
        (s("schema"), r((3, 1, 0), (4, 0, 0))),
        (s("logging"), r((1, 0, 0), (2, 0, 0))),
    ]);
    // newest features needs schema 4 -> conflicts with ingest; resolver must learn this
    dp.add_dependencies(s("features"), v(1, 2, 0), [
        (s("schema"), r((4, 0, 0), (5, 0, 0))),
        (s("ingest"), r((2, 0, 0), (3, 0, 0))),
    ]);
    dp.add_dependencies(s("features"), v(1, 0, 0), [
        (s("schema"), r((3, 0, 0), (4, 0, 0))),
        (s("ingest"), r((2, 0, 0), (3, 0, 0))),
    ]);
    dp.add_dependencies(s("report"), v(1, 0, 0), [
        (s("features"), r((1, 0, 0), (2, 0, 0))),
        (s("theme"), r((1, 0, 0), (2, 0, 0))),
    ]);
    dp.add_dependencies(s("schema"), v(3, 0, 0), []);
    dp.add_dependencies(s("schema"), v(3, 1, 0), []);
    dp.add_dependencies(s("schema"), v(4, 0, 0), []);
    dp.add_dependencies(s("logging"), v(1, 4, 0), []);
    dp.add_dependencies(s("theme"), v(1, 0, 0), []);
    dp
}

/// Resolved graph: node -> (version, deps-with-constraint), all BTree => deterministic.
type Resolved = BTreeMap<String, (SemanticVersion, BTreeMap<String, VS>)>;

fn materialize(dp: &Dp, sol: &pubgrub::SelectedDependencies<String, SemanticVersion>) -> Resolved {
    let mut out = Resolved::new();
    for (p, ver) in sol.iter() {
        let deps = match dp.get_dependencies(p, ver).unwrap() {
            Dependencies::Available(c) => c.iter().map(|(d, vs)| (d.clone(), vs.clone())).collect(),
            Dependencies::Unavailable(_) => BTreeMap::new(),
        };
        out.insert(p.clone(), (ver.clone(), deps));
    }
    out
}

/// Kahn's algorithm, deps-first. Err(cycle members) if not a DAG.
fn topo_order(g: &Resolved) -> Result<Vec<String>, Vec<String>> {
    let mut indeg: BTreeMap<&str, usize> = g.keys().map(|k| (k.as_str(), 0)).collect();
    let mut rdeps: BTreeMap<&str, Vec<&str>> = BTreeMap::new();
    for (n, (_, deps)) in g {
        for d in deps.keys() {
            *indeg.get_mut(n.as_str()).unwrap() += 1; // n waits for d
            rdeps.entry(d.as_str()).or_default().push(n.as_str());
        }
    }
    let mut ready: VecDeque<&str> = indeg.iter().filter(|(_, c)| **c == 0).map(|(k, _)| *k).collect();
    let mut order = Vec::new();
    while let Some(n) = ready.pop_front() {
        order.push(n.to_string());
        for &m in rdeps.get(n).map(|v| v.as_slice()).unwrap_or(&[]) {
            let c = indeg.get_mut(m).unwrap();
            *c -= 1;
            if *c == 0 {
                ready.push_back(m);
            }
        }
    }
    if order.len() == g.len() {
        Ok(order)
    } else {
        Err(indeg.into_iter().filter(|(_, c)| *c > 0).map(|(k, _)| k.to_string()).collect())
    }
}

/// Fake artifact bytes for a node (in reality: wheel/crate/tarball/build output).
fn artifact(name: &str, ver: &SemanticVersion, rebuild: u32) -> Vec<u8> {
    format!("artifact:{name}@{ver}#build{rebuild}").into_bytes()
}

#[derive(Clone, PartialEq)]
struct LockEntry {
    version: String,
    sha256: String, // integrity: crosses trust boundary (download/cache share) -> cryptographic
    fp: u128,       // Merkle fingerprint: XXH3-128(self content || sorted dep fps) -> change detection
}

fn build_lock(g: &Resolved, order: &[String], rebuilds: &HashMap<&str, u32>) -> BTreeMap<String, LockEntry> {
    let mut lock: BTreeMap<String, LockEntry> = BTreeMap::new();
    for n in order {
        // deps-first order guarantees dep fps exist
        let (ver, deps) = &g[n];
        let bytes = artifact(n, ver, *rebuilds.get(n.as_str()).unwrap_or(&0));
        let sha = Sha256::digest(&bytes);
        let mut buf = Vec::with_capacity(128);
        // length-prefixed fields -> unambiguous encoding
        for field in [n.as_bytes(), ver.to_string().as_bytes(), &xxh3_128(&bytes).to_le_bytes()] {
            buf.extend_from_slice(&(field.len() as u32).to_le_bytes());
            buf.extend_from_slice(field);
        }
        for d in deps.keys() {
            // BTreeMap => sorted => order-independent
            buf.extend_from_slice(d.as_bytes());
            buf.push(0);
            buf.extend_from_slice(&lock[d].fp.to_le_bytes());
        }
        lock.insert(n.clone(), LockEntry {
            version: ver.to_string(),
            sha256: sha.iter().map(|b| format!("{b:02x}")).collect(),
            fp: xxh3_128(&buf),
        });
    }
    lock
}

fn diff_lock(a: &BTreeMap<String, LockEntry>, b: &BTreeMap<String, LockEntry>) -> Vec<String> {
    let keys: BTreeSet<&String> = a.keys().chain(b.keys()).collect();
    let mut out = vec![];
    for k in keys {
        match (a.get(k), b.get(k)) {
            (Some(x), Some(y)) if x == y => {}
            (Some(x), Some(y)) if x.version != y.version => out.push(format!("~ {k} {} -> {}", x.version, y.version)),
            (Some(x), Some(y)) if x.sha256 != y.sha256 => out.push(format!("~ {k} content changed (sha256 {}.. -> {}..)", &x.sha256[..8], &y.sha256[..8])),
            (Some(_), Some(_)) => out.push(format!("~ {k} fingerprint changed (a dependency changed)")),
            (None, Some(y)) => out.push(format!("+ {k} {}", y.version)),
            (Some(x), None) => out.push(format!("- {k} {}", x.version)),
            (None, None) => unreachable!(),
        }
    }
    out
}

/// "Why is X included?" BFS from root over resolved edges; returns shortest path with constraints.
fn why(g: &Resolved, root: &str, target: &str) -> Option<Vec<String>> {
    let mut parent: HashMap<&str, &str> = HashMap::new();
    let mut q = VecDeque::from([root]);
    let mut seen = BTreeSet::from([root]);
    while let Some(n) = q.pop_front() {
        if n == target {
            let mut path = vec![target.to_string()];
            let mut cur = target;
            while let Some(&p) = parent.get(cur) {
                path.push(format!("{p} {} --requires[{}]-->", g[p].0, g[p].1[cur]));
                cur = p;
            }
            path.reverse();
            return Some(path);
        }
        for d in g[n].1.keys() {
            if seen.insert(d.as_str()) {
                parent.insert(d.as_str(), n);
                q.push_back(d.as_str());
            }
        }
    }
    None
}

/// Canonical manifest digest: memo key for "do we need to re-resolve at all?"
fn manifest_key(decls: &[(&str, (u32, u32, u32), Vec<(&str, VS)>)]) -> u128 {
    let mut canon: BTreeMap<String, BTreeMap<String, String>> = BTreeMap::new();
    for (p, ver, deps) in decls {
        let key = format!("{p}@{}", v(ver.0, ver.1, ver.2));
        let e = canon.entry(key).or_default();
        for (d, vs) in deps {
            e.insert(d.to_string(), vs.to_string());
        }
    }
    let mut buf = String::new();
    for (k, deps) in &canon {
        buf.push_str(k);
        buf.push('\n');
        for (d, vs) in deps {
            buf.push_str(&format!("  {d} {vs}\n"));
        }
    }
    xxh3_128(buf.as_bytes())
}

// ---------------- measurements ----------------

fn synth<P: pubgrub::Package>(name: impl Fn(u32) -> P, layers: u32, width: u32) -> OfflineDependencyProvider<P, Ranges<u32>> {
    let mut dp = OfflineDependencyProvider::<P, Ranges<u32>>::new();
    let id = |l: u32, i: u32| 1 + l * width + i;
    dp.add_dependencies(name(0), 1u32, (0..width).map(|i| (name(id(0, i)), Ranges::full())).collect::<Vec<_>>());
    for l in 0..layers {
        for i in 0..width {
            for ver in 1u32..=4 {
                let deps: Vec<(P, Ranges<u32>)> = if l + 1 == layers {
                    vec![]
                } else {
                    (0..3u32)
                        .map(|k| {
                            let j = (i * 7 + k * 13 + ver) % width;
                            // mild conflicts: some newest versions pin a dep to its oldest version
                            let range = if ver == 4 && (l * width + i) % 17 == 0 && k == 0 {
                                Ranges::singleton(1u32)
                            } else {
                                Ranges::higher_than(ver.saturating_sub(1).max(1))
                            };
                            (name(id(l + 1, j)), range)
                        })
                        .collect()
                };
                dp.add_dependencies(name(id(l, i)), ver, deps);
            }
        }
    }
    dp
}

fn time_min<F: FnMut() -> usize>(runs: usize, mut f: F) -> (f64, usize) {
    let mut best = f64::MAX;
    let mut last = 0;
    for _ in 0..runs {
        let t = Instant::now();
        last = black_box(f());
        best = best.min(t.elapsed().as_secs_f64());
    }
    (best, last)
}

fn bench_table<S: BuildHasher + Default>(label: &str, names: &[String], probes: &[usize]) {
    let mut m: HashMap<&str, u32, S> = HashMap::with_hasher(S::default());
    for (i, n) in names.iter().enumerate() {
        m.insert(n.as_str(), i as u32);
    }
    let (t, sum) = time_min(5, || {
        let mut acc = 0usize;
        for &p in probes {
            acc = acc.wrapping_add(*m.get(names[p].as_str()).unwrap() as usize);
        }
        acc
    });
    println!("  {label:<34} {:>7.2} ns/lookup  (checksum {sum})", t * 1e9 / probes.len() as f64);
}

fn main() {
    println!("== 1. Resolve internal graph (app 1.0.0) ==");
    let dp = internal_registry();
    let sol = resolve(&dp, s("app"), v(1, 0, 0)).expect("resolvable");
    let g = materialize(&dp, &sol);
    for (p, (ver, deps)) in &g {
        let ds: Vec<String> = deps.iter().map(|(d, vs)| format!("{d} {vs}")).collect();
        println!("  {p:<9} {ver:<6} deps: [{}]", ds.join(", "));
    }

    println!("\n== 2. Unsatisfiable request (app 2.0.0): derivation-tree explanation ==");
    match resolve(&dp, s("app"), v(2, 0, 0)) {
        Ok(_) => println!("  unexpectedly resolved"),
        Err(PubGrubError::NoSolution(mut tree)) => {
            tree.collapse_no_versions();
            for line in DefaultStringReporter::report(&tree).lines() {
                println!("  {line}");
            }
        }
        Err(e) => println!("  other error: {e:?}"),
    }

    println!("\n== 3. Build/install order (deps first, Kahn) ==");
    let order = topo_order(&g).expect("DAG");
    println!("  {}", order.join(" -> "));

    println!("\n== 4. Cycles: resolver accepts them, topo order must reject/condense ==");
    let mut cyc = Dp::new();
    cyc.add_dependencies(s("root"), v(1, 0, 0), [(s("plugin-a"), Ranges::full())]);
    cyc.add_dependencies(s("plugin-a"), v(1, 0, 0), [(s("plugin-b"), Ranges::full())]);
    cyc.add_dependencies(s("plugin-b"), v(1, 0, 0), [(s("plugin-a"), Ranges::full())]);
    let csol = resolve(&cyc, s("root"), v(1, 0, 0));
    println!("  resolve() ok = {}", csol.is_ok());
    let cg = materialize(&cyc, &csol.unwrap());
    match topo_order(&cg) {
        Ok(o) => println!("  order {o:?}"),
        Err(members) => println!("  topo_order: cycle among {members:?}"),
    }

    println!("\n== 5. Lock with SHA-256 (integrity) + XXH3-128 Merkle fingerprints (change detection) ==");
    let lock0 = build_lock(&g, &order, &HashMap::new());
    for (k, e) in &lock0 {
        println!("  {k:<9} {:<6} sha256={}..  fp={:032x}", e.version, &e.sha256[..16], e.fp);
    }
    let lock0_again = build_lock(&g, &order, &HashMap::new());
    println!("  deterministic rebuild identical: {}", lock0 == lock0_again);

    println!("\n== 6. Lock diff after rebuilding schema 3.1.0 (content change, same version) ==");
    let lock1 = build_lock(&g, &order, &HashMap::from([("schema", 1)]));
    for l in diff_lock(&lock0, &lock1) {
        println!("  {l}");
    }
    println!("  -> invalidation set = ancestors of 'schema' only; 'logging' and 'theme' keep their fp");

    println!("\n== 7. Why is 'schema' included? ==");
    for step in why(&g, "app", "schema").unwrap() {
        println!("  {step}");
    }

    println!("\n== 8. Manifest memo key (skip re-resolve when inputs unchanged) ==");
    let a = vec![
        ("ingest", (2, 1, 0), vec![("schema", r((3, 1, 0), (4, 0, 0))), ("logging", r((1, 0, 0), (2, 0, 0)))]),
        ("report", (1, 0, 0), vec![("features", r((1, 0, 0), (2, 0, 0)))]),
    ];
    let mut b = a.clone();
    b.reverse();
    b[1].2.reverse(); // different declaration order, same meaning
    let mut c = a.clone();
    c[0].2[0].1 = r((3, 0, 0), (4, 0, 0)); // constraint actually changed
    println!("  key(a)={:032x}", manifest_key(&a));
    println!("  key(b)={:032x}  (reordered decls) equal={}", manifest_key(&b), manifest_key(&a) == manifest_key(&b));
    println!("  key(c)={:032x}  (changed constraint) equal={}", manifest_key(&c), manifest_key(&a) == manifest_key(&c));

    println!("\n== 9. Measurements (release build, 2 vCPU shared host) ==");
    let (layers, width) = (30u32, 100u32);
    let dps = synth(|i| format!("org.example.plugin-{i:05}"), layers, width);
    let dpu = synth(|i| i, layers, width);
    let (ts, ns) = time_min(5, || resolve(&dps, "org.example.plugin-00000".to_string(), 1u32).unwrap().iter().count());
    let (tu, nu) = time_min(5, || resolve(&dpu, 0u32, 1u32).unwrap().iter().count());
    let su = resolve(&dpu, 0u32, 1u32).unwrap();
    let older = su.iter().filter(|(_, v)| **v < 4).count();
    println!("  synthetic graph: {} pkgs x 4 versions, 3 deps/version", layers * width + 1);
    println!("  resolve, P=String (provider-side String keys): {:>8.2} ms  ({ns} selected)", ts * 1e3);
    println!("  resolve, P=u32    (pre-interned ids)         : {:>8.2} ms  ({nu} selected, {older} not at newest)", tu * 1e3);

    println!("  hash-table lookups, 50k package-name keys (~24 B), 2M probes:");
    let names: Vec<String> = (0..50_000).map(|i| format!("org.example.plugin-{i:05}")).collect();
    let probes: Vec<usize> = (0..2_000_000usize).map(|i| (i * 7919) % names.len()).collect();
    bench_table::<std::collections::hash_map::RandomState>("std SipHash-1-3 (RandomState)", &names, &probes);
    bench_table::<rustc_hash::FxBuildHasher>("rustc-hash FxBuildHasher", &names, &probes);
    bench_table::<xxhash_rust::xxh3::Xxh3DefaultBuilder>("xxhash-rust Xxh3DefaultBuilder", &names, &probes);
    bench_table::<XxH64Default>("xxhash-rust Xxh64Builder(0)", &names, &probes);

    println!("  content hashing:");
    let big = vec![0xA5u8; 1 << 20];
    let (tx, _) = time_min(5, || { let mut a = 0u128; for _ in 0..200 { a ^= xxh3_128(black_box(&big)); } a as usize });
    let (th, _) = time_min(5, || { let mut a = 0u8; for _ in 0..50 { a ^= Sha256::digest(black_box(&big))[0]; } a as usize });
    println!("    1 MiB  XXH3-128: {:>7.2} GiB/s   SHA-256: {:>6.2} GiB/s", 200.0 / 1024.0 / tx, 50.0 / 1024.0 / th);
    let small = [0x5Au8; 64];
    let (tx, _) = time_min(5, || { let mut a = 0u128; for i in 0..1_000_000u32 { let mut x = small; x[0] = i as u8; a ^= xxh3_128(black_box(&x)); } a as usize });
    let (th, _) = time_min(5, || { let mut a = 0u8; for i in 0..1_000_000u32 { let mut x = small; x[0] = i as u8; a ^= Sha256::digest(black_box(&x))[0]; } a as usize });
    println!("    64 B   XXH3-128: {:>7.1} ns/op    SHA-256: {:>6.1} ns/op", tx * 1e3, th * 1e3);
}

#[derive(Default, Clone)]
struct XxH64Default;
impl BuildHasher for XxH64Default {
    type Hasher = xxhash_rust::xxh64::Xxh64;
    fn build_hasher(&self) -> Self::Hasher {
        xxhash_rust::xxh64::Xxh64::new(0)
    }
}

#[allow(dead_code)]
fn _assert_hash<T: Hash>() {}
