//! SurrealDB 3.3.x + xxhash-rust harness: hash-keyed code graph, executed against kv-mem.
//!
//! Sections map to the research brief:
//!  S1 schema (func nodes, calls TYPE RELATION ENFORCED, UNIQUE(in,out))
//!  S2 ingest with xxh3-derived ids (u64 -> i64 bit-cast) + content_hash
//!  S3 idempotent re-ingest, prove no dup nodes/edges
//!  S4 change one node, select only nodes whose content_hash changed
//!  S5 multi-hop + recursive traversal (+collect, +path, +shortest)
//!  S6 memo table keyed by XXH3-128 fingerprint (string id and array id)
//!  S7 gotchas: u64 > i64::MAX via serde_json / SurrealValue, ordering of bit-cast ids
use std::collections::BTreeMap;

use surrealdb::Surreal;
use surrealdb::engine::local::Mem;
use surrealdb::types::{RecordId, RecordIdKey, SurrealValue, ToSql, Value};
use xxhash_rust::xxh3::{xxh3_64, xxh3_64_with_seed, xxh3_128};

// ---------- hashing helpers ----------

/// Stable node identity: hash of the fully-qualified name (NOT the body), so the id
/// survives edits while content_hash changes.
fn node_key(fq_name: &str) -> i64 {
    let h: u64 = xxh3_64(fq_name.as_bytes());
    h as i64 // bit-cast, lossless & reversible: (k as u64) == h
}

/// Content fingerprint stored as a field. Bit-cast to i64 so it is a SurrealQL int.
fn content_hash(body: &str) -> i64 {
    xxh3_64(body.as_bytes()) as i64
}

/// Deterministic edge key: hash of (caller_key, callee_key) as fixed-width LE bytes.
fn edge_key(from: i64, to: i64) -> i64 {
    let mut buf = [0u8; 16];
    buf[..8].copy_from_slice(&from.to_le_bytes());
    buf[8..].copy_from_slice(&to.to_le_bytes());
    // seed distinguishes the edge domain from the node domain
    xxh3_64_with_seed(&buf, 0xED6E) as i64
}

fn hex128(x: u128) -> String {
    format!("{x:032x}")
}

// ---------- typed records (3.x: SurrealValue derive, not serde) ----------

#[derive(Debug, Clone, SurrealValue)]
struct Func {
    id: RecordId,
    name: String,
    body: String,
    content_hash: i64,
}

#[derive(Debug, Clone, SurrealValue)]
struct Changed {
    id: RecordId,
    name: String,
    old_hash: Option<i64>,
    content_hash: i64,
}

struct Src {
    name: &'static str,
    body: &'static str,
    calls: &'static [&'static str],
}

fn corpus() -> Vec<Src> {
    vec![
        Src { name: "app::main", body: "fn main(){ run(); log(); }", calls: &["app::run", "util::log"] },
        Src { name: "app::run", body: "fn run(){ parse(); exec(); }", calls: &["app::parse", "app::exec"] },
        Src { name: "app::parse", body: "fn parse(){ lex(); }", calls: &["app::lex"] },
        Src { name: "app::lex", body: "fn lex(){ log(); }", calls: &["util::log"] },
        Src { name: "app::exec", body: "fn exec(){ eval(); log(); }", calls: &["app::eval", "util::log"] },
        Src { name: "app::eval", body: "fn eval(){ eval(); }", calls: &["app::eval"] }, // self-loop (recursion)
        Src { name: "util::log", body: "fn log(){}", calls: &[] },
    ]
}

async fn ingest(db: &Surreal<surrealdb::engine::local::Db>, src: &[Src]) -> surrealdb::Result<()> {
    // Nodes: UPSERT on a deterministic id; keep previous hash in prev_hash so a later
    // query can select only changed nodes (no timestamps, no version counters).
    let mut nodes = Vec::new();
    let mut edges = Vec::new();
    for s in src {
        let k = node_key(s.name);
        nodes.push(BTreeMap::from([
            ("id".to_string(), RecordId::new("func", k).into_value()),
            ("name".to_string(), s.name.to_string().into_value()),
            ("body".to_string(), s.body.to_string().into_value()),
            ("content_hash".to_string(), content_hash(s.body).into_value()),
        ]));
        for c in s.calls {
            let ck = node_key(c);
            edges.push(BTreeMap::from([
                ("id".to_string(), RecordId::new("calls", edge_key(k, ck)).into_value()),
                ("in".to_string(), RecordId::new("func", k).into_value()),
                ("out".to_string(), RecordId::new("func", ck).into_value()),
            ]));
        }
    }
    // One transaction: nodes first (ENFORCED relation requires endpoints to exist).
    let mut res = db
        .query("BEGIN TRANSACTION")
        .query(
            "FOR $n IN $nodes {
                UPSERT $n.id SET
                    name = $n.name,
                    body = $n.body,
                    prev_hash = IF content_hash = NONE THEN $n.content_hash ELSE content_hash END,
                    content_hash = $n.content_hash
                RETURN NONE;
            }",
        )
        .query(
            "INSERT RELATION INTO calls $edges
               ON DUPLICATE KEY UPDATE seen = (seen OR 0) + 1
               RETURN NONE",
        )
        .query("COMMIT TRANSACTION")
        .bind(("nodes", nodes))
        .bind(("edges", edges))
        .await?;
    let errs = res.take_errors();
    if !errs.is_empty() {
        for (i, e) in &errs {
            eprintln!("  ingest stmt {i} error: {e}");
        }
    }
    Ok(())
}

async fn counts(db: &Surreal<surrealdb::engine::local::Db>) -> surrealdb::Result<(i64, i64)> {
    let mut r = db
        .query("RETURN count(SELECT VALUE id FROM func); RETURN count(SELECT VALUE id FROM calls);")
        .await?;
    let n: Option<i64> = r.take(0)?;
    let e: Option<i64> = r.take(1)?;
    Ok((n.unwrap_or(-1), e.unwrap_or(-1)))
}

async fn show(db: &Surreal<surrealdb::engine::local::Db>, label: &str, q: &str) {
    match db.query(q).await {
        Ok(mut r) => {
            let n = r.num_statements();
            for i in 0..n {
                match r.take::<Value>(i) {
                    Ok(v) => println!("{label}[{i}] => {}", v.into_json_value()),
                    Err(e) => println!("{label}[{i}] ERROR => {e}"),
                }
            }
        }
        Err(e) => println!("{label} QUERY ERROR => {e}"),
    }
}

#[tokio::main]
async fn main() -> surrealdb::Result<()> {
    let db = Surreal::new::<Mem>(()).await?;
    db.use_ns("harness").use_db("graph").await?;
    let ver = db.version().await?;
    println!("server version: {ver}");

    // ---------------- S1 schema ----------------
    println!("\n== S1 schema ==");
    let mut r = db
        .query(
            "DEFINE TABLE func SCHEMAFULL;
             DEFINE FIELD name ON func TYPE string;
             DEFINE FIELD body ON func TYPE string;
             DEFINE FIELD content_hash ON func TYPE int;
             DEFINE FIELD prev_hash ON func TYPE option<int>;
             DEFINE FIELD dirty ON func TYPE bool VALUE prev_hash != NONE AND prev_hash != content_hash;
             DEFINE INDEX func_name ON func FIELDS name UNIQUE;
             DEFINE INDEX func_dirty ON func FIELDS dirty;
             DEFINE TABLE calls TYPE RELATION IN func OUT func ENFORCED SCHEMAFULL;
             DEFINE FIELD seen ON calls TYPE option<int>;
             DEFINE INDEX calls_unique ON calls FIELDS in, out UNIQUE;
             DEFINE TABLE memo SCHEMAFULL;
             DEFINE FIELD result ON memo TYPE string;
             DEFINE FIELD hits ON memo TYPE int DEFAULT 0;",
        )
        .await?;
    let errs = r.take_errors();
    println!("schema statements: {} errors: {:?}", r.num_statements(), errs);

    // ---------------- S2 ingest ----------------
    println!("\n== S2 ingest (u64 -> i64 bit-cast ids) ==");
    for s in corpus().iter().take(3) {
        let h = xxh3_64(s.name.as_bytes());
        let k = h as i64;
        println!(
            "  {:<12} xxh3_64=0x{h:016x} u64={h:<20} -> i64 key={k:<21} roundtrip_ok={}",
            s.name,
            (k as u64) == h
        );
    }
    let src = corpus();
    ingest(&db, &src).await?;
    let (n, e) = counts(&db).await?;
    println!("after ingest #1: func={n} calls={e}");
    let one: Option<Func> = db.select(RecordId::new("func", node_key("app::run"))).await?;
    println!("typed select func:{} => {:?}", node_key("app::run"), one);
    show(&db, "edge-sample", "SELECT id, in.name AS from, out.name AS to FROM calls LIMIT 3;").await;

    // ---------------- S3 idempotent re-ingest ----------------
    println!("\n== S3 idempotent re-ingest ==");
    ingest(&db, &src).await?;
    ingest(&db, &src).await?;
    let (n2, e2) = counts(&db).await?;
    println!("after ingest #2,#3: func={n2} calls={e2}  (unchanged: {})", n2 == n && e2 == e);
    show(&db, "seen-counter", "SELECT VALUE seen FROM calls LIMIT 3;").await;
    // Duplicate edge with a DIFFERENT id but same (in,out) -> unique index must reject
    let a = node_key("app::main");
    let b = node_key("app::run");
    let mut r = db
        .query("RELATE $a->calls->$b")
        .bind(("a", RecordId::new("func", a)))
        .bind(("b", RecordId::new("func", b)))
        .await?;
    match r.take::<Value>(0) {
        Ok(v) => println!("plain RELATE dup (random edge id) => accepted?! {}", v.into_json_value()),
        Err(e) => println!("plain RELATE dup (random edge id) => rejected: {e}"),
    }
    // Same deterministic edge id via RELATE (3.1.5+: update + warning) and RELATE OR UPDATE
    let eid = RecordId::new("calls", edge_key(a, b));
    let mut r = db
        .query("RELATE $a->$e->$b SET seen = 100 RETURN VALUE seen")
        .bind(("a", RecordId::new("func", a)))
        .bind(("b", RecordId::new("func", b)))
        .bind(("e", eid.clone()))
        .await?;
    println!("RELATE explicit existing edge id => {:?}", r.take::<Value>(0).map(|v| v.into_json_value()));
    // INSERT RELATION without ON DUPLICATE -> should error
    let mut r = db
        .query("INSERT RELATION INTO calls { id: $e, in: $a, out: $b }")
        .bind(("a", RecordId::new("func", a)))
        .bind(("b", RecordId::new("func", b)))
        .bind(("e", eid.clone()))
        .await?;
    println!("INSERT RELATION dup id (no ODKU) => {:?}", r.take::<Value>(0).map(|v| v.into_json_value()));
    // ENFORCED: edge to a node that doesn't exist
    let mut r = db
        .query("RELATE $a->calls->func:12345")
        .bind(("a", RecordId::new("func", a)))
        .await?;
    println!("RELATE to missing node (ENFORCED) => {:?}", r.take::<Value>(0).map(|v| v.into_json_value()));
    let (n3, e3) = counts(&db).await?;
    println!("counts after dup attempts: func={n3} calls={e3}");

    // ---------------- S4 change detection ----------------
    println!("\n== S4 change detection by content_hash ==");
    let mut src2 = corpus();
    src2[3].body = "fn lex(){ log(); trace(); }"; // app::lex changed
    ingest(&db, &src2).await?;
    let mut r = db
        .query("SELECT id, name, prev_hash AS old_hash, content_hash FROM func WHERE prev_hash != content_hash")
        .await?;
    let changed: Vec<Changed> = r.take(0)?;
    println!("changed nodes: {changed:?}");
    // Content-hash comparison against an app-side manifest (no stored prev_hash needed)
    let manifest: Vec<Value> = src2
        .iter()
        .map(|s| {
            Value::from_t(BTreeMap::from([
                ("id".to_string(), RecordId::new("func", node_key(s.name)).into_value()),
                ("h".to_string(), content_hash(s.body).into_value()),
            ]))
        })
        .collect();
    // Pre-write diff: which incoming nodes differ from what is stored? (new ids => content_hash NONE => included)
    let mut src3 = corpus();
    src3[3].body = "fn lex(){ log(); trace(); }";
    src3[6].body = "fn log(){ /* v2 */ }"; // util::log changed vs stored
    let manifest3: Vec<Value> = src3
        .iter()
        .map(|s| {
            Value::from_t(BTreeMap::from([
                ("id".to_string(), RecordId::new("func", node_key(s.name)).into_value()),
                ("h".to_string(), content_hash(s.body).into_value()),
            ]))
        })
        .collect();
    let _ = manifest;
    let mut r = db
        .query("SELECT VALUE id FROM $m WHERE id.content_hash != h")
        .bind(("m", manifest3))
        .await?;
    println!("pre-write manifest diff (expect util::log only) => {:?}", r.take::<Value>(0).map(|v| v.into_json_value()));
    show(&db, "dirty via index", "SELECT VALUE name FROM func WHERE dirty = true;").await;
    show(&db, "explain dirty", "SELECT VALUE name FROM func WHERE dirty = true EXPLAIN;").await;
    show(&db, "explain prev!=content", "SELECT VALUE name FROM func WHERE prev_hash != content_hash EXPLAIN;").await;
    // Upstream impact: who (transitively) calls the changed node?  <-calls<-func recursive
    show(
        &db,
        "impact(callers of app::lex, transitive)",
        &format!(
            "RETURN func:{}.{{..+collect}}(<-calls<-func).name;",
            node_key("app::lex")
        ),
    )
    .await;

    // ---------------- S5 traversal ----------------
    println!("\n== S5 traversal ==");
    let main_id = node_key("app::main");
    show(&db, "1-hop", &format!("SELECT ->calls->func.name AS callees FROM func:{main_id};")).await;
    show(&db, "2-hop", &format!("SELECT ->calls->func->calls->func.name AS callees2 FROM func:{main_id};")).await;
    show(&db, "reverse", &format!("SELECT <-calls<-func.name AS callers FROM func:{};", node_key("util::log"))).await;
    show(&db, "recursive{1..3}", &format!("RETURN func:{main_id}.{{1..3}}(->calls->func).name;")).await;
    show(&db, "recursive+collect", &format!("RETURN func:{main_id}.{{..+collect}}(->calls->func).name;")).await;
    show(&db, "recursive+path (unbounded, cyclic graph)", &format!("RETURN func:{main_id}.{{..+path}}(->calls->func);")).await;
    show(&db, "recursive+path (..4)", &format!("RETURN func:{main_id}.{{..4+path}}(->calls->func).name;")).await;
    show(&db, "edge-filter", &format!("SELECT VALUE ->(calls WHERE seen >= 2)->func.name FROM func:{main_id};")).await;
    show(&db, "count(->calls)", &format!("SELECT VALUE count(->calls) FROM func:{main_id};")).await;
    show(
        &db,
        "recursive+shortest",
        &format!(
            "RETURN func:{main_id}.{{..+shortest=func:{}}}(->calls->func);",
            node_key("app::lex")
        ),
    )
    .await;
    show(
        &db,
        "recursive-nested(.@)",
        &format!("RETURN func:{main_id}.{{..3}}.{{ name, next: ->calls->func.@ }};"),
    )
    .await;

    // ---------------- S6 memo cache keyed by XXH3-128 ----------------
    println!("\n== S6 memo keyed by XXH3-128 ==");
    let input = b"eval(app::exec, opts={O2})";
    let fp: u128 = xxh3_128(input);
    let hi = (fp >> 64) as u64 as i64;
    let lo = fp as u64 as i64;
    println!("fp=0x{} hi={hi} lo={lo}", hex128(fp));
    // (a) string key (canonical hex) — portable across Python/Rust
    let sid = RecordId::new("memo", hex128(fp));
    // (b) array key of two i64 (hi, lo) — preserves numeric ordering per half
    let aid = RecordId::new("memo", RecordIdKey::Array(vec![Value::from_t(hi), Value::from_t(lo)].into()));
    // (c) uuid key: the 128 bits formatted as 8-4-4-4-12 (16-byte key, no extra crate needed)
    let hx = hex128(fp);
    let ustr = format!("{}-{}-{}-{}-{}", &hx[0..8], &hx[8..12], &hx[12..16], &hx[16..20], &hx[20..32]);
    let uid = RecordId::new("memo", RecordIdKey::Uuid(ustr.parse::<surrealdb::types::Uuid>().expect("uuid parse")));
    for (label, id) in [("string", sid.clone()), ("array", aid.clone()), ("uuid", uid.clone())] {
        // get-or-compute: first call computes, second call is a hit
        for round in 0..2 {
            let mut r = db
                .query(
                    "LET $hit = SELECT VALUE result FROM ONLY $id;
                     IF $hit != NONE {
                        UPDATE $id SET hits += 1 RETURN NONE;
                        RETURN { cached: true, result: $hit };
                     } ELSE {
                        CREATE $id SET result = $computed RETURN NONE;
                        RETURN { cached: false, result: $computed };
                     };",
                )
                .bind(("id", id.clone()))
                .bind(("computed", "RESULT(42)".to_string()))
                .await?;
            let n = r.num_statements();
            let v: Value = r.take(n - 1)?;
            println!("  memo[{label}] round {round} => {}", v.into_json_value());
        }
        show(&db, &format!("  memo[{label}] row"), &format!("SELECT * FROM {};", id_literal(&id))).await;
    }
    // UPSERT-based idempotent memo write (single statement)
    show(
        &db,
        "memo upsert",
        &format!("UPSERT memo:`{}` SET result = 'RESULT(42)', hits += 1 RETURN hits;", hex128(fp)),
    )
    .await;

    // ---------------- S7 gotchas ----------------
    println!("\n== S7 gotchas ==");
    let big: u64 = xxh3_64(b"app::run"); // 0xe6f4... > i64::MAX
    println!("raw u64 = {big} (> i64::MAX: {})", big > i64::MAX as u64);
    // (a) serde_json::Value with u64 > i64::MAX
    let j = serde_json::json!({ "h": big });
    let mut r = db.query("RETURN $j.h; RETURN type::of($j.h);").bind(("j", j)).await?;
    let v0: Value = r.take(0)?;
    let v1: Value = r.take(1)?;
    println!("serde_json u64 bind => {} (type {}), exact? {}", v0.clone().into_json_value(), v1.into_json_value(), v0.into_json_value().as_u64() == Some(big));
    // (b) SerdeWrapper / serde path for u64
    #[derive(serde::Serialize, serde::Deserialize, Debug)]
    struct H {
        h: u64,
    }
    let mut r = db
        .query("RETURN $w.h; RETURN type::of($w.h);")
        .bind(("w", surrealdb::types::SerdeWrapper(H { h: big })))
        .await?;
    let w0: Value = r.take(0)?;
    let w1: Value = r.take(1)?;
    println!("SerdeWrapper u64 bind => {} (type {})", w0.into_json_value(), w1.into_json_value());
    // (b2) SurrealValue for u64 (derive / into_value) silently bit-casts; reading back fails
    let v = Value::from_t(big);
    println!("Value::from_t(u64) => {} ; back to u64 => {:?}", v.clone().into_json_value(), v.into_t::<u64>().map_err(|e| e.to_string()));
    // (c) u64 literal > i64::MAX in SurrealQL record id
    show(&db, "u64 literal as id", &format!("CREATE func_raw:{big} RETURN id; RETURN type::of(record::id(func_raw:{big})); RETURN {big}; RETURN type::of({big});")).await;
    // (d) ordering: bit-cast i64 ids sort signed, not by unsigned hash
    show(&db, "id order (bit-cast i64)", "SELECT VALUE record::id(id) FROM func ORDER BY id LIMIT 3;").await;
    // (e) range scan on array ids (e.g. [hi, lo]) stays inside the hi prefix
    show(
        &db,
        "array id range",
        &format!("SELECT VALUE record::id(id) FROM memo:[{hi}, NONE]..=[{hi}, ..];"),
    )
    .await;
    // (f) point lookup vs WHERE scan: EXPLAIN
    show(&db, "explain point", &format!("SELECT * FROM func:{main_id} EXPLAIN;")).await;
    show(&db, "explain where-hash (no index)", &format!("SELECT * FROM func WHERE content_hash = {} EXPLAIN;", content_hash("fn main(){ run(); log(); }"))).await;
    show(&db, "define hash index", "DEFINE INDEX func_hash ON func FIELDS content_hash;").await;
    show(&db, "explain where-hash (index)", &format!("SELECT * FROM func WHERE content_hash = {} EXPLAIN;", content_hash("fn main(){ run(); log(); }"))).await;
    show(&db, "info calls", "INFO FOR TABLE calls;").await;

    // ---------------- S8 LIGHTWEIGHT relation (3.3.0+): id == [in, out] ----------------
    println!("\n== S8 LIGHTWEIGHT relation ==");
    show(&db, "lw define", "DEFINE TABLE dep TYPE RELATION IN func OUT func LIGHTWEIGHT;").await;
    let a = RecordId::new("func", node_key("app::main"));
    let b = RecordId::new("func", node_key("app::run"));
    for i in 0..3 {
        let mut r = db
            .query("RELATE $a->dep->$b")
            .bind(("a", a.clone()))
            .bind(("b", b.clone()))
            .await?;
        println!("  lw RELATE #{i} => {:?}", r.take::<Value>(0).map(|v| v.into_json_value()));
    }
    show(&db, "lw count", "RETURN count(SELECT VALUE id FROM dep);").await;
    show(&db, "lw traverse", &format!("SELECT VALUE ->dep->func.name FROM func:{};", node_key("app::main"))).await;
    show(&db, "lw with data (should fail)", &format!("RELATE func:{}->dep->func:{} SET w = 1;", node_key("app::run"), node_key("app::exec"))).await;
    show(&db, "lw to missing (should fail)", &format!("RELATE func:{}->dep->func:999;", node_key("app::run"))).await;

    // ---------------- S9 change feed (poll-free change log, versionstamp cursor) ----------------
    println!("\n== S9 CHANGEFEED ==");
    show(&db, "cf define", "DEFINE TABLE artifact CHANGEFEED 1h INCLUDE ORIGINAL; DEFINE FIELD h ON artifact TYPE int;").await;
    show(&db, "cf writes", "UPSERT artifact:1 SET h = 11; UPSERT artifact:2 SET h = 22; UPSERT artifact:1 SET h = 12; DELETE artifact:2;").await;
    show(&db, "cf show", "SHOW CHANGES FOR TABLE artifact SINCE 0 LIMIT 10;").await;

    // ---------------- S10 LIVE SELECT on embedded engine ----------------
    println!("\n== S10 LIVE SELECT (embedded) ==");
    {
        use futures::StreamExt;
        let mut stream = db.select::<Vec<Func>>("func").live().await?;
        let lexid = RecordId::new("func", node_key("app::lex"));
        db.query("UPDATE $id SET body = 'fn lex(){}', prev_hash = content_hash, content_hash = $h RETURN NONE")
            .bind(("id", lexid))
            .bind(("h", content_hash("fn lex(){}")))
            .await?
            .check()?;
        match tokio::time::timeout(std::time::Duration::from_secs(3), stream.next()).await {
            Ok(Some(Ok(n))) => println!("  live notification: action={:?} name={} content_hash={}", n.action, n.data.name, n.data.content_hash),
            Ok(Some(Err(e))) => println!("  live error: {e}"),
            Ok(None) => println!("  live stream ended"),
            Err(_) => println!("  live: no notification within 3s"),
        }
    }

    // ---------------- S11 ODKU via UNIQUE(in,out) without deterministic edge id ----------------
    println!("\n== S11 INSERT RELATION ODKU via unique index ==");
    show(&db, "odku-by-index", &format!(
        "INSERT RELATION INTO calls {{ in: func:{a}, out: func:{b} }} ON DUPLICATE KEY UPDATE seen += 1000 RETURN id, seen; RETURN count(SELECT VALUE id FROM calls);",
        a = node_key("app::main"), b = node_key("app::run"))).await;
    show(&db, "upsert-by-unique-name", &format!(
        "UPSERT func SET name = 'app::run', body = 'fn run(){{}}', content_hash = 1 WHERE name = 'app::run' RETURN id; RETURN count(SELECT VALUE id FROM func); RETURN record::id(func:{}.id);", node_key("app::run"))).await;

    // ---------------- S12 scaled timing (indicative only: opt-level=1, kv-mem, 2 vCPU shared) ----------------
    println!("\n== S12 scaled ingest timing ==");
    scaled(&db).await?;

    Ok(())
}

async fn scaled(db: &Surreal<surrealdb::engine::local::Db>) -> surrealdb::Result<()> {
    use std::time::Instant;
    db.query("DEFINE TABLE n SCHEMAFULL; DEFINE FIELD h ON n TYPE int;
              DEFINE TABLE e TYPE RELATION IN n OUT n ENFORCED SCHEMAFULL;
              DEFINE INDEX e_uniq ON e FIELDS in, out UNIQUE;").await?.check()?;
    const N: usize = 5000;
    const FAN: usize = 3;
    let name = |i: usize| format!("mod{}::f{}", i % 50, i);
    let body = |i: usize, v: u32| format!("body-{i}-v{v}");
    let build = |v_of: &dyn Fn(usize) -> u32| {
        let mut nodes = Vec::with_capacity(N);
        let mut edges = Vec::with_capacity(N * FAN);
        for i in 0..N {
            let k = node_key(&name(i));
            nodes.push(BTreeMap::from([
                ("id".to_string(), RecordId::new("n", k).into_value()),
                ("h".to_string(), content_hash(&body(i, v_of(i))).into_value()),
            ]));
            for f in 1..=FAN {
                let j = (i * 7 + f * 13) % N;
                let kj = node_key(&name(j));
                edges.push(BTreeMap::from([
                    ("id".to_string(), RecordId::new("e", edge_key(k, kj)).into_value()),
                    ("in".to_string(), RecordId::new("n", k).into_value()),
                    ("out".to_string(), RecordId::new("n", kj).into_value()),
                ]));
            }
        }
        (nodes, edges)
    };
    async fn write(db: &Surreal<surrealdb::engine::local::Db>, nodes: Vec<BTreeMap<String, Value>>, edges: Vec<BTreeMap<String, Value>>) -> surrealdb::Result<()> {
        for chunk in nodes.chunks(1000) {
            db.query("INSERT INTO n $rows ON DUPLICATE KEY UPDATE h = $input.h RETURN NONE")
                .bind(("rows", chunk.to_vec())).await?.check()?;
        }
        for chunk in edges.chunks(1000) {
            db.query("INSERT RELATION INTO e $rows ON DUPLICATE KEY UPDATE in = in RETURN NONE")
                .bind(("rows", chunk.to_vec())).await?.check()?;
        }
        Ok(())
    }
    let (nodes, edges) = build(&|_| 0);
    let t = Instant::now();
    write(db, nodes.clone(), edges.clone()).await?;
    println!("  initial ingest {N} nodes + {} edges: {:?}", edges.len(), t.elapsed());
    let t = Instant::now();
    write(db, nodes.clone(), edges.clone()).await?;
    println!("  full idempotent re-ingest (no changes): {:?}", t.elapsed());
    let mut r = db.query("RETURN count(SELECT VALUE id FROM n); RETURN count(SELECT VALUE id FROM e);").await?;
    let cn: Option<i64> = r.take(0)?; let ce: Option<i64> = r.take(1)?;
    println!("  counts after re-ingest: n={cn:?} e={ce:?}");
    // 1% of nodes change
    let (nodes2, _) = build(&|i| if i % 100 == 0 { 1 } else { 0 });
    let manifest: Vec<Value> = nodes2.iter().map(|m| Value::from_t(BTreeMap::from([
        ("id".to_string(), m["id"].clone()), ("h".to_string(), m["h"].clone())]))).collect();
    let t = Instant::now();
    let mut changed: Vec<RecordId> = Vec::new();
    for chunk in manifest.chunks(1000) {
        let mut r = db.query("SELECT VALUE id FROM $m WHERE id.h != h").bind(("m", chunk.to_vec())).await?;
        let c: Vec<RecordId> = r.take(0)?;
        changed.extend(c);
    }
    let d = t.elapsed();
    let t = Instant::now();
    let changed_rows: Vec<BTreeMap<String, Value>> = nodes2.into_iter().filter(|m| changed.iter().any(|c| m["id"] == c.clone().into_value())).collect();
    let nchg = changed_rows.len();
    write(db, changed_rows, vec![]).await?;
    println!("  manifest diff over {N} ids: {d:?} -> {} changed; write only changed ({nchg}): {:?}", changed.len(), t.elapsed());
    // traversal timing: 3-hop fan-out from one node, and transitive closure size
    let start = RecordId::new("n", node_key(&name(0)));
    let t = Instant::now();
    let mut r = db.query("RETURN count(array::distinct($s->e->n->e->n->e->n))").bind(("s", start.clone())).await?;
    let c3: Option<i64> = r.take(0)?;
    println!("  3-hop distinct reach: {c3:?} in {:?}", t.elapsed());
    let t = Instant::now();
    let mut r = db.query("RETURN count($s.{..6+collect}(->e->n))").bind(("s", start)).await?;
    let c6: Option<i64> = r.take(0)?;
    println!("  {{..6+collect}} reach: {c6:?} in {:?}", t.elapsed());
    Ok(())
}

fn id_literal(id: &RecordId) -> String {
    id.clone().into_value().to_sql()
}
