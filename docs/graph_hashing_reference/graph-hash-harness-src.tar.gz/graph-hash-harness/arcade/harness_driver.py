"""Official arcadedb-driver 0.2.0 (HTTP, httpx-based) against the 'codegraph' DB."""
import httpx, xxhash
import arcadedb_driver as ad
from arcadedb_driver import ArcadeDBServer, basic_auth, ArcadeDBError
from harness_http import node_key, content_hash, u64_to_i64

print("arcadedb-driver", ad.__version__)
with ArcadeDBServer(base_url="http://127.0.0.1:2480", auth=basic_auth("root", "arcadepass123"), timeout=httpx.Timeout(30.0)) as srv:
    print("server_info version:", getattr(srv.server_info(), "version", None), "| ready:", srv.ready(), "| dbs:", srv.list_databases())
    db = srv.db("codegraph")
    env = db.query(language="sql", command="SELECT qualname, content_hash FROM CodeNode WHERE key128 = :k",
                   params={"k": node_key("Function", "util.f2")[0]})
    print("driver query ->", env.result, "returned", env.returned, "truncated", env.truncated)
    env = db.query(language="opencypher", command="MATCH (a:Function {qualname:$s})-[:CALLS*1..5]->(b) RETURN DISTINCT b.qualname AS q ORDER BY q", params={"s": "app.f0"})
    print("driver opencypher ->", [r["q"] for r in env.result])
    # transaction context manager; rollback on exception
    try:
        with db.transaction() as tx:
            tx.command(language="sql", command="UPDATE Function SET tmp2 = 1 WHERE qualname = 'app.f0'")
            print("  in-tx read:", tx.query(language="sql", command="SELECT tmp2 FROM Function WHERE qualname='app.f0'").result)
            raise RuntimeError("boom")
    except RuntimeError: pass
    print("driver tx rollback -> tmp2 =", db.query(language="sql", command="SELECT tmp2 FROM Function WHERE qualname='app.f0'").result)
    with db.transaction() as tx:
        tx.command(language="sql", command="UPDATE Function SET content_hash = :h UPSERT WHERE key128 = :k", params={"h": content_hash("drv"), "k": "c" * 32})
    print("driver tx commit -> rows with key c*32:", db.query(language="sql", command="SELECT count(*) AS c FROM Function WHERE key128 = :k", params={"k": "c" * 32}).result)
    db.command(language="sql", command="DELETE FROM Function WHERE key128 = :k", params={"k": "c" * 32})
    try:
        db.command(language="sql", command="INSERT INTO Module SET key128 = :k", params={"k": node_key("Module", "app")[0]})
    except ArcadeDBError as e:
        print("driver duplicate key -> ArcadeDBError:", str(e)[:160])
    # streaming rows (ndjson)
    n = sum(1 for ev in db.query_stream(language="sql", command="SELECT k FROM N LIMIT 5") if getattr(ev, "record", None))
    print("driver query_stream rows:", n)
