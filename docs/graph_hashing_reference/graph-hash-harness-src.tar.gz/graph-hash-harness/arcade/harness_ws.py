"""WebSocket change feed (/ws) as a replacement for timestamp polling; plus server-side hash() availability."""
import base64, json, threading, time
import websocket, xxhash
from harness_http import cmd, query, node_key, content_hash

events = []
tok = base64.b64encode(b"root:arcadepass123").decode()
ws = websocket.create_connection("ws://127.0.0.1:2480/ws", header=[f"Authorization: Basic {tok}"], timeout=10)
ws.send(json.dumps({"action": "subscribe", "database": "codegraph", "type": "Function", "changeTypes": ["update"]}))
print("subscribe ack:", ws.recv())

def reader():
    try:
        while True:
            events.append(json.loads(ws.recv()))
    except Exception:
        pass
th = threading.Thread(target=reader, daemon=True); th.start()

k = node_key("Function", "net.f1")[0]
h = query("SELECT content_hash FROM CodeNode WHERE key128 = :k", {"k": k})[0]["content_hash"]
print("guarded no-op update count:", cmd("UPDATE Function SET content_hash = :h WHERE key128 = :k AND content_hash <> :h", {"h": h, "k": k}))
print("unguarded identical update count:", cmd("UPDATE Function SET content_hash = :h WHERE key128 = :k", {"h": h, "k": k}))
print("real change count:", cmd("UPDATE Function SET content_hash = :h WHERE key128 = :k AND content_hash <> :h", {"h": content_hash("net.f1 v2"), "k": k}))
time.sleep(1.5)
ws.close()
print(f"events received: {len(events)}")
for e in events:
    rec = e.get("record", {})
    print("  ", e.get("changeType"), rec.get("qualname"), rec.get("content_hash"), "| keys:", sorted(e.keys()))

# server-side hash methods available (none is xxh3)
for alg in ("MD5", "SHA-256", "XXH3"):
    try: print(f"'abc'.hash('{alg}') ->", query(f"SELECT 'abc'.hash('{alg}') AS h"))
    except Exception as ex: print(f"'abc'.hash('{alg}') -> ERROR", str(ex)[:160])
