"""ArcadeDB 26.10.1 + python-xxhash harness over the plain HTTP/JSON API (requests).

Run:  python3 harness_http.py   (server on 127.0.0.1:2480, root/arcadepass123)
Every printed line is copied verbatim into the research notes.
"""
import json, struct, sys, time
import requests, xxhash

BASE = "http://127.0.0.1:2480/api/v1"
AUTH = ("root", "arcadepass123")
DB = "codegraph"
S = requests.Session(); S.auth = AUTH


# ---------------------------------------------------------------- HTTP helpers
def server(cmd):
    r = S.post(f"{BASE}/server", json={"command": cmd}); return r.status_code, r.json()

def cmd(sql, params=None, lang="sql", session=None, check=True, **extra):
    body = {"language": lang, "command": sql, **extra}
    if params is not None: body["params"] = params
    h = {"arcadedb-session-id": session} if session else {}
    r = S.post(f"{BASE}/command/{DB}", json=body, headers=h)
    j = r.json()
    if check and r.status_code >= 300:
        raise RuntimeError(f"{r.status_code} {sql[:80]!r}: {j.get('error')} | {j.get('detail','')[:300]}")
    return j if not check else j["result"]

def query(sql, params=None, lang="sql"):
    body = {"language": lang, "command": sql}
    if params is not None: body["params"] = params
    r = S.post(f"{BASE}/query/{DB}", json=body); j = r.json()
    if r.status_code >= 300: raise RuntimeError(f"{r.status_code}: {j}")
    return j["result"]


# ---------------------------------------------------------------- hashing helpers
SEED = 0  # persisted alongside data as hash_alg tag
def u64_to_i64(u: int) -> int:
    """Two's-complement reinterpretation so a u64 digest fits ArcadeDB LONG (signed 64-bit)."""
    return u - (1 << 64) if u >= (1 << 63) else u

def i64_to_u64(i: int) -> int:
    return i + (1 << 64) if i < 0 else i

def canon(*fields) -> bytes:
    """Length-prefixed canonical encoding (u32 LE length + UTF-8 bytes) so ('ab','c') != ('a','bc')."""
    out = bytearray()
    for f in fields:
        b = f if isinstance(f, bytes) else str(f).encode()
        out += struct.pack("<I", len(b)) + b
    return bytes(out)

def node_key(kind, qualname):
    d = canon(b"node-v1", kind, qualname)
    return xxhash.xxh3_128_hexdigest(d), u64_to_i64(xxhash.xxh3_64_intdigest(d))

def content_hash(body: str) -> int:
    return u64_to_i64(xxhash.xxh3_64_intdigest(body.encode()))

def edge_key(src_key128, label, dst_key128):
    return xxhash.xxh3_128_hexdigest(canon(b"edge-v1", src_key128, label, dst_key128))


# ---------------------------------------------------------------- synthetic code graph
def synthetic_graph(version=1):
    mods = ["app", "core", "util", "db", "net", "cli"]
    funcs = {m: [f"{m}.f{i}" for i in range(4)] for m in mods}
    nodes = []
    for m in mods:
        nodes.append(("Module", m, f"module {m} v1"))
        for f in funcs[m]:
            nodes.append(("Function", f, f"def {f}(): pass  # body"))
    if version == 2:  # change exactly one function body
        nodes = [(k, q, (b + " CHANGED") if q == "util.f2" else b) for k, q, b in nodes]
    deps = [("app", "core"), ("app", "cli"), ("cli", "core"), ("core", "util"), ("core", "db"),
            ("db", "util"), ("db", "net"), ("net", "util")]
    edges = []
    for a, b in deps: edges.append(("IMPORTS", a, b))
    for m in mods:
        for f in funcs[m]: edges.append(("DEFINES", m, f))
    calls = [("app.f0", "core.f1"), ("core.f1", "db.f0"), ("db.f0", "net.f3"), ("net.f3", "util.f2"),
             ("core.f1", "util.f2"), ("cli.f0", "core.f1"), ("app.f0", "cli.f0")]
    for a, b in calls: edges.append(("CALLS", a, b))
    return nodes, edges


def main():
    print("server version:", S.get(f"{BASE}/server", params={"mode": "basic"}).json().get("version"))
    st, j = server(f"drop database {DB}") if DB in S.get(f"{BASE}/databases").json()["result"] else (None, None)
    print("create database:", server(f"create database {DB}"))

    # ---------------- schema
    ddl = [
        "CREATE VERTEX TYPE CodeNode IF NOT EXISTS",
        "CREATE PROPERTY CodeNode.key128 IF NOT EXISTS STRING (mandatory true, notnull true, readonly true)",
        "CREATE PROPERTY CodeNode.key64 IF NOT EXISTS LONG",
        "CREATE PROPERTY CodeNode.content_hash IF NOT EXISTS LONG",
        "CREATE PROPERTY CodeNode.kind IF NOT EXISTS STRING",
        "CREATE PROPERTY CodeNode.qualname IF NOT EXISTS STRING",
        "CREATE PROPERTY CodeNode.hash_alg IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON CodeNode (key128) UNIQUE_HASH",
        "CREATE INDEX IF NOT EXISTS ON CodeNode (key64) UNIQUE",
        "CREATE VERTEX TYPE Module IF NOT EXISTS EXTENDS CodeNode",
        "CREATE VERTEX TYPE Function IF NOT EXISTS EXTENDS CodeNode",
        "CREATE EDGE TYPE Dep IF NOT EXISTS",
        "CREATE PROPERTY Dep.ekey IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON Dep (ekey) UNIQUE_HASH",
        "CREATE EDGE TYPE IMPORTS IF NOT EXISTS EXTENDS Dep",
        "CREATE EDGE TYPE DEFINES IF NOT EXISTS EXTENDS Dep",
        "CREATE EDGE TYPE CALLS IF NOT EXISTS EXTENDS Dep",
        "CREATE INDEX IF NOT EXISTS ON IMPORTS (`@out`, `@in`) UNIQUE",
        "CREATE INDEX IF NOT EXISTS ON DEFINES (`@out`, `@in`) UNIQUE",
        "CREATE INDEX IF NOT EXISTS ON CALLS (`@out`, `@in`) UNIQUE",
        # memo/cache keyed by fingerprint
        "CREATE DOCUMENT TYPE Memo IF NOT EXISTS",
        "CREATE PROPERTY Memo.fp IF NOT EXISTS STRING",
        "CREATE INDEX IF NOT EXISTS ON Memo (fp) UNIQUE_HASH",
    ]
    for s in ddl:
        try: cmd(s)
        except RuntimeError as e: print("DDL FAIL", s, "->", e); raise
    idx = query("SELECT name, typeName, properties, `unique`, type FROM schema:indexes ORDER BY name")
    print("indexes:"); [print("  ", r) for r in idx]

    # ---------------- u64 -> signed LONG demonstration
    demo = b"util.f2"
    u = xxhash.xxh3_64_intdigest(demo); i = u64_to_i64(u)
    print(f"xxh3_64({demo!r}) u64={u} hex={xxhash.xxh3_64_hexdigest(demo)} -> signed LONG {i}")
    assert i64_to_u64(i) == u and struct.pack(">q", i) == xxhash.xxh3_64_digest(demo)
    print("  struct.pack('>q', signed) == xxh3_64_digest(): True  (big-endian canonical bytes round-trip)")

    # What happens if you send the raw u64 >= 2**63 as a param into a LONG property?
    big = None
    for n in range(1000):
        cand = xxhash.xxh3_64_intdigest(f"probe{n}".encode())
        if cand >= 1 << 63: big = cand; break
    cmd("CREATE DOCUMENT TYPE Probe IF NOT EXISTS"); cmd("CREATE PROPERTY Probe.h IF NOT EXISTS LONG")
    r = cmd("INSERT INTO Probe SET h = :h", {"h": big}, check=False)
    print(f"raw u64 {big} (>=2^63) into LONG ->", "error:" if "error" in r else "ok:", json.dumps(r)[:300])
    r = cmd("INSERT INTO Probe SET h = :h", {"h": u64_to_i64(big)}, check=False)
    print(f"signed {u64_to_i64(big)} into LONG ->", json.dumps(r.get("result", r))[:200])
    print("  read back:", query("SELECT h FROM Probe"))

    # ---------------- ingestion (idempotent): one sqlscript transaction per batch
    def ingest(version):
        nodes, edges = synthetic_graph(version)
        t0 = time.perf_counter()
        lines = ["BEGIN;"]; params = {}
        for n, (kind, q, body) in enumerate(nodes):
            k128, k64 = node_key(kind, q)
            params.update({f"k{n}": k128, f"s{n}": k64, f"q{n}": q, f"c{n}": content_hash(body)})
            # UPSERT on the UNIQUE_HASH key: atomic insert-or-update.
            lines.append(f"UPDATE {kind} SET key128 = :k{n}, key64 = :s{n}, kind = '{kind}', qualname = :q{n}, "
                         f"content_hash = :c{n}, hash_alg = 'xxh3-v0.8/seed0/canon-v1' UPSERT WHERE key128 = :k{n};")
        keyof = {q: node_key(k, q)[0] for k, q, _ in nodes}
        for m, (label, a, b) in enumerate(edges):
            params.update({f"a{m}": keyof[a], f"b{m}": keyof[b], f"e{m}": edge_key(keyof[a], label, keyof[b])})
            lines.append(f"CREATE EDGE {label} FROM (SELECT FROM CodeNode WHERE key128 = :a{m}) "
                         f"TO (SELECT FROM CodeNode WHERE key128 = :b{m}) IF NOT EXISTS SET ekey = :e{m};")
        lines.append("COMMIT RETRY 3;")
        res = cmd("\n".join(lines), params, lang="sqlscript", check=False)
        dt = (time.perf_counter() - t0) * 1000
        return res, dt, len(nodes), len(edges)

    def counts():
        return {t: query(f"SELECT count(*) AS c FROM {t}")[0]["c"] for t in ("CodeNode", "Module", "Function", "Dep", "IMPORTS", "DEFINES", "CALLS")}

    res, dt, nn, ne = ingest(1)
    print(f"ingest#1: {nn} nodes {ne} edges in {dt:.1f} ms; error={res.get('error')}; counts={counts()}")
    res, dt, nn, ne = ingest(1)
    print(f"ingest#2 (identical): {dt:.1f} ms; error={res.get('error')}; counts={counts()}")

    # direct duplicate attempts — what do the constraints do?
    a, b = node_key("Module", "app")[0], node_key("Module", "core")[0]
    r = cmd("CREATE EDGE IMPORTS FROM (SELECT FROM CodeNode WHERE key128 = :a) TO (SELECT FROM CodeNode WHERE key128 = :b)",
            {"a": a, "b": b}, check=False)
    print("plain CREATE EDGE duplicate (no IF NOT EXISTS) ->", (r.get("error") or "") , "|", (r.get("detail") or "")[:160])
    r = cmd("CREATE EDGE IMPORTS FROM (SELECT FROM CodeNode WHERE key128 = :a) TO (SELECT FROM CodeNode WHERE key128 = :b) IF NOT EXISTS",
            {"a": a, "b": b}, check=False)
    print("CREATE EDGE ... IF NOT EXISTS duplicate ->", json.dumps(r.get("result"))[:200], "count IMPORTS =", counts()["IMPORTS"])
    r = cmd("INSERT INTO Module SET key128 = :k, qualname = 'dup'", {"k": a}, check=False)
    print("INSERT duplicate key128 ->", r.get("error"), "|", (r.get("detail") or "")[:200])

    # ---------------- change detection: compute local fingerprints, ask DB which differ
    nodes2, _ = synthetic_graph(2)
    local = {node_key(k, q)[0]: content_hash(b) for k, q, b in nodes2}
    stored = {r["key128"]: r["content_hash"] for r in query("SELECT key128, content_hash FROM CodeNode")}
    changed = [k for k, h in local.items() if stored.get(k) != h]
    print("client-side diff: changed keys =", changed, "=> qualnames", [r["qualname"] for r in query("SELECT qualname FROM CodeNode WHERE key128 IN :ks", {"ks": changed})])

    # server-side variant: send (key, hash) pairs, DB returns mismatches
    pairs = [{"k": k, "h": h} for k, h in local.items()]
    t0 = time.perf_counter()
    rows = query("SELECT key128, qualname, content_hash FROM CodeNode WHERE key128 IN :ks AND content_hash NOT IN :hs",
                 {"ks": list(local), "hs": list(local.values())})
    print(f"server-side NOT IN filter -> {[r['qualname'] for r in rows]} ({(time.perf_counter()-t0)*1000:.1f} ms)")

    # Re-ingest v2 with RETURN BEFORE to observe exactly what changed
    res, dt, nn, ne = ingest(2)
    print(f"ingest v2: {dt:.1f} ms error={res.get('error')} counts={counts()}")
    print("  util.f2 content_hash now:", query("SELECT qualname, content_hash FROM CodeNode WHERE qualname = 'util.f2'"))

    # ---------------- upstream impact: who (transitively) depends on the changed node?
    rows = query("""SELECT qualname, $depth AS depth FROM (
                      TRAVERSE in('CALLS') FROM (SELECT FROM Function WHERE qualname = 'util.f2') MAXDEPTH 10)
                    ORDER BY depth, qualname""")
    print("TRAVERSE in('CALLS') from util.f2 (impacted callers):", [(r["qualname"], r["depth"]) for r in rows])

    rows = query("""MATCH {type: Function, as: f, where: (qualname = 'app.f0')}
                     .out('CALLS'){as: g, while: ($depth < 5)} RETURN DISTINCT g.qualname AS q ORDER BY q""")
    print("MATCH out('CALLS') while depth<5 from app.f0:", [r["q"] for r in rows])

    rows = query("""SELECT qualname FROM (SELECT expand(out('IMPORTS').out('IMPORTS')) FROM Module WHERE qualname = 'app')""")
    print("2-hop out('IMPORTS').out('IMPORTS') from app:", sorted(r["qualname"] for r in rows))

    # shortestPath by key lookup -> RIDs -> qualnames
    sp = query("""SELECT shortestPath((SELECT FROM CodeNode WHERE key128 = :a), (SELECT FROM CodeNode WHERE key128 = :b), 'OUT', 'CALLS') AS p""",
               {"a": node_key("Function", "app.f0")[0], "b": node_key("Function", "util.f2")[0]})
    print("shortestPath(app.f0 -> util.f2, OUT, CALLS) raw:", sp)
    rids = sp[0]["p"]
    names = {r["@rid"]: r["qualname"] for r in query("SELECT @rid, qualname FROM CodeNode WHERE @rid IN :r", {"r": rids})}
    print("   as qualnames:", [names.get(x) for x in rids])
    sp_both = query("SELECT shortestPath((SELECT FROM Module WHERE qualname='net'), (SELECT FROM Module WHERE qualname='cli')) AS p")
    sp_out = query("SELECT shortestPath((SELECT FROM Module WHERE qualname='net'), (SELECT FROM Module WHERE qualname='cli'), 'OUT') AS p")
    print("default-direction probe net->cli: no-dir =", sp_both[0]["p"], "| OUT =", sp_out[0]["p"])

    # dijkstra with weights
    cmd("UPDATE CALLS SET w = 1"); cmd("UPDATE CALLS SET w = 10 WHERE @out.qualname = 'core.f1' AND @in.qualname = 'util.f2'")
    dj = query("""SELECT dijkstra((SELECT FROM Function WHERE qualname='core.f1'), (SELECT FROM Function WHERE qualname='util.f2'), 'w', 'OUT') AS p""")
    print("dijkstra(core.f1 -> util.f2, w) :", [names.get(x, x) for x in dj[0]["p"]] if dj and dj[0].get("p") else dj)
    rows = query("SELECT @rid, qualname FROM CodeNode"); names = {r["@rid"]: r["qualname"] for r in rows}
    print("   names:", [names.get(x) for x in dj[0]["p"]])

    # Cypher (native opencypher) on the same data
    rows = query("MATCH p = shortestPath((a:Function {qualname:'app.f0'})-[:CALLS*]->(b:Function {qualname:'util.f2'})) RETURN [n IN nodes(p) | n.qualname] AS path", lang="opencypher")
    print("opencypher shortestPath:", rows)
    rows = query("CALL algo.topologicalSort('IMPORTS') YIELD node, order RETURN node.qualname AS m, order ORDER BY order", lang="opencypher")
    print("algo.topologicalSort('IMPORTS'):", [(r["m"], r["order"]) for r in rows])
    rows = query("CALL algo.cycleDetection('IMPORTS') YIELD node, inCycle, hasCycle RETURN hasCycle, count(*) AS n", lang="opencypher")
    print("algo.cycleDetection('IMPORTS'):", rows)
    rows = query("CALL algo.pagerank() YIELD node, score RETURN node.qualname AS q, score ORDER BY score DESC LIMIT 3", lang="opencypher")
    print("algo.pagerank top3:", [(r["q"], round(r["score"], 4)) for r in rows])

    # Cypher MERGE idempotency on the hash key
    for _ in range(2):
        r = cmd("MERGE (n:Function {key128:$k}) ON CREATE SET n.qualname = 'merged.fn' RETURN n.qualname AS q",
                {"k": "f" * 32}, lang="opencypher", check=False)
    print("opencypher MERGE x2 ->", r.get("result"), "stats", {k: v for k, v in (r.get("stats") or {}).items() if v}, "| count merged.fn =",
          query("SELECT count(*) AS c FROM Function WHERE qualname='merged.fn'")[0]["c"])
    r1 = cmd("MATCH (a:Module {qualname:'app'}),(b:Module {qualname:'core'}) MERGE (a)-[r:IMPORTS]->(b) RETURN count(r) AS c", lang="opencypher", check=False)
    print("opencypher MERGE existing edge ->", r1.get("result"), "stats", {k: v for k, v in (r1.get("stats") or {}).items() if v}, "| IMPORTS count", counts()["IMPORTS"])

    # ---------------- memo / cache vertex keyed by fingerprint (inputs' content hashes)
    def fingerprint(target):
        rows = query("""SELECT key128, content_hash FROM (TRAVERSE out('CALLS') FROM (SELECT FROM Function WHERE qualname = :t))
                        ORDER BY key128""", {"t": target})
        h = xxhash.xxh3_128()
        for r in rows: h.update(canon(r["key128"], str(r["content_hash"])))
        return h.hexdigest(), len(rows)

    fp, n = fingerprint("core.f1")
    hit = query("SELECT result FROM Memo WHERE fp = :fp", {"fp": fp})
    print(f"memo fp(core.f1 closure, {n} nodes) = {fp} hit={bool(hit)}")
    cmd("UPDATE Memo SET fp = :fp, result = 'expensive-analysis-output' UPSERT WHERE fp = :fp", {"fp": fp})
    print("  second lookup hit =", bool(query("SELECT result FROM Memo WHERE fp = :fp", {"fp": fp})))

    # EXPLAIN shows index use for key lookups
    plan = S.post(f"{BASE}/query/{DB}", json={"language": "sql", "command": "EXPLAIN SELECT FROM CodeNode WHERE key128 = 'x'"}).json()
    print("EXPLAIN key128 lookup:\n" + "\n".join("   " + l for l in plan.get("explain", "").splitlines()))
    plan = S.post(f"{BASE}/query/{DB}", json={"language": "sql", "command": "EXPLAIN SELECT FROM CodeNode WHERE key64 > 0 ORDER BY key64 LIMIT 3"}).json()
    print("EXPLAIN key64 range:\n" + "\n".join("   " + l for l in plan.get("explain", "").splitlines()))

    # signed sort order vs unsigned
    rows = query("SELECT qualname, key64 FROM CodeNode WHERE key64 IS NOT NULL ORDER BY key64 LIMIT 4")
    print("ORDER BY key64 (signed) first 4:", [(r["qualname"], r["key64"], f"{i64_to_u64(r['key64']):016x}") for r in rows])

    # ---------------- explicit HTTP session transaction (begin/commit) + rollback
    rb = S.post(f"{BASE}/begin/{DB}"); sid = rb.headers.get("arcadedb-session-id")
    print("begin ->", rb.status_code, "session", sid)
    cmd("UPDATE Function SET content_hash = 0 WHERE qualname = 'app.f0'", session=sid)
    inside = S.post(f"{BASE}/command/{DB}", json={"language": "sql", "command": "SELECT content_hash FROM Function WHERE qualname='app.f0'"},
                    headers={"arcadedb-session-id": sid}).json()["result"]
    outside = query("SELECT content_hash FROM Function WHERE qualname='app.f0'")
    rr = S.post(f"{BASE}/rollback/{DB}", headers={"arcadedb-session-id": sid})
    print(f"  inside tx={inside} outside tx={outside} rollback -> {rr.status_code}; after: {query('SELECT content_hash FROM Function WHERE qualname=' + chr(39) + 'app.f0' + chr(39))}")

    # X-Request-Id replay protection
    hdr = {"X-Request-Id": "ingest-batch-42"}
    body = {"language": "sql", "command": "INSERT INTO Probe SET h = 7"}
    r1 = S.post(f"{BASE}/command/{DB}", json=body, headers=hdr); r2 = S.post(f"{BASE}/command/{DB}", json=body, headers=hdr)
    print("X-Request-Id replay: statuses", r1.status_code, r2.status_code, "replay-protection hdr", r1.headers.get("X-ArcadeDB-Replay-Protection"),
          "| Probe h=7 rows:", query("SELECT count(*) AS c FROM Probe WHERE h = 7")[0]["c"])

    print("final counts:", counts())


if __name__ == "__main__":
    main()
