"""Follow-up checks on the 'codegraph' DB created by harness_http.py (run that first)."""
import json, threading, time, struct, random
import requests, xxhash
from harness_http import BASE, AUTH, DB, S, cmd, query, node_key, content_hash, canon, u64_to_i64, synthetic_graph

def show(label, v): print(f"{label}: {json.dumps(v, default=str)[:600]}")

# 1. schema:indexes full record (which field carries the algorithm?)
rec = query("SELECT FROM schema:indexes WHERE name = 'CodeNode[key128]'")
show("schema:indexes CodeNode[key128]", rec)
rec = query("SELECT FROM schema:indexes WHERE name = 'CodeNode[key64]'")
show("schema:indexes CodeNode[key64]", rec)

# 2. ArcadeDB has no per-record @version (MVCC is page-versioned) -> what does an identical UPSERT report?
k = node_key("Function", "db.f1")[0]
h = query("SELECT content_hash FROM CodeNode WHERE key128 = :k", {"k": k})[0]["content_hash"]
r_up = cmd("UPDATE Function SET content_hash = :h UPSERT WHERE key128 = :k", {"h": h, "k": k})
r_guard = cmd("UPDATE Function SET content_hash = :h WHERE key128 = :k AND content_hash <> :h", {"h": h, "k": k})
r_guard2 = cmd("UPDATE Function SET content_hash = :h WHERE key128 = :k AND content_hash <> :h", {"h": h + 1, "k": k})
cmd("UPDATE Function SET content_hash = :h WHERE key128 = :k", {"h": h, "k": k})
print(f"identical UPSERT result={r_up}; guarded UPDATE same hash result={r_guard}; guarded UPDATE new hash result={r_guard2}")

# 3. Correct pairwise diff, two ways
nodes2, _ = synthetic_graph(2)
pairs = [{"k": node_key(kd, q)[0], "h": content_hash(b)} for kd, q, b in nodes2]
pairs[0]["h"] = 12345  # simulate a second local change (app module)
rows = query("UNWIND $pairs AS p MATCH (n:CodeNode {key128: p.k}) WHERE n.content_hash <> p.h RETURN n.qualname AS q ORDER BY q",
             {"pairs": pairs}, lang="opencypher")
show("opencypher UNWIND pairwise diff", rows)
# guarded update that both detects and applies, returning only touched rows
script = ["BEGIN;"]; params = {}
for i, p in enumerate(pairs):
    params[f"k{i}"], params[f"h{i}"] = p["k"], p["h"]
    script.append(f"UPDATE CodeNode SET content_hash = :h{i} RETURN AFTER qualname WHERE key128 = :k{i} AND content_hash <> :h{i};")
script.append("COMMIT;")
res = cmd("\n".join(script), params, lang="sqlscript", check=False)
show("sqlscript guarded UPDATE ... RETURN AFTER (last statement result only?)", res.get("result", res))
# Revert app's hash to the real value so later tests are sane
cmd("UPDATE CodeNode SET content_hash = :h WHERE key128 = :k", {"h": content_hash("module app v1"), "k": node_key("Module", "app")[0]})

# per-statement guarded UPDATE with RETURN COUNT (default) – count tells changed vs unchanged
r_same = cmd("UPDATE CodeNode SET content_hash = :h WHERE key128 = :k AND content_hash <> :h", {"h": content_hash("module app v1"), "k": node_key("Module", "app")[0]})
show("guarded UPDATE unchanged -> result", r_same)

# 4. Stale-node removal: anything not in the current key set
keys = [p["k"] for p in pairs]
r = cmd("DELETE FROM CodeNode WHERE key128 NOT IN :ks", {"ks": keys})
show("DELETE FROM CodeNode WHERE key128 NOT IN current keys (removes the MERGE test node)", r)
print("  Dep edges after delete:", query("SELECT count(*) AS c FROM Dep")[0]["c"], " CodeNode:", query("SELECT count(*) AS c FROM CodeNode")[0]["c"])

# 5. Edge dedup by content-derived ekey on the supertype index, independent of (@out,@in)
a, b = node_key("Module", "app")[0], node_key("Module", "net")[0]
from harness_http import edge_key
ek = edge_key(a, "IMPORTS", b)
for i in range(2):
    r = cmd("CREATE EDGE IMPORTS FROM (SELECT FROM CodeNode WHERE key128 = :a) TO (SELECT FROM CodeNode WHERE key128 = :b) IF NOT EXISTS SET ekey = :e",
            {"a": a, "b": b, "e": ek}, check=False)
print("IF NOT EXISTS x2 new edge app->net; IMPORTS count:", query("SELECT count(*) AS c FROM IMPORTS")[0]["c"],
      "| lookup by ekey:", query("SELECT @out.qualname AS s, @in.qualname AS d FROM Dep WHERE ekey = :e", {"e": ek}))
plan = S.post(f"{BASE}/query/{DB}", json={"language": "sql", "command": f"EXPLAIN SELECT FROM Dep WHERE ekey = '{ek}'"}).json()
print("EXPLAIN Dep ekey lookup:", " | ".join(l.strip() for l in plan.get("explain", "").splitlines()))
# IF NOT EXISTS without a UNIQUE (@out,@in) index: does it still dedup? (non-atomic check)
cmd("CREATE EDGE TYPE LINK IF NOT EXISTS")
for i in range(2):
    cmd("CREATE EDGE LINK FROM (SELECT FROM Module WHERE qualname='app') TO (SELECT FROM Module WHERE qualname='util') IF NOT EXISTS")
print("LINK (no unique index) IF NOT EXISTS x2 ->", query("SELECT count(*) AS c FROM LINK")[0]["c"])

# 6. Concurrency: 4 threads UPSERT the same 50 keys 3 times each via /command (autocommit) -> duplicates?
cmd("CREATE VERTEX TYPE Blob IF NOT EXISTS"); cmd("CREATE PROPERTY Blob.k IF NOT EXISTS STRING")
cmd("CREATE INDEX IF NOT EXISTS ON Blob (k) UNIQUE_HASH")
cmd("CREATE VERTEX TYPE BlobNoIdx IF NOT EXISTS"); cmd("CREATE PROPERTY BlobNoIdx.k IF NOT EXISTS STRING")
errs = {"Blob": [], "BlobNoIdx": []}
def worker(t, typ):
    s = requests.Session(); s.auth = AUTH
    for rep in range(3):
        for i in range(50):
            kk = xxhash.xxh3_128_hexdigest(f"blob{i}".encode())
            body = {"language": "sql", "command": f"UPDATE {typ} SET k = :k, w = :w UPSERT WHERE k = :k", "params": {"k": kk, "w": t}}
            r = s.post(f"{BASE}/command/{DB}", json=body)
            if r.status_code != 200: errs[typ].append(r.json().get("error"))
for typ in ("Blob",):
    ths = [threading.Thread(target=worker, args=(t, typ)) for t in range(4)]
    t0 = time.perf_counter(); [x.start() for x in ths]; [x.join() for x in ths]
    print(f"concurrent UPSERT {typ}: rows={query(f'SELECT count(*) AS c FROM {typ}')[0]['c']} (expected 50), "
          f"distinct k={query(f'SELECT count(DISTINCT k) AS c FROM {typ}')[0]['c']}, errors={len(errs[typ])} {set(errs[typ])}, {(time.perf_counter()-t0):.2f}s")
r = cmd("UPDATE BlobNoIdx SET k = 'x' UPSERT WHERE k = 'x'", check=False)
print("UPSERT without UNIQUE index ->", r.get("error"), "|", (r.get("detail") or "")[:160])

# 7. /api/v1/batch JSONL bulk load vs UNIQUE index
lines = [json.dumps({"@type": "vertex", "@class": "Blob", "@id": "t1", "k": xxhash.xxh3_128_hexdigest(b"blob0")}),
         json.dumps({"@type": "vertex", "@class": "Blob", "@id": "t2", "k": "new-unique-key"})]
r = S.post(f"{BASE}/batch/{DB}", data="\n".join(lines) + "\n", headers={"Content-Type": "application/x-ndjson"})
print("batch JSONL with one duplicate key ->", r.status_code, json.dumps(r.json())[:300], "| Blob rows:", query("SELECT count(*) AS c FROM Blob")[0]["c"])

# 8. X-Request-Id headers verbatim
hdr = {"X-Request-Id": f"req-{random.random()}"}
r1 = S.post(f"{BASE}/command/{DB}", json={"language": "sql", "command": "INSERT INTO Probe SET h = 99"}, headers=hdr)
r2 = S.post(f"{BASE}/command/{DB}", json={"language": "sql", "command": "INSERT INTO Probe SET h = 99"}, headers=hdr)
print("X-Request-Id: r1 hdrs", {k: v for k, v in r1.headers.items() if k.lower().startswith("x-")})
print("              r2 hdrs", {k: v for k, v in r2.headers.items() if k.lower().startswith("x-")}, "| rows h=99:", query("SELECT count(*) AS c FROM Probe WHERE h = 99")[0]["c"])

# 9. Scale probe: 20k nodes / ~60k edges upsert in 2k-statement sqlscript chunks; then idempotent re-run
N = 20000
cmd("CREATE VERTEX TYPE N IF NOT EXISTS"); cmd("CREATE PROPERTY N.k IF NOT EXISTS STRING"); cmd("CREATE PROPERTY N.c IF NOT EXISTS LONG")
cmd("CREATE INDEX IF NOT EXISTS ON N (k) UNIQUE_HASH")
cmd("CREATE EDGE TYPE NE IF NOT EXISTS"); cmd("CREATE INDEX IF NOT EXISTS ON NE (`@out`, `@in`) UNIQUE")
rng = random.Random(7)
keys = [xxhash.xxh3_128_hexdigest(struct.pack("<Q", i)) for i in range(N)]
edges = sorted({(i, rng.randrange(max(0, i - 500), i)) for i in range(1, N) for _ in range(3)})
def upsert_nodes(content_salt):
    t0 = time.perf_counter()
    for off in range(0, N, 2000):
        rows = [{"k": keys[i], "c": u64_to_i64(xxhash.xxh3_64_intdigest(f"{i}{content_salt if i % 1000 == 0 else ''}".encode()))} for i in range(off, min(N, off + 2000))]
        # one parameterised statement per chunk: UNWIND-style via opencypher MERGE
        cmd("UNWIND $rows AS r MERGE (n:N {k: r.k}) SET n.c = r.c", {"rows": rows}, lang="opencypher")
    return time.perf_counter() - t0
def upsert_edges():
    t0 = time.perf_counter()
    for off in range(0, len(edges), 3000):
        rows = [{"a": keys[a], "b": keys[b]} for a, b in edges[off:off + 3000]]
        cmd("UNWIND $rows AS r MATCH (a:N {k: r.a}), (b:N {k: r.b}) MERGE (a)-[:NE]->(b)", {"rows": rows}, lang="opencypher")
    return time.perf_counter() - t0
t_n1 = upsert_nodes(""); t_e1 = upsert_edges()
print(f"scale: initial {N} nodes {t_n1:.2f}s, {len(edges)} edges {t_e1:.2f}s -> N={query('SELECT count(*) AS c FROM N')[0]['c']} NE={query('SELECT count(*) AS c FROM NE')[0]['c']}")
t_n2 = upsert_nodes(""); t_e2 = upsert_edges()
print(f"scale: idempotent re-run nodes {t_n2:.2f}s edges {t_e2:.2f}s -> N={query('SELECT count(*) AS c FROM N')[0]['c']} NE={query('SELECT count(*) AS c FROM NE')[0]['c']}")
# point-lookup latency by hash key
t0 = time.perf_counter()
for i in range(0, N, 100): query("SELECT c FROM N WHERE k = :k", {"k": keys[i]})
print(f"scale: 200 HTTP point lookups by key128 avg {(time.perf_counter()-t0)/200*1000:.2f} ms each (includes HTTP round trip)")
# changed-set detection over 20k with only 20 changed (salt every 1000th)
local = [{"k": keys[i], "h": u64_to_i64(xxhash.xxh3_64_intdigest(f"{i}{'v2' if i % 1000 == 0 else ''}".encode()))} for i in range(N)]
t0 = time.perf_counter(); changed = []
for off in range(0, N, 5000):
    changed += query("UNWIND $p AS p MATCH (n:N {k: p.k}) WHERE n.c <> p.h RETURN n.k AS k", {"p": local[off:off + 5000]}, lang="opencypher")
print(f"scale: pairwise diff of {N} (key,hash) pairs -> {len(changed)} changed in {(time.perf_counter()-t0):.2f}s")
t0 = time.perf_counter()
r = query("SELECT count(*) AS c FROM (TRAVERSE out('NE') FROM (SELECT FROM N WHERE k = :k) MAXDEPTH 6)", {"k": keys[N - 1]})
print(f"scale: TRAVERSE out('NE') depth<=6 from last node -> {r[0]['c']} vertices in {(time.perf_counter()-t0)*1000:.1f} ms")
t0 = time.perf_counter()
r = query("SELECT shortestPath((SELECT FROM N WHERE k = :a), (SELECT FROM N WHERE k = :b), 'OUT', 'NE') AS p", {"a": keys[N - 1], "b": keys[0]})
print(f"scale: shortestPath last->first len={len(r[0]['p'])} in {(time.perf_counter()-t0)*1000:.1f} ms")
t0 = time.perf_counter()
r = query("CALL algo.wcc('NE') YIELD node, componentId RETURN count(DISTINCT componentId) AS comps", lang="opencypher")
print(f"scale: algo.wcc('NE') -> {r} in {(time.perf_counter()-t0)*1000:.1f} ms")
t0 = time.perf_counter()
r = query("CALL algo.pagerank({relTypes:'NE'}) YIELD node, score RETURN max(score) AS mx", lang="opencypher")
print(f"scale: algo.pagerank(NE) -> {r} in {(time.perf_counter()-t0)*1000:.1f} ms")
