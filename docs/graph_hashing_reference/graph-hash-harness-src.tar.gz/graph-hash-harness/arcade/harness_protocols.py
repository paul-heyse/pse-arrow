"""psycopg (Postgres wire, port 5432) and neo4j (Bolt, port 7687) against the 'codegraph' DB."""
import json, time, xxhash
import psycopg, neo4j
from harness_http import node_key, content_hash, u64_to_i64

print("psycopg", psycopg.__version__, "| neo4j driver", neo4j.__version__)

# ------------------------------------------------------------------ psycopg
t0 = time.perf_counter()
conn = psycopg.connect(host="127.0.0.1", port=5432, dbname="codegraph", user="root", password="arcadepass123", autocommit=True)
print(f"psycopg connect ok in {(time.perf_counter()-t0)*1000:.0f} ms; server_version param:", conn.info.parameter_status("server_version"))
with conn.cursor() as cur:
    k = node_key("Function", "util.f2")[0]
    cur.execute("SELECT qualname, key64, content_hash FROM CodeNode WHERE key128 = %s", (k,))
    row = cur.fetchone(); print("psycopg param lookup ->", row, "| col types:", [(c.name, c.type_code) for c in cur.description])
    cur.execute("SELECT shortestPath((SELECT FROM Function WHERE qualname='app.f0'), (SELECT FROM Function WHERE qualname='util.f2'), 'OUT', 'CALLS') AS p")
    print("psycopg shortestPath ->", cur.fetchall())
    cur.execute("{opencypher} MATCH (a:Module {qualname:'app'})-[:IMPORTS*1..3]->(m) RETURN DISTINCT m.qualname AS q ORDER BY q")
    print("psycopg {opencypher} var-length ->", cur.fetchall())
    # u64 >= 2^63 through psycopg: psycopg sends Python int > int8 range as numeric
    big = 17318697568785992647
    try:
        cur.execute("INSERT INTO Probe SET h = %s", (big,)); print("psycopg raw u64 insert ->", cur.statusmessage)
    except Exception as e: print("psycopg raw u64 insert -> ERROR", type(e).__name__, str(e)[:200])
    cur.execute("INSERT INTO Probe SET h = %s", (u64_to_i64(big),)); print("psycopg signed insert ->", cur.statusmessage)
    # UPSERT via psycopg
    cur.execute("UPDATE Function SET content_hash = %s UPSERT WHERE key128 = %s", (content_hash("x"), "a" * 32))
    print("psycopg UPSERT ->", cur.statusmessage, cur.rowcount)
    cur.execute("DELETE FROM Function WHERE key128 = %s", ("a" * 32,))

# explicit transaction over pg wire
conn2 = psycopg.connect(host="127.0.0.1", port=5432, dbname="codegraph", user="root", password="arcadepass123")
try:
    with conn2.transaction():
        with conn2.cursor() as cur:
            cur.execute("UPDATE Function SET tmp = 1 WHERE qualname = 'app.f0'")
            raise RuntimeError("force rollback")
except RuntimeError: pass
with conn2.cursor() as cur:
    cur.execute("SELECT tmp FROM Function WHERE qualname = 'app.f0'"); print("psycopg transaction() rollback -> tmp =", cur.fetchall())
conn2.close(); conn.close()

# ------------------------------------------------------------------ neo4j / Bolt
drv = neo4j.GraphDatabase.driver("bolt://127.0.0.1:7687", auth=("root", "arcadepass123"))
with drv.session(database="codegraph") as s:
    rec = s.run("MATCH (f:Function {key128: $k}) RETURN f.qualname AS q, f.key64 AS k64", k=node_key("Function", "util.f2")[0]).single()
    print("bolt param lookup ->", dict(rec))
    rows = s.run("MATCH p = shortestPath((a:Function {qualname:'app.f0'})-[:CALLS*]->(b:Function {qualname:'util.f2'})) RETURN [n IN nodes(p) | n.qualname] AS path").data()
    print("bolt shortestPath ->", rows)
    res = s.run("UNWIND $rows AS r MERGE (n:Function {key128: r.k}) ON CREATE SET n.qualname = r.q RETURN count(n) AS c",
                rows=[{"k": "b" * 32, "q": "bolt.tmp"}, {"k": "b" * 32, "q": "bolt.tmp"}]).consume()
    print("bolt UNWIND MERGE same key twice -> nodes_created", res.counters.nodes_created)
    s.run("MATCH (n:Function {key128: $k}) DETACH DELETE n", k="b" * 32).consume()
    try:
        s.run("CREATE (n:Probe2 {h: $h})", h=17318697568785992647).consume(); print("bolt raw u64 -> accepted?!")
    except Exception as e: print("bolt raw u64 param -> client error", type(e).__name__, str(e)[:120])
    def tx_fn(tx):
        return tx.run("MATCH (a:Module) RETURN count(a) AS c").single()["c"]
    print("bolt execute_read managed tx ->", s.execute_read(tx_fn))
drv.close()
