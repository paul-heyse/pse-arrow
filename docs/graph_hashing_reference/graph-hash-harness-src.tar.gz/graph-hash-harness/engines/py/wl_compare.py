"""Time networkx.weisfeiler_lehman_graph_hash on the graph exported by `wl_hash` and a pure-Python
xxh3 equivalent of the Rust algorithm. Run from the engines dir:
    python3 -I py/wl_compare.py results/wl_small.edges 20000 3 5
"""
import statistics, sys, time, warnings
import networkx as nx
import xxhash

path, n, iters, reps = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
G = nx.Graph(); G.add_nodes_from(range(n))  # keep isolated nodes, as the Rust CSR does
G.add_edges_from(tuple(map(int, l.split())) for l in open(path))
warnings.simplefilter("ignore")  # networkx 3.5+ warns that attribute-less hashes changed

def timed(f):
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter(); out = f(); ts.append((time.perf_counter() - t0) * 1e3)
    return statistics.median(ts), out

ms_nx, h_nx = timed(lambda: nx.weisfeiler_lehman_graph_hash(G, iterations=iters))

# Python port of the Rust algorithm: integer labels, xxh3_64 over packed little-endian u64s
adj = {v: list(G.neighbors(v)) for v in G}
def wl_xxh3():
    lab = {v: xxhash.xxh3_64_intdigest(len(adj[v]).to_bytes(8, "little")) for v in adj}
    for _ in range(iters):
        lab = {v: xxhash.xxh3_64_intdigest(b"".join(x.to_bytes(8, "little") for x in [lab[v]] + sorted(lab[w] for w in adj[v]))) for v in adj}
    return xxhash.xxh3_64_hexdigest(b"".join(x.to_bytes(8, "little") for x in sorted(lab.values())))
ms_xx, h_xx = timed(wl_xxh3)
print(f"| implementation | ms (median of {reps}) | hash |")
print("|---|---:|---|")
print(f"| networkx {nx.__version__} weisfeiler_lehman_graph_hash (blake2b, string labels), iterations={iters} | {ms_nx:.0f} | {h_nx} |")
print(f"| pure-Python xxh3_64 port of the Rust `wl_graph_hash(.., all_iters=false)` (python-xxhash {xxhash.VERSION}) | {ms_xx:.0f} | {h_xx} |")
print(f"> graph: n={G.number_of_nodes()} m={G.number_of_edges()}")

# Does the hash function matter inside networkx? Swap blake2b for xxh3_128 in the module-level helper.
import networkx.algorithms.graph_hashing as gh
orig = gh._hash_label
gh._hash_label = lambda label, digest_size: xxhash.xxh3_128_hexdigest(label.encode("ascii"))
ms_nx_xx, _ = timed(lambda: nx.weisfeiler_lehman_graph_hash(G, iterations=iters))
gh._hash_label = orig
labels = []  # cost of the hash calls alone, on networkx-style label strings of this graph
deg = {v: str(len(adj[v])) for v in adj}
labels = [deg[v] + "".join(sorted(deg[w] for w in adj[v])) for v in adj]
from hashlib import blake2b
ms_b2, _ = timed(lambda: [blake2b(s.encode("ascii"), digest_size=16).hexdigest() for s in labels])
ms_x3, _ = timed(lambda: [xxhash.xxh3_128_hexdigest(s.encode("ascii")) for s in labels])
print(f"| networkx with `_hash_label` patched to xxh3_128 | {ms_nx_xx:.0f} | (different values) |")
print(f"> hash calls alone over {len(labels)} first-iteration label strings: blake2b {ms_b2:.1f} ms, xxh3_128 {ms_x3:.1f} ms")
