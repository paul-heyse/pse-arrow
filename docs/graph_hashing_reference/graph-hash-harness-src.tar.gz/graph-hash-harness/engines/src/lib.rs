//! Shared helpers for the engines prototypes: deterministic RNG, timing, CLI args,
//! machine banner and a byte-counting global allocator.

pub mod util {
    use std::time::Instant;

    /// SplitMix64 — tiny, deterministic, good enough for synthetic workloads.
    #[derive(Clone, Debug)]
    pub struct Rng(u64);
    impl Rng {
        pub fn new(seed: u64) -> Self { Rng(seed) }
        #[inline]
        pub fn next_u64(&mut self) -> u64 {
            self.0 = self.0.wrapping_add(0x9E37_79B9_7F4A_7C15);
            let mut z = self.0;
            z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
            z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
            z ^ (z >> 31)
        }
        /// Uniform in [0, n).
        #[inline]
        pub fn below(&mut self, n: usize) -> usize { ((self.next_u64() as u128 * n as u128) >> 64) as usize }
        #[inline]
        pub fn chance(&mut self, p: f64) -> bool { ((self.next_u64() >> 11) as f64) * (1.0 / (1u64 << 53) as f64) < p }
        pub fn shuffle<T>(&mut self, v: &mut [T]) {
            for i in (1..v.len()).rev() { let j = self.below(i + 1); v.swap(i, j); }
        }
    }

    pub fn median(mut v: Vec<f64>) -> f64 {
        v.sort_by(|a, b| a.partial_cmp(b).unwrap());
        let n = v.len();
        if n == 0 { return f64::NAN; }
        if n % 2 == 1 { v[n / 2] } else { (v[n / 2 - 1] + v[n / 2]) / 2.0 }
    }

    pub fn percentile(mut v: Vec<f64>, p: f64) -> f64 {
        v.sort_by(|a, b| a.partial_cmp(b).unwrap());
        if v.is_empty() { return f64::NAN; }
        let idx = ((v.len() - 1) as f64 * p).round() as usize;
        v[idx]
    }

    /// Run `setup()` (untimed) then `f(state)` (timed), `reps` times. Returns (median ms, last output).
    pub fn bench_setup<S, T>(reps: usize, mut setup: impl FnMut() -> S, mut f: impl FnMut(S) -> T) -> (f64, T) {
        let mut times = Vec::with_capacity(reps);
        let mut last = None;
        for _ in 0..reps.max(1) {
            let s = setup();
            let t0 = Instant::now();
            let out = f(s);
            times.push(t0.elapsed().as_secs_f64() * 1e3);
            last = Some(out); // dropped outside the timed region on the next iteration
        }
        (median(times), last.unwrap())
    }

    pub fn bench<T>(reps: usize, mut f: impl FnMut() -> T) -> (f64, T) { bench_setup(reps, || (), |_| f()) }

    /// `--name value` or `--name=value`, else `default`.
    pub fn arg<T: std::str::FromStr>(name: &str, default: T) -> T {
        let args: Vec<String> = std::env::args().collect();
        let flag = format!("--{name}");
        let eq = format!("{flag}=");
        for i in 0..args.len() {
            if let Some(v) = args[i].strip_prefix(&eq) { if let Ok(x) = v.parse() { return x; } }
            if args[i] == flag { if let Some(Ok(x)) = args.get(i + 1).map(|v| v.parse()) { return x; } }
        }
        default
    }

    pub fn machine_line() -> String {
        let cpu = std::fs::read_to_string("/proc/cpuinfo").ok()
            .and_then(|s| s.lines().find(|l| l.starts_with("model name"))
                .map(|l| l.split(':').nth(1).unwrap_or("").trim().to_string()))
            .unwrap_or_default();
        let ncpu = std::thread::available_parallelism().map(|n| n.get()).unwrap_or(1);
        let rustc = std::process::Command::new("rustc").arg("-V").output().ok()
            .map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string()).unwrap_or_default();
        let load = std::fs::read_to_string("/proc/loadavg").unwrap_or_default();
        format!("> machine: {cpu} ×{ncpu} vCPU; {rustc}; loadavg at start: {}",
            load.split_whitespace().take(3).collect::<Vec<_>>().join(" "))
    }
}

/// Global allocator wrapper that tracks live heap bytes (use with `#[global_allocator]` in a bin).
pub mod alloc_count {
    use std::alloc::{GlobalAlloc, Layout, System};
    use std::sync::atomic::{AtomicUsize, Ordering::Relaxed};

    pub struct Counting;
    pub static LIVE: AtomicUsize = AtomicUsize::new(0);
    pub static ALLOCS: AtomicUsize = AtomicUsize::new(0);

    unsafe impl GlobalAlloc for Counting {
        unsafe fn alloc(&self, l: Layout) -> *mut u8 {
            LIVE.fetch_add(l.size(), Relaxed); ALLOCS.fetch_add(1, Relaxed);
            unsafe { System.alloc(l) }
        }
        unsafe fn dealloc(&self, p: *mut u8, l: Layout) {
            LIVE.fetch_sub(l.size(), Relaxed);
            unsafe { System.dealloc(p, l) }
        }
        unsafe fn realloc(&self, p: *mut u8, l: Layout, new: usize) -> *mut u8 {
            LIVE.fetch_add(new, Relaxed); LIVE.fetch_sub(l.size(), Relaxed); ALLOCS.fetch_add(1, Relaxed);
            unsafe { System.realloc(p, l, new) }
        }
    }
    pub fn live() -> usize { LIVE.load(Relaxed) }
    pub fn allocs() -> usize { ALLOCS.load(Relaxed) }
}
