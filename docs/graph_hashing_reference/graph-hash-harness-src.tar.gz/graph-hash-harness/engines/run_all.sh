#!/usr/bin/env bash
# Re-run every engines experiment (release build) and write results/*.md. Run on a quiet machine.
set -euo pipefail
cd "$(dirname "$0")"
cargo build --release --bins
R=results; mkdir -p $R
cargo run --release --bin dag_exec -- --reps 7                               > $R/dag_exec.md
cargo run --release --bin dag_exec -- --reps 7 --coarse 0.3                  > $R/dag_exec_coarse.md
cargo run --release --bin dag_exec -- --reps 7 --work-us 0                   > $R/dag_exec_work0.md
cargo run --release --bin dag_exec -- --reps 7 --work-us 0 --out-bytes 65536 > $R/dag_exec_work0_64k.md
cargo run --release --bin dag_exec -- --reps 5 --layers 1000 --window 2      > $R/dag_exec_deep.md
cargo run --release --bin scc_merkle -- --reps 7 --perms 200                 > $R/scc_merkle.md
cargo run --release --bin wl_hash -- --reps 7                                > $R/wl_hash.md
python3 -I py/wl_compare.py $R/wl_small.edges 20000 3 5                      > $R/wl_python.md
cargo run --release --bin code_reindex -- --reps 7                           > $R/code_reindex.md
cargo run --release --bin hash_cons -- --reps 7                              > $R/hash_cons.md
cargo run --release --bin hash_cons -- --reps 7 --depth 6                    > $R/hash_cons_d6.md
for b in ex_a_ca_executor ex_b_scc_merkle ex_c_wl ex_d_fn_index ex_e_hashcons; do cargo run --release --bin $b; done
