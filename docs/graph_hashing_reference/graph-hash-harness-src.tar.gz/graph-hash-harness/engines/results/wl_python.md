| implementation | ms (median of 5) | hash |
|---|---:|---|
| networkx 3.6.1 weisfeiler_lehman_graph_hash (blake2b, string labels), iterations=3 | 221 | ad8b2b8eaf47a82e745f992ea9ec4a32 |
| pure-Python xxh3_64 port of the Rust `wl_graph_hash(.., all_iters=false)` (python-xxhash 4.0.1) | 266 | d538d9855c782623 |
> graph: n=20000 m=100000
| networkx with `_hash_label` patched to xxh3_128 | 182 | (different values) |
> hash calls alone over 20000 first-iteration label strings: blake2b 11.6 ms, xxh3_128 2.5 ms
