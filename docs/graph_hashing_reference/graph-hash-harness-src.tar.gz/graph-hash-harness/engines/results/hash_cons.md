> machine: Intel(R) Xeon(R) Processor @ 2.10GHz ×2 vCPU; rustc 1.97.0 (2d8144b78 2026-07-07); loadavg at start: 1.90 1.54 1.14
> size_of::<NodeKey>() = 16 B, size_of::<Tree>() = 24 B
> hash_cons: K=10000 formulas, vocabulary depth=10 × 64/level, seed=3; avg naive tree size 1985 nodes; distinct formulas after canonical interning 3766

| representation | nodes | heap bytes | allocations | build ms (median of 7) |
|---|---:|---:|---:|---:|
| naive `Box` trees | 19853520 | 476484480 | 19843521 | 1448.1 |
| `Rc` sharing via build-time memo (no interning) | 10652 | 500640 | – | 0.77 |
| hash-consed (FxHash table) | 4272 | 375888 | 25 | 173.0 |
| hash-consed (foldhash table) | 4272 | – | – | 227.8 |
| hash-consed (std SipHash table) | 4272 | – | – | 560.9 |
| hash-consed (xxhash-rust `Xxh3DefaultBuilder` table — anti-pattern for small keys) | 4272 | – | – | 762.9 |

> interner lookups during build: 19853520 (one per constructed node; hit rate 99.9785%)

| equality check (2000 random formula pairs) | equal pairs found | ns / comparison |
|---|---:|---:|
| deep structural, commutativity-aware (`Box` trees) | 0 | 228 |
| deep `==` formula vs its clone (always equal ⇒ full walk) | 2000 | 26958 |
| derived `==` on `Rc` trees (syntactic, no ptr_eq short-cut) | 0 | 50 |
| hash-consed `Id == Id` | 0 | 1.18 |

| dedup 10000 formulas | distinct | ms |
|---|---:|---:|
| fingerprint each naive tree (commutative XXH3-128 Merkle walk) then set-insert | – | 587.1 |
| insert hash-consed Ids into FxHashSet | 3766 | 0.129 |
