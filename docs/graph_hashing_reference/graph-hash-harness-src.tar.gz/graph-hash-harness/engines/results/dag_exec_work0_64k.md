> machine: Intel(R) Xeon(R) Processor @ 2.10GHz ×2 vCPU; rustc 1.97.0 (2d8144b78 2026-07-07); loadavg at start: 1.92 1.36 1.04
> dag_exec: n=10000 layers=10 leaves=1000 edges=20874 depth=10 window=±6 p_global=0.01 coarse_frac=0 work≈0µs/task (0 iters @ 31.7 ns) out=65536B reps=7 seed=42 rayon_threads=2
> leaf cone sizes (tasks reachable from one leaf, incl. itself): min=1 p10=5 median=232 p90=349 max=647

Cells: task executions / wall ms (median of 7); CA = content-addressed constructive traces (XXH3-128 keys).

| scenario (edited leaf cone) | naive | dirty-bit | dirty+restat | CA full | CA rayon | CA hybrid | CA keys hashed (full / hybrid) |
|---|---:|---:|---:|---:|---:|---:|---:|
| cold build | 10000 / 770.0 | 10000 / 792.5 | – | 10000 / 819.4 | 10000 / 801.3 | – | 10000 / – |
| no-op rebuild | 10000 / 778.5 | 0 / 0.3 | 0 / 0.4 | 0 / 1.9 | 0 / 2.3 | 0 / 0.4 | 10000 / 0 |
| touch only (mtime bump, same bytes), median leaf (232) | 10000 / 1024.5 | 232 / 23.9 | 1 / 0.5 | 0 / 2.1 | 0 / 1.9 | 0 / 0.4 | 10000 / 1 |
| value edit, median leaf (232) | 10000 / 809.7 | 232 / 24.1 | 232 / 24.7 | 232 / 27.3 | 232 / 26.5 | 232 / 24.9 | 10000 / 232 |
| comment-only edit, median leaf (232) | 10000 / 812.8 | 232 / 25.1 | 1 / 0.5 | 1 / 2.1 | 1 / 3.0 | 1 / 0.5 | 10000 / 1 |
| edit→revert, median leaf (232) | 10000 / 1054.0 | 232 / 24.4 | 232 / 24.5 | 0 / 2.0 | 0 / 2.4 | 0 / 0.4 | 10000 / 232 |
| touch only (mtime bump, same bytes), p90 leaf (349) | 10000 / 1053.2 | 349 / 37.5 | 1 / 0.5 | 0 / 2.0 | 0 / 2.3 | 0 / 0.4 | 10000 / 1 |
| value edit, p90 leaf (349) | 10000 / 839.5 | 349 / 36.9 | 349 / 36.5 | 349 / 39.9 | 349 / 32.8 | 349 / 37.5 | 10000 / 349 |
| comment-only edit, p90 leaf (349) | 10000 / 820.5 | 349 / 36.9 | 1 / 0.5 | 1 / 2.4 | 1 / 2.4 | 1 / 0.5 | 10000 / 1 |
| edit→revert, p90 leaf (349) | 10000 / 1066.8 | 349 / 39.2 | 349 / 37.8 | 0 / 2.6 | 0 / 2.4 | 0 / 0.5 | 10000 / 349 |

> all strategies produced outputs identical to a from-scratch build: yes

> undeclared-input change (task 5000 reads ambient config not in its key): naive re-exec correct; dirty-bit/restat stale outputs = 32; CA stale outputs = 32 (execs 0). Fix: declare it as an input node (its value hash enters the key).
