> machine: Intel(R) Xeon(R) Processor @ 2.10GHz ×2 vCPU; rustc 1.97.0 (2d8144b78 2026-07-07); loadavg at start: 1.90 1.54 1.14
> code_reindex: /root/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/petgraph-0.8.3/src (64 files, 27183 lines) → 1245 fn nodes, 3821 call edges; call sites 5544: resolved 2574, no in-crate candidate 1638, dropped as ambiguous (>3 candidates) 1332
> timings (median of 7): full index (parse all + hash + link + Merkle) 156.6 ms; re-parse+hash largest file (graph_impl/mod.rs, 83 KiB) 16.35 ms; link+Merkle 2.99 ms; Merkle only 0.451 ms

Cells: artifacts recomputed / artifacts left stale (vs. ground truth = deep semantics). N=1245 nodes × 3 artifacts = 3735.

| edit | target (transitive callers) | content Δ / deep Δ nodes | full rebuild | file-mtime re-index | shallow content hash | deep Merkle | interface-Merkle | deep Merkle, doc-split keys (recomputed) |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| blank lines + `//` block at file top (shifts every span) | median-cone fn `edge_endpoints` (6) | 0 / 0 | 3735 / 0 | 393 / 0 | 0 / 0 | 0 / 0 | 0 / 0 | 0 |
| `//` comment in body | median-cone fn `edge_endpoints` (6) | 0 / 0 | 3735 / 0 | 393 / 0 | 0 / 0 | 0 / 0 | 0 / 0 | 0 |
| `///` doc line added | median-cone fn `edge_endpoints` (6) | 1 / 7 | 3735 / 0 | 393 / 6 | 3 / 6 | 9 / 0 | 3 / 6 | 1 |
| body change | median-cone fn `edge_endpoints` (6) | 1 / 7 | 3735 / 0 | 393 / 6 | 3 / 6 | 9 / 0 | 3 / 6 | 9 |
| signature change (+param) | median-cone fn `edge_endpoints` (6) | 1 / 7 | 3735 / 0 | 393 / 6 | 3 / 6 | 9 / 0 | 7 / 2 | 9 |
| blank lines + `//` block at file top (shifts every span) | p90-cone fn `node_weight` (118) | 0 / 0 | 3735 / 0 | 87 / 0 | 0 / 0 | 0 / 0 | 0 / 0 | 0 |
| `//` comment in body | p90-cone fn `node_weight` (118) | 0 / 0 | 3735 / 0 | 87 / 0 | 0 / 0 | 0 / 0 | 0 / 0 | 0 |
| `///` doc line added | p90-cone fn `node_weight` (118) | 1 / 119 | 3735 / 0 | 87 / 106 | 3 / 118 | 121 / 0 | 3 / 118 | 1 |
| body change | p90-cone fn `node_weight` (118) | 1 / 119 | 3735 / 0 | 87 / 106 | 3 / 118 | 121 / 0 | 3 / 118 | 121 |
| signature change (+param) | p90-cone fn `node_weight` (118) | 1 / 119 | 3735 / 0 | 87 / 106 | 3 / 118 | 121 / 0 | 4 / 117 | 121 |
| blank lines + `//` block at file top (shifts every span) | max-cone fn `is_null` (443) | 0 / 0 | 3735 / 0 | 414 / 0 | 0 / 0 | 0 / 0 | 0 / 0 | 0 |
| `//` comment in body | max-cone fn `is_null` (443) | 0 / 0 | 3735 / 0 | 414 / 0 | 0 / 0 | 0 / 0 | 0 / 0 | 0 |
| `///` doc line added | max-cone fn `is_null` (443) | 1 / 444 | 3735 / 0 | 414 / 344 | 3 / 443 | 446 / 0 | 3 / 443 | 1 |
| body change | max-cone fn `is_null` (443) | 1 / 444 | 3735 / 0 | 414 / 344 | 3 / 443 | 446 / 0 | 3 / 443 | 446 |
| signature change (+param) | max-cone fn `is_null` (443) | 1 / 444 | 3735 / 0 | 414 / 344 | 3 / 443 | 446 / 0 | 8 / 438 | 446 |

> file-mtime = re-derive every fn in the touched file (no cross-file propagation); shallow = key all three artifacts by own content hash;
> deep Merkle = label/embedding by content hash, summary by SCC-aware deep hash; interface-Merkle = summary keyed by own content + direct callees' signatures (a different, weaker contract: stale counts are vs deep semantics).
> doc-split = label keyed by full content (docs inform it); embedding + summary keyed by doc-stripped code hash / deep code hash (stale = 0 under that contract by construction).
