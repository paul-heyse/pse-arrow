> machine: Intel(R) Xeon(R) Processor @ 2.10GHz ×2 vCPU; rustc 1.97.0 (2d8144b78 2026-07-07); loadavg at start: 1.98 1.54 1.14
> wl_hash invariance: 20 random relabelings + edge-order shuffles of a 2k-node/8k-edge graph (h=4): 0 graph- or node-label mismatches; rewiring one edge changes the hash: yes

| pair | isomorphic? | WL hash equal for h=1..6? |
|---|---|---|
| 2×triangle vs 6-cycle | no (2 components vs 1) | equal at every h (collision) |
| decalin vs bicyclopentyl | no | equal at every h (collision) |
| 6-cycle vs 6-path (control) | no | [false, false, false, false, false, false] |

> throughput graph: n=200000 m=1000000 (undirected; 2000000 adjacency entries); per-iteration timings, median of 7; rayon threads=2

| WL step variant | ms / iteration | M adjacency entries / s | distinct labels after 1 step |
|---|---:|---:|---:|
| sort-based, 1 thread | 29.4 | 68 | 170320 |
| sort-based, rayon | 14.9 | 134 | 170320 |
| commutative-sum aggregate (no sort), 1 thread | 13.4 | 149 | 170320 |
| full graph hash h=3 (init + 3 steps + sorts), 1 thread | 109.7 | – | – |

> graph hash (h=3) = 143a125d35d80301
> Python-comparison graph n=20000 m=100000 written to results/wl_small.edges; Rust graph hash h=3 (final labels only): 8.64 ms (median of 7), hash d538d9855c782623
> re-run: python3 -I py/wl_compare.py results/wl_small.edges 20000 3 7   (the xxh3 port must print the same hash)
