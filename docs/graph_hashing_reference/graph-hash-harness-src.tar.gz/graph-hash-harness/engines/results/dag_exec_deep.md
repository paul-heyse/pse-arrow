> machine: Intel(R) Xeon(R) Processor @ 2.10GHz ×2 vCPU; rustc 1.97.0 (2d8144b78 2026-07-07); loadavg at start: 0.07 0.50 0.79
> dag_exec: n=10000 layers=1000 leaves=10 edges=19452 depth=1000 window=±2 p_global=0.01 coarse_frac=0 work≈20µs/task (637 iters @ 31.4 ns) out=64B reps=5 seed=42 rayon_threads=2
> leaf cone sizes (tasks reachable from one leaf, incl. itself): min=1678 p10=9937 median=9947 p90=9971 max=9971

Cells: task executions / wall ms (median of 5); CA = content-addressed constructive traces (XXH3-128 keys).

| scenario (edited leaf cone) | naive | dirty-bit | dirty+restat | CA full | CA rayon | CA hybrid | CA keys hashed (full / hybrid) |
|---|---:|---:|---:|---:|---:|---:|---:|
| cold build | 10000 / 212.8 | 10000 / 215.2 | – | 10000 / 212.9 | 10000 / 144.1 | – | 10000 / – |
| no-op rebuild | 10000 / 214.5 | 0 / 0.3 | 0 / 0.3 | 0 / 1.2 | 0 / 24.5 | 0 / 0.4 | 10000 / 0 |
| touch only (mtime bump, same bytes), median leaf (9947) | 10000 / 216.8 | 9947 / 219.5 | 1 / 0.5 | 0 / 1.3 | 0 / 23.7 | 0 / 0.4 | 10000 / 1 |
| value edit, median leaf (9947) | 10000 / 209.2 | 9947 / 212.3 | 9947 / 214.0 | 9947 / 212.2 | 9947 / 125.6 | 9947 / 218.6 | 10000 / 9947 |
| comment-only edit, median leaf (9947) | 10000 / 208.4 | 9947 / 208.8 | 1 / 0.5 | 1 / 1.4 | 1 / 18.0 | 1 / 0.4 | 10000 / 1 |
| edit→revert, median leaf (9947) | 10000 / 220.3 | 9947 / 207.0 | 9947 / 205.3 | 0 / 1.3 | 0 / 17.8 | 0 / 1.1 | 10000 / 9947 |
| touch only (mtime bump, same bytes), p90 leaf (9971) | 10000 / 206.9 | 9971 / 207.8 | 1 / 0.4 | 0 / 1.2 | 0 / 23.6 | 0 / 0.4 | 10000 / 1 |
| value edit, p90 leaf (9971) | 10000 / 217.8 | 9971 / 219.4 | 9971 / 220.4 | 9971 / 224.2 | 9971 / 129.0 | 9971 / 213.8 | 10000 / 9971 |
| comment-only edit, p90 leaf (9971) | 10000 / 212.8 | 9971 / 220.6 | 1 / 0.4 | 1 / 1.2 | 1 / 20.2 | 1 / 0.4 | 10000 / 1 |
| edit→revert, p90 leaf (9971) | 10000 / 215.7 | 9971 / 213.9 | 9971 / 220.6 | 0 / 1.3 | 0 / 21.4 | 0 / 1.2 | 10000 / 9971 |

> all strategies produced outputs identical to a from-scratch build: yes

> undeclared-input change (task 5000 reads ambient config not in its key): naive re-exec correct; dirty-bit/restat stale outputs = 4922; CA stale outputs = 4922 (execs 0). Fix: declare it as an input node (its value hash enters the key).
