> machine: Intel(R) Xeon(R) Processor @ 2.10GHz ×2 vCPU; rustc 1.97.0 (2d8144b78 2026-07-07); loadavg at start: 1.88 1.30 1.01
> dag_exec: n=10000 layers=10 leaves=1000 edges=20874 depth=10 window=±6 p_global=0.01 coarse_frac=0.3 work≈20µs/task (633 iters @ 31.6 ns) out=64B reps=7 seed=42 rayon_threads=2
> leaf cone sizes (tasks reachable from one leaf, incl. itself): min=1 p10=5 median=232 p90=349 max=647

Cells: task executions / wall ms (median of 7); CA = content-addressed constructive traces (XXH3-128 keys).

| scenario (edited leaf cone) | naive | dirty-bit | dirty+restat | CA full | CA rayon | CA hybrid | CA keys hashed (full / hybrid) |
|---|---:|---:|---:|---:|---:|---:|---:|
| cold build | 10000 / 213.2 | 10000 / 234.7 | – | 10000 / 217.5 | 10000 / 210.2 | – | 10000 / – |
| no-op rebuild | 10000 / 213.7 | 0 / 0.3 | 0 / 0.4 | 0 / 1.2 | 0 / 1.7 | 0 / 0.4 | 10000 / 0 |
| touch only (mtime bump, same bytes), median leaf (232) | 10000 / 210.9 | 232 / 7.6 | 1 / 0.5 | 0 / 1.5 | 0 / 2.1 | 0 / 0.5 | 10000 / 1 |
| value edit, median leaf (232) | 10000 / 213.4 | 232 / 5.1 | 217 / 4.9 | 217 / 6.1 | 217 / 6.2 | 217 / 5.0 | 10000 / 217 |
| comment-only edit, median leaf (232) | 10000 / 216.9 | 232 / 5.2 | 1 / 0.4 | 1 / 1.3 | 1 / 1.7 | 1 / 0.4 | 10000 / 1 |
| edit→revert, median leaf (232) | 10000 / 209.0 | 232 / 5.2 | 217 / 5.1 | 0 / 1.2 | 0 / 1.7 | 0 / 0.4 | 10000 / 217 |
| touch only (mtime bump, same bytes), p90 leaf (349) | 10000 / 211.5 | 349 / 7.6 | 1 / 0.4 | 0 / 1.3 | 0 / 1.7 | 0 / 0.4 | 10000 / 1 |
| value edit, p90 leaf (349) | 10000 / 210.5 | 349 / 7.5 | 233 / 5.2 | 233 / 6.2 | 233 / 6.6 | 233 / 5.3 | 10000 / 233 |
| comment-only edit, p90 leaf (349) | 10000 / 211.0 | 349 / 7.5 | 1 / 0.4 | 1 / 1.3 | 1 / 1.8 | 1 / 0.4 | 10000 / 1 |
| edit→revert, p90 leaf (349) | 10000 / 213.5 | 349 / 8.0 | 233 / 5.7 | 0 / 1.3 | 0 / 1.7 | 0 / 0.4 | 10000 / 233 |

> all strategies produced outputs identical to a from-scratch build: yes

> undeclared-input change (task 5000 reads ambient config not in its key): naive re-exec correct; dirty-bit/restat stale outputs = 32; CA stale outputs = 32 (execs 0). Fix: declare it as an input node (its value hash enters the key).
