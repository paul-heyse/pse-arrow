> machine: Intel(R) Xeon(R) Processor @ 2.10GHz ×2 vCPU; rustc 1.97.0 (2d8144b78 2026-07-07); loadavg at start: 1.54 1.48 1.13
> size_of::<NodeKey>() = 16 B, size_of::<Tree>() = 24 B
> hash_cons: K=10000 formulas, vocabulary depth=6 × 64/level, seed=3; avg naive tree size 174 nodes; distinct formulas after canonical interning 3554

| representation | nodes | heap bytes | allocations | build ms (median of 7) |
|---|---:|---:|---:|---:|
| naive `Box` trees | 1743699 | 41848776 | 1733700 | 127.4 |
| `Rc` sharing via build-time memo (no interning) | 10396 | 493000 | – | 0.75 |
| hash-consed (FxHash table) | 3870 | 310352 | 24 | 15.9 |
| hash-consed (foldhash table) | 3870 | – | – | 21.3 |
| hash-consed (std SipHash table) | 3870 | – | – | 50.5 |
| hash-consed (xxhash-rust `Xxh3DefaultBuilder` table — anti-pattern for small keys) | 3870 | – | – | 70.3 |

> interner lookups during build: 1743699 (one per constructed node; hit rate 99.7781%)

| equality check (2000 random formula pairs) | equal pairs found | ns / comparison |
|---|---:|---:|
| deep structural, commutativity-aware (`Box` trees) | 1 | 80 |
| deep `==` formula vs its clone (always equal ⇒ full walk) | 2000 | 1774 |
| derived `==` on `Rc` trees (syntactic, no ptr_eq short-cut) | 0 | 16 |
| hash-consed `Id == Id` | 1 | 1.69 |

| dedup 10000 formulas | distinct | ms |
|---|---:|---:|
| fingerprint each naive tree (commutative XXH3-128 Merkle walk) then set-insert | – | 52.1 |
| insert hash-consed Ids into FxHashSet | 3554 | 0.092 |
