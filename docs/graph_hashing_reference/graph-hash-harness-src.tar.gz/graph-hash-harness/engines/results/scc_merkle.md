> machine: Intel(R) Xeon(R) Processor @ 2.10GHz ×2 vCPU; rustc 1.97.0 (2d8144b78 2026-07-07); loadavg at start: 1.98 1.52 1.13
> scc_merkle: n=200000 edges=407355 p_back=0.08 window=32 reps=7 seed=7
> SCCs=190384 (non-trivial=2621, nodes in non-trivial SCCs=12237, largest=53, median non-trivial size=3)

| invariance check | result |
|---|---|
| 200 random relabelings × 2 canonicalizations, n=5000 (every node's Merkle hash equal to its image) | 0 failures |
| 1 relabeling of the full n=200000 graph | identical |
| sanity: deleting one dependency edge changes that node's hash | yes |

| operation | SCCs rehashed | ancestor SCC cone | median ms | speedup vs full |
|---|---:|---:|---:|---:|
| full recompute (Tarjan + condensation + hash), refined canon | 190384 | – | 84.5 | 1× |
| full recompute, basic canon | 190384 | – | 93.6 | – |
| …of which: petgraph build + tarjan_scc only | – | – | 15.5 | – |
| …of which: per-node normalized content hashing only | – | – | 21.0 | – |
| content edit: no dependents (cone p10) | 1 | 1 | 0.010 | 8381× |
| content edit: median cone | 73579 | 73579 | 14.106 | 6× |
| content edit: p90 cone | 167252 | 167252 | 31.886 | 3× |
| content edit: member of largest SCC | 121711 | 121711 | 23.088 | 4× |
| whitespace-only edit (normalized content hash unchanged) | 0 | – | 0.0022 | – |

> incremental results verified equal to a from-scratch recompute for every edit above.

| SCC pair (all members identical content; correct answer = same hash iff isomorphic) | isomorphic? | basic canon | WL-refined canon | exact canon (k≤8) | identity in content |
|---|---|---|---|---|---|
| 6-cycle + chord 0→2 vs 6-cycle + chord 0→3 | no | same hash | different | different | n/a |
| circulant C7(1,2) vs C7(1,3) (both 2-in/2-out regular) | no | same hash | same hash | different | different |
| 6-cycle + chord 0→2 vs same shape with chord 3→5 (relabeled) | yes | same hash | same hash | same hash | n/a |

> distinct member hashes inside the 6-node chord SCC: basic=1 refined=6 (6 = every non-automorphic position distinguished)
