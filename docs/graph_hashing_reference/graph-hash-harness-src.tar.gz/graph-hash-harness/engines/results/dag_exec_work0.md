> machine: Intel(R) Xeon(R) Processor @ 2.10GHz ×2 vCPU; rustc 1.97.0 (2d8144b78 2026-07-07); loadavg at start: 1.92 1.36 1.04
> dag_exec: n=10000 layers=10 leaves=1000 edges=20874 depth=10 window=±6 p_global=0.01 coarse_frac=0 work≈0µs/task (0 iters @ 37.2 ns) out=64B reps=7 seed=42 rayon_threads=2
> leaf cone sizes (tasks reachable from one leaf, incl. itself): min=1 p10=5 median=232 p90=349 max=647

Cells: task executions / wall ms (median of 7); CA = content-addressed constructive traces (XXH3-128 keys).

| scenario (edited leaf cone) | naive | dirty-bit | dirty+restat | CA full | CA rayon | CA hybrid | CA keys hashed (full / hybrid) |
|---|---:|---:|---:|---:|---:|---:|---:|
| cold build | 10000 / 4.0 | 10000 / 2.0 | – | 10000 / 3.4 | 10000 / 3.5 | – | 10000 / – |
| no-op rebuild | 10000 / 2.0 | 0 / 0.3 | 0 / 0.4 | 0 / 1.3 | 0 / 1.7 | 0 / 0.4 | 10000 / 0 |
| touch only (mtime bump, same bytes), median leaf (232) | 10000 / 1.9 | 232 / 0.3 | 1 / 0.4 | 0 / 1.3 | 0 / 1.7 | 0 / 0.4 | 10000 / 1 |
| value edit, median leaf (232) | 10000 / 2.1 | 232 / 0.3 | 232 / 0.4 | 232 / 1.3 | 232 / 1.7 | 232 / 0.5 | 10000 / 232 |
| comment-only edit, median leaf (232) | 10000 / 2.0 | 232 / 0.3 | 1 / 0.4 | 1 / 1.2 | 1 / 2.0 | 1 / 0.4 | 10000 / 1 |
| edit→revert, median leaf (232) | 10000 / 2.0 | 232 / 0.4 | 232 / 0.4 | 0 / 1.7 | 0 / 2.1 | 0 / 0.5 | 10000 / 232 |
| touch only (mtime bump, same bytes), p90 leaf (349) | 10000 / 2.1 | 349 / 0.4 | 1 / 0.4 | 0 / 1.3 | 0 / 1.7 | 0 / 0.4 | 10000 / 1 |
| value edit, p90 leaf (349) | 10000 / 2.3 | 349 / 0.4 | 349 / 0.4 | 349 / 1.4 | 349 / 1.8 | 349 / 0.5 | 10000 / 349 |
| comment-only edit, p90 leaf (349) | 10000 / 2.8 | 349 / 0.4 | 1 / 0.4 | 1 / 1.2 | 1 / 1.7 | 1 / 0.4 | 10000 / 1 |
| edit→revert, p90 leaf (349) | 10000 / 1.9 | 349 / 0.3 | 349 / 0.4 | 0 / 1.2 | 0 / 1.6 | 0 / 0.4 | 10000 / 349 |

> all strategies produced outputs identical to a from-scratch build: yes

> undeclared-input change (task 5000 reads ambient config not in its key): naive re-exec correct; dirty-bit/restat stale outputs = 32; CA stale outputs = 32 (execs 0). Fix: declare it as an input node (its value hash enters the key).
