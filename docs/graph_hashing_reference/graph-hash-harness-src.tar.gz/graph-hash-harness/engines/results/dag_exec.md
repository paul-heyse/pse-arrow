> machine: Intel(R) Xeon(R) Processor @ 2.10GHz ×2 vCPU; rustc 1.97.0 (2d8144b78 2026-07-07); loadavg at start: 1.02 1.33 1.10
> dag_exec: n=10000 layers=10 leaves=1000 edges=20874 depth=10 window=±6 p_global=0.01 coarse_frac=0 work≈20µs/task (449 iters @ 44.5 ns) out=64B reps=7 seed=42 rayon_threads=2
> leaf cone sizes (tasks reachable from one leaf, incl. itself): min=1 p10=5 median=232 p90=349 max=647

Cells: task executions / wall ms (median of 7); CA = content-addressed constructive traces (XXH3-128 keys).

| scenario (edited leaf cone) | naive | dirty-bit | dirty+restat | CA full | CA rayon | CA hybrid | CA keys hashed (full / hybrid) |
|---|---:|---:|---:|---:|---:|---:|---:|
| cold build | 10000 / 152.1 | 10000 / 150.3 | – | 10000 / 151.8 | 10000 / 83.2 | – | 10000 / – |
| no-op rebuild | 10000 / 155.4 | 0 / 0.3 | 0 / 0.4 | 0 / 1.3 | 0 / 1.5 | 0 / 0.4 | 10000 / 0 |
| touch only (mtime bump, same bytes), median leaf (232) | 10000 / 162.3 | 232 / 4.1 | 1 / 0.4 | 0 / 1.5 | 0 / 1.9 | 0 / 0.4 | 10000 / 1 |
| value edit, median leaf (232) | 10000 / 158.1 | 232 / 3.9 | 232 / 3.9 | 232 / 6.1 | 232 / 4.2 | 232 / 3.8 | 10000 / 232 |
| comment-only edit, median leaf (232) | 10000 / 154.3 | 232 / 3.8 | 1 / 0.4 | 1 / 1.5 | 1 / 1.5 | 1 / 0.4 | 10000 / 1 |
| edit→revert, median leaf (232) | 10000 / 169.6 | 232 / 4.0 | 232 / 3.9 | 0 / 1.2 | 0 / 1.5 | 0 / 0.4 | 10000 / 232 |
| touch only (mtime bump, same bytes), p90 leaf (349) | 10000 / 154.4 | 349 / 5.6 | 1 / 0.4 | 0 / 1.2 | 0 / 1.6 | 0 / 0.4 | 10000 / 1 |
| value edit, p90 leaf (349) | 10000 / 154.4 | 349 / 5.5 | 349 / 5.5 | 349 / 6.6 | 349 / 5.9 | 349 / 5.6 | 10000 / 349 |
| comment-only edit, p90 leaf (349) | 10000 / 149.0 | 349 / 6.1 | 1 / 0.4 | 1 / 1.5 | 1 / 1.8 | 1 / 0.4 | 10000 / 1 |
| edit→revert, p90 leaf (349) | 10000 / 157.2 | 349 / 6.0 | 349 / 5.7 | 0 / 1.2 | 0 / 1.6 | 0 / 0.5 | 10000 / 349 |

> all strategies produced outputs identical to a from-scratch build: yes

> undeclared-input change (task 5000 reads ambient config not in its key): naive re-exec correct; dirty-bit/restat stale outputs = 32; CA stale outputs = 32 (execs 0). Fix: declare it as an input node (its value hash enters the key).
