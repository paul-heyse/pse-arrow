"""Recompute the Rust test vectors (f_db_integers --json) with python-xxhash and compare.

Also re-derives the canonical node encoding in Python with struct.pack('<QHIdI...') for the first
case, proving the byte layout itself (not just the hash) is reproducible cross-language.

Usage: python3 scripts/check_python.py vec.json
"""
import json, struct, sys
import xxhash

def encode(id_, kind, flags, weight, name, deps):
    if weight == 0.0:
        weight = 0.0  # canonicalize -0.0
    nb = name.encode("utf-8")
    return (struct.pack("<QHId", id_, kind, flags, weight) + struct.pack("<I", len(nb)) + nb
            + struct.pack("<I", len(deps)) + struct.pack(f"<{len(deps)}I", *deps))

def to_i64(u):  # bit-cast u64 -> signed i64, same as Rust `h as i64`
    return u - (1 << 64) if u >= (1 << 63) else u

vecs = json.load(open(sys.argv[1]))
print(f"python-xxhash {xxhash.VERSION}, libxxhash {xxhash.XXHASH_VERSION}")
ok = True
py_bytes = {
    "node_canonical": encode(42, 3, 0xDEADBEEF, 1.5, "pkg/core::Graph", [1, 2, 3, 1_000_000]),
    "node_negzero_weight": encode(7, 0, 0, -0.0, "", []),
    "node_unicode": encode(2**64 - 1, 2**16 - 1, 1, -2.25, "ノード/πβ", [2**32 - 1]),
    "node_long": encode(1, 1, 1, 0.1, "".join(chr(ord('a') + i % 26) for i in range(300)), list(range(64))),
    "empty": b"",
    "str_node:42": b"node:42",
}
rows = []
for v in vecs:
    b = bytes.fromhex(v["bytes_hex"])
    enc_ok = py_bytes[v["name"]] == b
    checks = {
        "encoding": enc_ok,
        "xxh3_64": xxhash.xxh3_64_intdigest(b) == v["xxh3_64"],
        "xxh3_64_hex": xxhash.xxh3_64_hexdigest(b) == v["xxh3_64_hex"],
        "xxh3_64_i64": to_i64(xxhash.xxh3_64_intdigest(b)) == v["xxh3_64_i64"],
        "xxh3_64_seeded": xxhash.xxh3_64_intdigest(b, seed=v["seed"]) == v["xxh3_64_seeded"],
        "xxh3_128_hex": xxhash.xxh3_128_hexdigest(b) == v["xxh3_128_hex"],
        "xxh3_128_hi_lo": (lambda d: (to_i64(d >> 64), to_i64(d & (2**64 - 1))))(xxhash.xxh3_128_intdigest(b)) == (v["xxh3_128_hi_i64"], v["xxh3_128_lo_i64"]),
        "xxh3_128_digest_be": xxhash.xxh3_128_digest(b).hex() == v["xxh3_128_hex"],
        "xxh64": xxhash.xxh64_intdigest(b) == v["xxh64"],
    }
    ok &= all(checks.values())
    rows.append((v["name"], v["len"], all(checks.values()), [k for k, c in checks.items() if not c]))
print("| vector | len | all match | failures |\n|---|---|---|---|")
for r in rows:
    print(f"| {r[0]} | {r[1]} | {'yes' if r[2] else 'NO'} | {', '.join(r[3]) or '—'} |")
c = vecs[0]
print(f"\nnode_canonical: bytes={c['bytes_hex']}\n  xxh3_64={c['xxh3_64']} (0x{c['xxh3_64_hex']}), as i64={c['xxh3_64_i64']}, xxh3_128={c['xxh3_128_hex']}")
sys.exit(0 if ok else 1)
