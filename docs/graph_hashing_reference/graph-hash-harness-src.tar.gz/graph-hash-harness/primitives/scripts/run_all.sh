#!/usr/bin/env bash
# Re-run every benchmark; outputs go to results/<bin>.<flavor>.md
# Usage: scripts/run_all.sh            (default x86-64 build)
#        FLAVOR=native scripts/run_all.sh   (RUSTFLAGS="-C target-cpu=native", separate target dir)
set -euo pipefail
cd "$(dirname "$0")/.."
FLAVOR=${FLAVOR:-default}
mkdir -p results
if [ "$FLAVOR" = native ]; then export RUSTFLAGS="-C target-cpu=native"; export CARGO_TARGET_DIR=target-native; fi
export REPS=${REPS:-7}
for b in ${BINS:-a_hashmap_keys b_bfs c_fingerprint d_interning e_collisions f_db_integers g_merkle h_key_patterns}; do
  echo "== $b ($FLAVOR)"; cargo run --release --bin "$b" > "results/$b.$FLAVOR.md"
done
if [ "$FLAVOR" = default ]; then
  cargo run --release --bin f_db_integers -- --json > results/vectors.json
  python3 scripts/check_python.py results/vectors.json > results/python_check.md
fi
