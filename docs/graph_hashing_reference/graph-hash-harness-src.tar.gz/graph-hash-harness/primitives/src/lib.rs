//! Shared helpers for the graph-hash primitive benchmarks:
//! deterministic RNG, interleaved median timing, a toggleable counting allocator,
//! and markdown table output.
use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicBool, AtomicIsize, Ordering::Relaxed};
use std::time::Instant;

pub use std::hint::black_box;

// ---------------------------------------------------------------- allocator
/// Counts live heap bytes, but only while `ENABLED` (so timed passes pay one relaxed load).
pub struct CountingAlloc;
static ENABLED: AtomicBool = AtomicBool::new(false);
static LIVE: AtomicIsize = AtomicIsize::new(0);
static PEAK: AtomicIsize = AtomicIsize::new(0);

#[inline]
fn add(delta: isize) {
    if ENABLED.load(Relaxed) {
        let now = LIVE.fetch_add(delta, Relaxed) + delta;
        PEAK.fetch_max(now, Relaxed);
    }
}
unsafe impl GlobalAlloc for CountingAlloc {
    unsafe fn alloc(&self, l: Layout) -> *mut u8 {
        let p = unsafe { System.alloc(l) };
        if !p.is_null() { add(l.size() as isize) }
        p
    }
    unsafe fn alloc_zeroed(&self, l: Layout) -> *mut u8 {
        let p = unsafe { System.alloc_zeroed(l) };
        if !p.is_null() { add(l.size() as isize) }
        p
    }
    unsafe fn dealloc(&self, p: *mut u8, l: Layout) {
        unsafe { System.dealloc(p, l) };
        add(-(l.size() as isize));
    }
    unsafe fn realloc(&self, p: *mut u8, l: Layout, new: usize) -> *mut u8 {
        let q = unsafe { System.realloc(p, l, new) };
        if !q.is_null() { add(new as isize - l.size() as isize) }
        q
    }
}
#[global_allocator]
static GLOBAL: CountingAlloc = CountingAlloc;

/// Run `f` with allocation counting on. Returns (value, retained_bytes, peak_extra_bytes).
/// Retained = bytes allocated during `f` and still live when it returns (i.e. owned by the result).
pub fn measure_mem<T>(f: impl FnOnce() -> T) -> (T, isize, isize) {
    let base = LIVE.load(Relaxed);
    PEAK.store(base, Relaxed);
    ENABLED.store(true, Relaxed);
    let v = f();
    ENABLED.store(false, Relaxed);
    (v, LIVE.load(Relaxed) - base, PEAK.load(Relaxed) - base)
}

// ---------------------------------------------------------------- rng
/// SplitMix64: tiny, deterministic, good enough for workload generation.
#[derive(Clone)]
pub struct Rng(pub u64);
impl Rng {
    pub fn new(seed: u64) -> Self { Rng(seed) }
    #[inline]
    pub fn next_u64(&mut self) -> u64 {
        self.0 = self.0.wrapping_add(0x9E37_79B9_7F4A_7C15);
        let mut z = self.0;
        z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
        z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
        z ^ (z >> 31)
    }
    /// Uniform in [0, n) (Lemire multiply-shift; bias negligible for our n).
    #[inline]
    pub fn below(&mut self, n: u64) -> u64 { ((self.next_u64() as u128 * n as u128) >> 64) as u64 }
    pub fn shuffle<T>(&mut self, v: &mut [T]) {
        for i in (1..v.len()).rev() { let j = self.below(i as u64 + 1) as usize; v.swap(i, j); }
    }
    /// Random lowercase-alnum string with length in [lo, hi].
    pub fn string(&mut self, lo: usize, hi: usize) -> String {
        const A: &[u8] = b"abcdefghijklmnopqrstuvwxyz0123456789_:/";
        let len = lo + self.below((hi - lo + 1) as u64) as usize;
        (0..len).map(|_| A[self.below(A.len() as u64) as usize] as char).collect()
    }
}

// ---------------------------------------------------------------- timing
pub fn ns_since(t: Instant) -> f64 { t.elapsed().as_nanos() as f64 }

pub fn median(v: &mut [f64]) -> f64 {
    v.sort_by(|a, b| a.total_cmp(b));
    let n = v.len();
    if n == 0 { return f64::NAN }
    if n % 2 == 1 { v[n / 2] } else { (v[n / 2 - 1] + v[n / 2]) / 2.0 }
}

pub fn reps() -> usize { std::env::var("REPS").ok().and_then(|s| s.parse().ok()).unwrap_or(7) }

/// Interleaved repetitions: in rep r, variants run in rotated order starting at r % n.
/// `run(idx)` returns K metrics; result is the per-metric median for every variant.
pub fn interleave<const K: usize>(reps: usize, n: usize, mut run: impl FnMut(usize) -> [f64; K]) -> Vec<[f64; K]> {
    let mut samples: Vec<Vec<[f64; K]>> = vec![Vec::new(); n];
    for r in 0..reps {
        for i in 0..n {
            let idx = (i + r) % n;
            samples[idx].push(run(idx));
        }
    }
    samples
        .into_iter()
        .map(|s| {
            let mut out = [0.0; K];
            for k in 0..K {
                let mut col: Vec<f64> = s.iter().map(|m| m[k]).collect();
                out[k] = median(&mut col);
            }
            out
        })
        .collect()
}

// ---------------------------------------------------------------- output
pub fn print_env(bin: &str) {
    let cpu = std::fs::read_to_string("/proc/cpuinfo").ok()
        .and_then(|s| s.lines().find(|l| l.starts_with("model name")).map(|l| l.split(':').nth(1).unwrap_or("").trim().to_string()))
        .unwrap_or_else(|| "?".into());
    let load = std::fs::read_to_string("/proc/loadavg").unwrap_or_default();
    let feats: Vec<&str> = [
        ("sse4.2", cfg!(target_feature = "sse4.2")), ("avx2", cfg!(target_feature = "avx2")),
        ("avx512f", cfg!(target_feature = "avx512f")), ("aes", cfg!(target_feature = "aes")),
    ].iter().filter(|x| x.1).map(|x| x.0).collect();
    println!("<!-- bin={bin} cpu=\"{cpu}\" rustc=\"{}\" rustflags=\"{}\" compile-time target features beyond SSE2: [{}] loadavg={} reps={} -->",
        env!("RUSTC_VERSION"), env!("BUILD_RUSTFLAGS"), feats.join(","), load.split_whitespace().take(3).collect::<Vec<_>>().join(" "), reps());
}

pub fn print_table(title: &str, headers: &[&str], rows: &[Vec<String>]) {
    println!("\n#### {title}\n");
    println!("| {} |", headers.join(" | "));
    println!("|{}|", headers.iter().map(|_| "---").collect::<Vec<_>>().join("|"));
    for r in rows { println!("| {} |", r.join(" | ")); }
}

/// Format with ~3 significant digits.
pub fn f(x: f64) -> String {
    if !x.is_finite() { return "–".into() }
    let a = x.abs();
    if a >= 100.0 { format!("{x:.0}") } else if a >= 10.0 { format!("{x:.1}") } else if a >= 1.0 { format!("{x:.2}") } else { format!("{x:.3}") }
}
pub fn mib(bytes: isize) -> String { format!("{:.1}", bytes as f64 / (1024.0 * 1024.0)) }
