<!-- bin=g_merkle cpu="Intel(R) Xeon(R) Processor @ 2.10GHz" rustc="rustc 1.97.0 (2d8144b78 2026-07-07)" rustflags="" compile-time target features beyond SSE2: [] loadavg=0.24 0.56 0.78 reps=7 -->

#### Full Merkle propagation, N=1048576, edges=4193826, random children (uniform over all earlier nodes)

| fingerprint scheme | total ms | ns/node | over no-hash baseline ns/node |
|---|---|---|---|
| no hash (traversal + add/rotate only) | 26.7 | 25.4 | 0.000 |
| XXH3-64, 8-B child fps | 49.5 | 47.2 | 21.7 |
| XXH3-64, children sorted (set semantics) | 96.6 | 92.1 | 66.6 |
| XXH3-64 content + wrapping-add multiset of children | 49.2 | 46.9 | 21.5 |
| XXH3-128, 16-B child fps | 78.6 | 74.9 | 49.5 |
| BLAKE3 truncated to 128, 16-B child fps | 290 | 277 | 252 |
| BLAKE3-256, 32-B child fps | 409 | 390 | 364 |
| SHA-256, 32-B child fps | 337 | 322 | 296 |

#### Full Merkle propagation, N=1048576, edges=4193826, local children (within previous 64 nodes)

| fingerprint scheme | total ms | ns/node | over no-hash baseline ns/node |
|---|---|---|---|
| no hash (traversal + add/rotate only) | 18.5 | 17.6 | 0.000 |
| XXH3-64, 8-B child fps | 30.1 | 28.7 | 11.0 |
| XXH3-64, children sorted (set semantics) | 70.7 | 67.5 | 49.8 |
| XXH3-64 content + wrapping-add multiset of children | 26.4 | 25.1 | 7.49 |
| XXH3-128, 16-B child fps | 39.0 | 37.2 | 19.5 |
| BLAKE3 truncated to 128, 16-B child fps | 198 | 189 | 172 |
| BLAKE3-256, 32-B child fps | 271 | 258 | 240 |
| SHA-256, 32-B child fps | 238 | 227 | 209 |

#### Incremental re-propagation (XXH3-128) after changing one node's content, random DAG N=1048576; verified == full recompute

| changed node index | dirty nodes (node + ancestors) | share of graph | ms |
|---|---|---|---|
| 1048566 | 1 | 0.0% | 0.065 |
| 1047576 | 1 | 0.0% | 0.057 |
| 786432 | 1 | 0.0% | 0.056 |
| 524288 | 18 | 0.0% | 0.074 |
| 104857 | 597 | 0.1% | 0.505 |
| 100 | 913625 | 87.1% | 158 |
