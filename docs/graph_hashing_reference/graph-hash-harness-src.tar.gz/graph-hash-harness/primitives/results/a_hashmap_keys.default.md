<!-- bin=a_hashmap_keys cpu="Intel(R) Xeon(R) Processor @ 2.10GHz" rustc="rustc 1.97.0 (2d8144b78 2026-07-07)" rustflags="" compile-time target features beyond SSE2: [] loadavg=0.46 0.57 0.77 reps=7 -->

### n = 1048576 keys


#### u32 dense node ids (0..n, shuffled), n=1048576

| variant | insert ns/op | hit ns/op | miss ns/op | hit vs best |
|---|---|---|---|---|
| std RandomState (SipHash-1-3) | 79.4 | 60.6 | 23.4 | 18.86× |
| foldhash::fast | 50.7 | 16.4 | 5.47 | 5.11× |
| foldhash::quality | 48.8 | 21.2 | 6.96 | 6.59× |
| rustc-hash FxBuildHasher | 47.1 | 14.2 | 4.09 | 4.42× |
| ahash RandomState | 50.9 | 19.0 | 10.2 | 5.91× |
| xxhash-rust Xxh3DefaultBuilder | 81.5 | 45.9 | 18.3 | 14.29× |
| custom XXH3 oneshot-per-write Hasher | 53.3 | 23.4 | 8.81 | 7.29× |
| twox-hash xxhash64::State | 89.5 | 48.9 | 20.0 | 15.23× |
| hashbrown + DefaultHashBuilder (foldhash) | 49.8 | 16.6 | 5.54 | 5.17× |
| hashbrown + FxBuildHasher | 38.7 | 15.7 | 4.06 | 4.89× |
| nohash (identity; NOT valid for raw ids) | 85.7 | 7.30 | 1.29 | 2.27× |
| dense Vec<u32> index (baseline) | 5.66 | 3.21 | 0.836 | 1.00× |
| sorted Vec + binary_search | 27.4 | 239 | 40.0 | 74.50× |

#### u32 sparse random ids, n=1048576

| variant | insert ns/op | hit ns/op | miss ns/op | hit vs best |
|---|---|---|---|---|
| std RandomState (SipHash-1-3) | 73.7 | 58.4 | 22.9 | 3.95× |
| foldhash::fast | 51.1 | 15.2 | 5.31 | 1.02× |
| foldhash::quality | 52.4 | 22.0 | 6.80 | 1.49× |
| rustc-hash FxBuildHasher | 47.8 | 14.8 | 5.34 | 1.00× |
| ahash RandomState | 50.7 | 19.4 | 10.2 | 1.31× |
| xxhash-rust Xxh3DefaultBuilder | 78.9 | 45.3 | 17.6 | 3.06× |
| custom XXH3 oneshot-per-write Hasher | 52.1 | 23.1 | 8.17 | 1.56× |
| twox-hash xxhash64::State | 82.9 | 51.0 | 19.5 | 3.45× |
| hashbrown + DefaultHashBuilder (foldhash) | 50.8 | 19.4 | 5.84 | 1.31× |
| hashbrown + FxBuildHasher | 41.4 | 15.0 | 5.49 | 1.02× |
| nohash (identity; NOT valid for raw ids) | 91.7 | 22.9 | 55.3 | 1.55× |
| sorted Vec + binary_search | 29.2 | 205 | 203 | 13.86× |

#### u64 pre-hashed fingerprints, n=1048576

| variant | insert ns/op | hit ns/op | miss ns/op | hit vs best |
|---|---|---|---|---|
| std RandomState (SipHash-1-3) | 108 | 80.1 | 26.9 | 5.20× |
| foldhash::fast | 53.5 | 19.5 | 6.83 | 1.27× |
| foldhash::quality | 54.7 | 26.2 | 8.07 | 1.70× |
| rustc-hash FxBuildHasher | 54.1 | 19.5 | 6.79 | 1.27× |
| ahash RandomState | 55.6 | 23.8 | 12.4 | 1.54× |
| xxhash-rust Xxh3DefaultBuilder | 95.6 | 58.3 | 20.9 | 3.78× |
| custom XXH3 oneshot-per-write Hasher | 55.6 | 25.2 | 9.35 | 1.64× |
| twox-hash xxhash64::State | 95.2 | 56.0 | 20.5 | 3.63× |
| hashbrown + DefaultHashBuilder (foldhash) | 48.0 | 18.6 | 6.86 | 1.20× |
| hashbrown + FxBuildHasher | 53.5 | 17.9 | 6.65 | 1.16× |
| nohash-hasher (identity; valid: key is already a hash) | 54.0 | 15.4 | 5.98 | 1.00× |
| sorted Vec + binary_search | 36.5 | 318 | 306 | 20.64× |

#### (u32,u32) edge tuples, n=1048576

| variant | insert ns/op | hit ns/op | miss ns/op | hit vs best |
|---|---|---|---|---|
| std RandomState (SipHash-1-3) | 105 | 101 | 32.8 | 5.58× |
| foldhash::fast | 60.6 | 18.2 | 6.25 | 1.00× |
| foldhash::quality | 60.0 | 27.5 | 7.41 | 1.51× |
| rustc-hash FxBuildHasher | 59.8 | 19.4 | 6.82 | 1.07× |
| ahash RandomState | 59.2 | 24.2 | 13.6 | 1.33× |
| xxhash-rust Xxh3DefaultBuilder | 118 | 70.8 | 25.9 | 3.89× |
| custom XXH3 oneshot-per-write Hasher | 67.9 | 33.4 | 13.3 | 1.84× |
| twox-hash xxhash64::State | 243 | 211 | 56.4 | 11.62× |
| hashbrown + DefaultHashBuilder (foldhash) | 54.8 | 18.4 | 6.31 | 1.01× |
| hashbrown + FxBuildHasher | 59.5 | 19.6 | 7.29 | 1.08× |
| sorted Vec + binary_search | 41.0 | 401 | 386 | 22.05× |

#### &str keys, 16–32 bytes, n=1048576

| variant | insert ns/op | hit ns/op | miss ns/op | hit vs best |
|---|---|---|---|---|
| std RandomState (SipHash-1-3) | 399 | 164 | 55.3 | 2.54× |
| foldhash::fast | 163 | 99.7 | 23.0 | 1.55× |
| foldhash::quality | 178 | 89.4 | 23.7 | 1.39× |
| rustc-hash FxBuildHasher | 145 | 64.3 | 18.4 | 1.00× |
| ahash RandomState | 171 | 83.9 | 25.1 | 1.30× |
| xxhash-rust Xxh3DefaultBuilder | 372 | 224 | 64.8 | 3.48× |
| custom XXH3 oneshot-per-write Hasher | 196 | 88.0 | 26.5 | 1.37× |
| twox-hash xxhash64::State | 384 | 207 | 75.0 | 3.22× |
| hashbrown + DefaultHashBuilder (foldhash) | 159 | 77.6 | 23.2 | 1.21× |
| hashbrown + FxBuildHasher | 141 | 74.4 | 29.8 | 1.16× |
| sorted Vec + binary_search | 201 | 2025 | 2101 | 31.47× |

### n = 16384 keys


#### u32 dense node ids (0..n, shuffled), n=16384

| variant | insert ns/op | hit ns/op | miss ns/op | hit vs best |
|---|---|---|---|---|
| std RandomState (SipHash-1-3) | 40.3 | 12.2 | 11.4 | 22.32× |
| foldhash::fast | 23.8 | 2.95 | 2.42 | 5.41× |
| foldhash::quality | 23.3 | 3.42 | 2.83 | 6.29× |
| rustc-hash FxBuildHasher | 19.2 | 2.50 | 1.66 | 4.59× |
| ahash RandomState | 22.8 | 3.82 | 3.29 | 7.02× |
| xxhash-rust Xxh3DefaultBuilder | 37.6 | 9.24 | 10.1 | 16.97× |
| custom XXH3 oneshot-per-write Hasher | 24.6 | 4.56 | 4.02 | 8.38× |
| twox-hash xxhash64::State | 39.7 | 9.94 | 11.3 | 18.25× |
| hashbrown + DefaultHashBuilder (foldhash) | 21.5 | 2.89 | 2.39 | 5.31× |
| hashbrown + FxBuildHasher | 18.4 | 2.71 | 1.73 | 4.97× |
| nohash (identity; NOT valid for raw ids) | 41.7 | 1.68 | 1.08 | 3.08× |
| dense Vec<u32> index (baseline) | 1.46 | 0.545 | 0.379 | 1.00× |
| sorted Vec + binary_search | 17.4 | 29.2 | 20.0 | 53.58× |

#### u32 sparse random ids, n=16384

| variant | insert ns/op | hit ns/op | miss ns/op | hit vs best |
|---|---|---|---|---|
| std RandomState (SipHash-1-3) | 39.2 | 12.7 | 12.0 | 4.90× |
| foldhash::fast | 23.1 | 2.93 | 2.48 | 1.13× |
| foldhash::quality | 23.6 | 3.42 | 2.93 | 1.32× |
| rustc-hash FxBuildHasher | 22.5 | 2.59 | 2.47 | 1.00× |
| ahash RandomState | 22.7 | 3.77 | 3.26 | 1.45× |
| xxhash-rust Xxh3DefaultBuilder | 39.4 | 9.40 | 10.1 | 3.62× |
| custom XXH3 oneshot-per-write Hasher | 23.9 | 4.61 | 3.97 | 1.78× |
| twox-hash xxhash64::State | 39.3 | 9.97 | 11.5 | 3.85× |
| hashbrown + DefaultHashBuilder (foldhash) | 22.4 | 2.88 | 2.51 | 1.11× |
| hashbrown + FxBuildHasher | 21.0 | 2.88 | 2.50 | 1.11× |
| nohash (identity; NOT valid for raw ids) | 53.4 | 12.2 | 24.0 | 4.71× |
| sorted Vec + binary_search | 17.2 | 27.6 | 27.2 | 10.64× |

#### u64 pre-hashed fingerprints, n=16384

| variant | insert ns/op | hit ns/op | miss ns/op | hit vs best |
|---|---|---|---|---|
| std RandomState (SipHash-1-3) | 46.2 | 14.9 | 13.0 | 6.57× |
| foldhash::fast | 24.4 | 2.89 | 2.48 | 1.28× |
| foldhash::quality | 24.7 | 3.64 | 3.00 | 1.61× |
| rustc-hash FxBuildHasher | 23.0 | 2.94 | 2.62 | 1.30× |
| ahash RandomState | 25.0 | 3.67 | 3.32 | 1.62× |
| xxhash-rust Xxh3DefaultBuilder | 38.5 | 9.62 | 9.78 | 4.24× |
| custom XXH3 oneshot-per-write Hasher | 24.5 | 4.45 | 3.97 | 1.96× |
| twox-hash xxhash64::State | 41.4 | 10.8 | 10.7 | 4.78× |
| hashbrown + DefaultHashBuilder (foldhash) | 23.8 | 3.08 | 2.50 | 1.36× |
| hashbrown + FxBuildHasher | 23.0 | 2.73 | 2.48 | 1.20× |
| nohash-hasher (identity; valid: key is already a hash) | 24.1 | 2.27 | 2.18 | 1.00× |
| sorted Vec + binary_search | 23.4 | 33.4 | 33.6 | 14.75× |

#### (u32,u32) edge tuples, n=16384

| variant | insert ns/op | hit ns/op | miss ns/op | hit vs best |
|---|---|---|---|---|
| std RandomState (SipHash-1-3) | 64.5 | 19.2 | 16.4 | 5.79× |
| foldhash::fast | 24.6 | 3.32 | 2.92 | 1.00× |
| foldhash::quality | 25.4 | 3.91 | 3.20 | 1.18× |
| rustc-hash FxBuildHasher | 24.1 | 3.52 | 2.91 | 1.06× |
| ahash RandomState | 26.3 | 4.79 | 4.44 | 1.44× |
| xxhash-rust Xxh3DefaultBuilder | 55.9 | 16.2 | 16.0 | 4.86× |
| custom XXH3 oneshot-per-write Hasher | 29.2 | 7.94 | 7.13 | 2.39× |
| twox-hash xxhash64::State | 106 | 40.7 | 29.4 | 12.24× |
| hashbrown + DefaultHashBuilder (foldhash) | 23.3 | 3.36 | 2.78 | 1.01× |
| hashbrown + FxBuildHasher | 24.0 | 3.52 | 3.77 | 1.06× |
| sorted Vec + binary_search | 25.9 | 60.9 | 60.5 | 18.34× |

#### &str keys, 16–32 bytes, n=16384

| variant | insert ns/op | hit ns/op | miss ns/op | hit vs best |
|---|---|---|---|---|
| std RandomState (SipHash-1-3) | 112 | 41.2 | 33.9 | 3.67× |
| foldhash::fast | 46.9 | 15.3 | 7.44 | 1.36× |
| foldhash::quality | 41.0 | 14.1 | 8.27 | 1.26× |
| rustc-hash FxBuildHasher | 35.5 | 11.2 | 5.99 | 1.00× |
| ahash RandomState | 42.8 | 15.0 | 8.56 | 1.34× |
| xxhash-rust Xxh3DefaultBuilder | 112 | 47.7 | 27.9 | 4.25× |
| custom XXH3 oneshot-per-write Hasher | 45.9 | 16.7 | 9.14 | 1.49× |
| twox-hash xxhash64::State | 130 | 51.6 | 37.1 | 4.60× |
| hashbrown + DefaultHashBuilder (foldhash) | 38.9 | 14.0 | 7.54 | 1.24× |
| hashbrown + FxBuildHasher | 35.9 | 11.2 | 6.55 | 1.00× |
| sorted Vec + binary_search | 74.2 | 233 | 202 | 20.79× |

#### Memory, n = 1048576 entries, no pre-sizing (allocator-counted)

| structure | MiB | bytes/entry |
|---|---|---|
| HashMap<u32,u32,Fx> | 18.0 | 18.0 |
| HashMap<u64,u32,Fx> | 34.0 | 34.0 |
| HashMap<(u32,u32),u32,Fx> | 26.0 | 26.0 |
| Vec<u32> dense index | 4.0 | 4.0 |
