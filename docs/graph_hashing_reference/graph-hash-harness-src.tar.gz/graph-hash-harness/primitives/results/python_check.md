python-xxhash 4.0.1, libxxhash 0.8.3
| vector | len | all match | failures |
|---|---|---|---|
| node_canonical | 61 | yes | — |
| node_negzero_weight | 30 | yes | — |
| node_unicode | 48 | yes | — |
| node_long | 586 | yes | — |
| empty | 0 | yes | — |
| str_node:42 | 7 | yes | — |

node_canonical: bytes=2a000000000000000300efbeadde000000000000f83f0f000000706b672f636f72653a3a47726170680400000001000000020000000300000040420f00
  xxh3_64=4455514264387335601 (0x3dd52a9dfc7e35b1), as i64=4455514264387335601, xxh3_128=20744ca1dced2128da4db39423570b23
