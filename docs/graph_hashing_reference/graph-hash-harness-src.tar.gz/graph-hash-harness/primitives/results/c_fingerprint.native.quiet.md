<!-- bin=c_fingerprint cpu="Intel(R) Xeon(R) Processor @ 2.10GHz" rustc="rustc 1.97.0 (2d8144b78 2026-07-07)" rustflags="-C target-cpu=native" compile-time target features beyond SSE2: [sse4.2,avx2,avx512f,aes] loadavg=0.82 0.27 0.36 reps=7 -->

#### Part 1a — one-shot latency, ns per call, cache-hot window max(16 KiB, 2×size)

| algorithm | 16 B | 64 B | 256 B | 1 KiB | 16 KiB | 1 MiB |
|---|---|---|---|---|---|---|
| XXH3-64 xxhash-rust | 4.10 | 6.65 | 15.7 | 30.7 | 352 | 23106 |
| XXH3-64 twox-hash | 4.38 | 6.86 | 25.6 | 46.3 | 475 | 33428 |
| XXH3-128 xxhash-rust | 6.36 | 9.83 | 25.7 | 41.1 | 381 | 27180 |
| XXH3-128 twox-hash | 6.85 | 10.3 | 28.3 | 46.7 | 468 | 34241 |
| XXH64 xxhash-rust | 7.28 | 17.1 | 37.2 | 106 | 1479 | 94530 |
| XXH64 twox-hash | 7.19 | 18.0 | 38.5 | 160 | 3121 | 201906 |
| BLAKE3 (1 thread) | 86.7 | 69.8 | 297 | 1078 | 3034 | 185182 |
| SHA-256 (sha2) | 81.0 | 118 | 260 | 822 | 12161 | 764867 |
| SipHash-1-3-128 (siphasher) | 20.9 | 34.5 | 87.6 | 302 | 4724 | 291736 |

#### Part 1b — throughput GiB/s, cache-hot window max(16 KiB, 2×size)

| algorithm | 16 B | 64 B | 256 B | 1 KiB | 16 KiB | 1 MiB |
|---|---|---|---|---|---|---|
| XXH3-64 xxhash-rust | 3.64 | 8.96 | 15.2 | 31.1 | 43.3 | 42.3 |
| XXH3-64 twox-hash | 3.40 | 8.68 | 9.31 | 20.6 | 32.2 | 29.2 |
| XXH3-128 xxhash-rust | 2.34 | 6.06 | 9.29 | 23.2 | 40.0 | 35.9 |
| XXH3-128 twox-hash | 2.18 | 5.81 | 8.44 | 20.4 | 32.6 | 28.5 |
| XXH64 xxhash-rust | 2.05 | 3.49 | 6.41 | 9.01 | 10.3 | 10.3 |
| XXH64 twox-hash | 2.07 | 3.31 | 6.20 | 5.98 | 4.89 | 4.84 |
| BLAKE3 (1 thread) | 0.172 | 0.853 | 0.804 | 0.885 | 5.03 | 5.27 |
| SHA-256 (sha2) | 0.184 | 0.503 | 0.918 | 1.16 | 1.25 | 1.28 |
| SipHash-1-3-128 (siphasher) | 0.713 | 1.73 | 2.72 | 3.16 | 3.23 | 3.35 |

#### Part 1a — one-shot latency, ns per call, 4 MiB window (beyond per-core L2)

| algorithm | 16 B | 64 B | 256 B | 1 KiB | 16 KiB | 1 MiB |
|---|---|---|---|---|---|---|
| XXH3-64 xxhash-rust | 10.7 | 16.5 | 35.3 | 67.3 | 547 | 26402 |
| XXH3-64 twox-hash | 11.0 | 15.8 | 47.6 | 87.0 | 764 | 37171 |
| XXH3-128 xxhash-rust | 15.4 | 23.0 | 48.7 | 88.9 | 645 | 31651 |
| XXH3-128 twox-hash | 15.8 | 23.7 | 61.4 | 99.8 | 742 | 36128 |
| XXH64 xxhash-rust | 16.1 | 31.2 | 68.8 | 145 | 1603 | 94440 |
| XXH64 twox-hash | 15.7 | 40.7 | 66.9 | 198 | 3133 | 200226 |
| BLAKE3 (1 thread) | 102 | 104 | 310 | 1117 | 3433 | 185140 |
| SHA-256 (sha2) | 95.5 | 154 | 292 | 866 | 12484 | 766615 |
| SipHash-1-3-128 (siphasher) | 56.0 | 70.5 | 127 | 359 | 4868 | 293484 |

#### Part 1b — throughput GiB/s, 4 MiB window (beyond per-core L2)

| algorithm | 16 B | 64 B | 256 B | 1 KiB | 16 KiB | 1 MiB |
|---|---|---|---|---|---|---|
| XXH3-64 xxhash-rust | 1.39 | 3.62 | 6.75 | 14.2 | 27.9 | 37.0 |
| XXH3-64 twox-hash | 1.35 | 3.78 | 5.01 | 11.0 | 20.0 | 26.3 |
| XXH3-128 xxhash-rust | 0.966 | 2.60 | 4.89 | 10.7 | 23.6 | 30.9 |
| XXH3-128 twox-hash | 0.941 | 2.52 | 3.88 | 9.56 | 20.6 | 27.0 |
| XXH64 xxhash-rust | 0.924 | 1.91 | 3.47 | 6.57 | 9.52 | 10.3 |
| XXH64 twox-hash | 0.948 | 1.46 | 3.56 | 4.83 | 4.87 | 4.88 |
| BLAKE3 (1 thread) | 0.146 | 0.572 | 0.770 | 0.854 | 4.44 | 5.27 |
| SHA-256 (sha2) | 0.156 | 0.388 | 0.815 | 1.10 | 1.22 | 1.27 |
| SipHash-1-3-128 (siphasher) | 0.266 | 0.845 | 1.88 | 2.66 | 3.13 | 3.33 |

#### Part 2 — canonical encoding vs hashing, graph-node struct (6 fields; name 16–32 B; deps 4–12 × u32), ns per node

| pipeline | avg encoded bytes | encode ns | encode+hash ns | hash share |
|---|---|---|---|---|
| hand LE encoder → XXH3-64 | 86.0 | 18.7 | 25.8 | 28% |
| hand LE encoder → XXH3-128 | 86.0 | 18.8 | 29.2 | 35% |
| hand LE encoder → BLAKE3 | 86.0 | 18.8 | 168 | 89% |
| hand LE encoder → SHA-256 | 86.0 | 18.8 | 143 | 87% |
| streaming fields into Xxh3Default (no buffer) | 86.0 | — | 100 | — |
| postcard::to_slice (reused 512 B buf) → XXH3-64 | 73.3 | 95.0 | 104 | 8% |
| bincode 2 serde encode_into_slice (reused buf) → XXH3-64 | 94.0 | 16.6 | 24.5 | 32% |
| serde_json::to_writer (reused Vec, struct order) → XXH3-64 | 179 | 226 | 245 | 8% |
| #[derive(Hash)] → FxHasher (in-process only) | — | — | 7.37 | — |
| #[derive(Hash)] → foldhash::quality (in-process only) | — | — | 15.9 | — |
| postcard::to_allocvec → XXH3-64 | 73.3 | 221 | 236 | 7% |
| bincode 2 serde (fixint LE) → XXH3-64 | 94.0 | 222 | 222 | 0% |
| serde_json::to_vec (struct order) → XXH3-64 | 179 | 290 | 311 | 7% |
| serde_json sorted keys (via Value/BTreeMap) → XXH3-64 | 179 | 821 | 871 | 6% |
| serde_json sorted keys → SHA-256 | 179 | 859 | 994 | 14% |

("hash share" = (encode+hash − encode)/(encode+hash); serde_json struct-order output is NOT canonical across struct edits; listed for cost only.)
