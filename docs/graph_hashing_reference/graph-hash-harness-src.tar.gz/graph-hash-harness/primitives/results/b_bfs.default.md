<!-- bin=b_bfs cpu="Intel(R) Xeon(R) Processor @ 2.10GHz" rustc="rustc 1.97.0 (2d8144b78 2026-07-07)" rustflags="" compile-time target features beyond SSE2: [] loadavg=0.83 0.70 0.90 reps=7 -->

Graph: N = 1048576 nodes, M = 8388608 directed edges (uniform random endpoints, SplitMix64 seed 42), BFS from node 0 over out-edges.
Reached 1048244 nodes (99.97%).

#### Part 1 — visited set (adjacency = hand CSR), N=1048576, M=8388608

| visited set | BFS ms | vs best | ns / edge scanned | visited-set MiB |
|---|---|---|---|---|
| Vec<bool> | 91.1 | 1.00× | 10.9 | 1.0 |
| fixedbitset::FixedBitSet | 104 | 1.14× | 12.4 | 0.1 |
| roaring::RoaringBitmap | 318 | 3.49× | 37.9 | 0.1 |
| epoch stamps Vec<u32> | 114 | 1.25× | 13.5 | 4.0 |
| HashSet<u32> std SipHash | 629 | 6.90× | 75.0 | 10.0 |
| HashSet<u32> foldhash::fast | 310 | 3.41× | 37.0 | 10.0 |
| HashSet<u32> foldhash::quality | 343 | 3.76× | 40.9 | 10.0 |
| HashSet<u32> FxBuildHasher | 304 | 3.33× | 36.2 | 10.0 |
| HashSet<u32> FxBuildHasher, with_capacity(N) | 271 | 2.97× | 32.3 | 10.0 |
| HashSet<u32> ahash | 359 | 3.94× | 42.8 | 10.0 |
| HashSet<u32> Xxh3DefaultBuilder | 572 | 6.28× | 68.2 | 10.0 |
| HashSet<u32> twox xxhash64::State | 400 | 4.39× | 47.7 | 10.0 |
| HashSet<u32> nohash (identity) | 289 | 3.17× | 34.4 | 10.0 |
| hashbrown::HashSet<u32> default (foldhash) | 307 | 3.37× | 36.6 | 10.0 |

#### Part 1b — visited-set reset cost, N=1048576

| reset | µs |
|---|---|
| Vec<bool>::fill(false) | 86.9 |
| FixedBitSet::clear() | 9.05 |
| epoch += 1 | 0.053 |
| HashSet::clear() (full set, keeps capacity) | 71.2 |

#### Part 2 — adjacency layout (visited = Vec<bool>), N=1048576, M=8388608, 5 reps

| adjacency | build ms | BFS ms | retained MiB | peak MiB during build | bytes/edge |
|---|---|---|---|---|---|
| hand CSR (offsets+targets, counting sort) | 120 | 105 | 36.0 | 40.0 | 4.50 |
| petgraph::csr::Csr (sort+dedup, from_sorted_edges) | 397 | 117 | 40.0 | 104.0 | 5.00 |
| petgraph::Graph (adjacency list, with_capacity) | 162 | 783 | 136.0 | 136.0 | 17.0 |
| HashMap<u32,Vec<u32>> FxBuildHasher | 865 | 250 | 109.7 | 114.0 | 13.7 |
| HashMap<u32,Vec<u32>> foldhash::fast | 1015 | 251 | 109.7 | 114.0 | 13.7 |
| HashMap<u32,Vec<u32>> std SipHash | 1456 | 342 | 109.7 | 114.0 | 13.7 |
| Vec<Vec<u32>> (dense ids, no hashing) | 763 | 180 | 67.7 | 67.7 | 8.46 |
| petgraph GraphMap (IndexMap) std RandomState | 6430 | 648 | 512.2 | 512.2 | 64.0 |
| petgraph GraphMap (IndexMap) FxBuildHasher | 3572 | 578 | 512.2 | 512.2 | 64.0 |
| petgraph GraphMap (IndexMap) foldhash::fast | 4006 | 596 | 512.2 | 512.2 | 64.0 |

#### Part 2b — petgraph::visit::Bfs (library traversal, includes visit-map alloc)

| traversal | BFS ms |
|---|---|
| petgraph::visit::Bfs on Graph (FixedBitSet visit map) | 1001 |
| petgraph::visit::Bfs on csr::Csr (FixedBitSet visit map) | 120 |
| petgraph::visit::Bfs on GraphMap<Fx> (hashbrown HashSet visit map, foldhash) | 829 |

#### Part 3 — graph keyed by sparse random u64 ids, N=1048576, M=8388608

| representation | build ms | BFS ms | retained MiB (graph + id map) |
|---|---|---|---|
| HashMap<u64,Vec<u64>> + HashSet<u64>, std SipHash | 1816 | 1101 | 153.4 |
| HashMap<u64,Vec<u64>> + HashSet<u64>, FxBuildHasher | 1007 | 553 | 153.4 |
| HashMap<u64,Vec<u64>> + HashSet<u64>, foldhash::fast | 1035 | 600 | 153.4 |
| HashMap<u64,Vec<u64>> + HashSet<u64>, nohash (ids are random) | 989 | 539 | 153.4 |
| relabel u64→u32 (HashMap<u64,u32,Fx>) + hand CSR + Vec<bool> | 457 | 104 | 70.0 |
