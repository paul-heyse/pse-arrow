<!-- bin=f_db_integers cpu="Intel(R) Xeon(R) Processor @ 2.10GHz" rustc="rustc 1.97.0 (2d8144b78 2026-07-07)" rustflags="" compile-time target features beyond SSE2: [] loadavg=0.52 0.43 0.87 reps=7 -->

#### 1. u64 → i64 bit-cast (`h as i64`, back with `s as u64`) — lossless; 1,000,000 random round trips asserted

| u64 (hex) | as i64 (bit-cast) | (h ^ 1<<63) as i64 (order-preserving) | 16-char hex |
|---|---|---|---|
| 0x0000000000000000 | 0 | -9223372036854775808 | 0000000000000000 |
| 0x0000000000000001 | 1 | -9223372036854775807 | 0000000000000001 |
| 0x7fffffffffffffff | 9223372036854775807 | -1 | 7fffffffffffffff |
| 0x8000000000000000 | -9223372036854775808 | 0 | 8000000000000000 |
| 0x8000000000000001 | -9223372036854775807 | 1 | 8000000000000001 |
| 0xffffffffffffffff | -1 | 9223372036854775807 | ffffffffffffffff |

Random u64 fingerprints that become negative i64: 500088 / 1000000 (50.01%).

#### 2. Sort order of 200,000 random fingerprints vs unsigned u64 order (positions identical)

| ordering key | positions equal to u64 order | note |
|---|---|---|
| u64 | 100% | reference |
| h as i64 (bit-cast) | 0.00% | values ≥ 2^63 sort first (negative); wrap at index 100011 |
| (h ^ 1<<63) as i64 | 100.00% | order-preserving; DB `ORDER BY` / range scans match u64 |
| format!("{h:016x}") zero-padded hex | 100.00% | lexicographic == numeric when fixed width |
| format!("{h:x}") unpadded hex | 0.01% | WRONG: variable width |
| h.to_string() decimal | 0.00% | WRONG: variable width |

#### 2b. Range partitions by top 2 bits: the bit-cast column puts shards 2–3 *below* shards 0–1

| shard | u64 range | bit-cast i64 range | sign-flipped i64 range |
|---|---|---|---|
| shard 0 | [0x0000000000000000, 0x3fffffffffffffff] | [0, 4611686018427387903] | [-9223372036854775808, -4611686018427387905] |
| shard 1 | [0x4000000000000000, 0x7fffffffffffffff] | [4611686018427387904, 9223372036854775807] | [-4611686018427387904, -1] |
| shard 2 | [0x8000000000000000, 0xbfffffffffffffff] | [-9223372036854775808, -4611686018427387905] | [0, 4611686018427387903] |
| shard 3 | [0xc000000000000000, 0xffffffffffffffff] | [-4611686018427387904, -1] | [4611686018427387904, 9223372036854775807] |

#### 3. 128-bit fingerprint storage: XXH3-128("node:42")

| form | value | round trip | sort == u128 order |
|---|---|---|---|
| u128 | 40730759286533844829196621875188843942 | — | 100% |
| 32-char hex (== python `xxh3_128_hexdigest`) | 1ea4757a4200fc7978aedbffed07c5a6 | ok | 100.0% |
| 16 bytes big-endian (`to_be_bytes`, == python `digest()`) | 1ea4757a4200fc7978aedbffed07c5a6 | ok | memcmp order = u128 order |
| (hi as i64, lo as i64) two BIGINT columns | (2208018885272206457, 8696129822738859430) | ok | 0.0% |
| (hi^2^63, lo^2^63) as i64 two BIGINT columns | (-7015353151582569351, -527242214115916378) | ok (xor back) | 100.0% |

4. Cross-language vectors: run `cargo run --release --bin f_db_integers -- --json > vec.json && python3 scripts/check_python.py vec.json`.
