<!-- bin=c_fingerprint cpu="Intel(R) Xeon(R) Processor @ 2.10GHz" rustc="rustc 1.97.0 (2d8144b78 2026-07-07)" rustflags="" compile-time target features beyond SSE2: [] loadavg=0.06 0.08 0.30 reps=7 -->

#### Part 1a — one-shot latency, ns per call, cache-hot window max(16 KiB, 2×size)

| algorithm | 16 B | 64 B | 256 B | 1 KiB | 16 KiB | 1 MiB |
|---|---|---|---|---|---|---|
| XXH3-64 xxhash-rust | 4.35 | 6.60 | 22.2 | 57.7 | 830 | 54436 |
| XXH3-64 twox-hash | 4.62 | 7.00 | 21.2 | 41.2 | 464 | 35862 |
| XXH3-128 xxhash-rust | 6.74 | 9.74 | 26.8 | 61.9 | 817 | 54434 |
| XXH3-128 twox-hash | 6.94 | 10.2 | 28.9 | 49.3 | 458 | 35624 |
| XXH64 xxhash-rust | 6.94 | 17.7 | 36.6 | 105 | 1472 | 96918 |
| XXH64 twox-hash | 6.85 | 17.0 | 36.5 | 105 | 1463 | 97130 |
| BLAKE3 (1 thread) | 62.6 | 71.3 | 280 | 1055 | 3010 | 186496 |
| SHA-256 (sha2) | 74.6 | 117 | 249 | 815 | 12085 | 767150 |
| SipHash-1-3-128 (siphasher) | 20.9 | 34.5 | 87.2 | 304 | 4625 | 298871 |

#### Part 1b — throughput GiB/s, cache-hot window max(16 KiB, 2×size)

| algorithm | 16 B | 64 B | 256 B | 1 KiB | 16 KiB | 1 MiB |
|---|---|---|---|---|---|---|
| XXH3-64 xxhash-rust | 3.43 | 9.03 | 10.7 | 16.5 | 18.4 | 17.9 |
| XXH3-64 twox-hash | 3.23 | 8.51 | 11.2 | 23.2 | 32.9 | 27.2 |
| XXH3-128 xxhash-rust | 2.21 | 6.12 | 8.90 | 15.4 | 18.7 | 17.9 |
| XXH3-128 twox-hash | 2.15 | 5.83 | 8.24 | 19.3 | 33.3 | 27.4 |
| XXH64 xxhash-rust | 2.15 | 3.36 | 6.51 | 9.07 | 10.4 | 10.1 |
| XXH64 twox-hash | 2.18 | 3.50 | 6.52 | 9.10 | 10.4 | 10.1 |
| BLAKE3 (1 thread) | 0.238 | 0.836 | 0.853 | 0.904 | 5.07 | 5.24 |
| SHA-256 (sha2) | 0.200 | 0.510 | 0.959 | 1.17 | 1.26 | 1.27 |
| SipHash-1-3-128 (siphasher) | 0.713 | 1.73 | 2.73 | 3.14 | 3.30 | 3.27 |

#### Part 1a — one-shot latency, ns per call, 4 MiB window (beyond per-core L2)

| algorithm | 16 B | 64 B | 256 B | 1 KiB | 16 KiB | 1 MiB |
|---|---|---|---|---|---|---|
| XXH3-64 xxhash-rust | 10.5 | 16.5 | 57.9 | 112 | 949 | 60529 |
| XXH3-64 twox-hash | 10.7 | 17.0 | 51.8 | 89.8 | 677 | 44314 |
| XXH3-128 xxhash-rust | 14.7 | 24.6 | 63.0 | 120 | 930 | 69065 |
| XXH3-128 twox-hash | 15.4 | 23.5 | 67.9 | 99.0 | 655 | 40118 |
| XXH64 xxhash-rust | 14.7 | 32.6 | 71.6 | 142 | 1523 | 102585 |
| XXH64 twox-hash | 14.1 | 32.4 | 70.7 | 147 | 1503 | 96431 |
| BLAKE3 (1 thread) | 93.6 | 105 | 318 | 1106 | 3164 | 209385 |
| SHA-256 (sha2) | 90.8 | 149 | 301 | 869 | 12413 | 791839 |
| SipHash-1-3-128 (siphasher) | 57.3 | 72.0 | 140 | 358 | 4775 | 323876 |

#### Part 1b — throughput GiB/s, 4 MiB window (beyond per-core L2)

| algorithm | 16 B | 64 B | 256 B | 1 KiB | 16 KiB | 1 MiB |
|---|---|---|---|---|---|---|
| XXH3-64 xxhash-rust | 1.42 | 3.61 | 4.12 | 8.55 | 16.1 | 16.1 |
| XXH3-64 twox-hash | 1.39 | 3.51 | 4.60 | 10.6 | 22.6 | 22.0 |
| XXH3-128 xxhash-rust | 1.02 | 2.42 | 3.78 | 7.96 | 16.4 | 14.1 |
| XXH3-128 twox-hash | 0.968 | 2.53 | 3.51 | 9.63 | 23.3 | 24.3 |
| XXH64 xxhash-rust | 1.02 | 1.83 | 3.33 | 6.71 | 10.0 | 9.52 |
| XXH64 twox-hash | 1.06 | 1.84 | 3.37 | 6.48 | 10.2 | 10.1 |
| BLAKE3 (1 thread) | 0.159 | 0.566 | 0.750 | 0.863 | 4.82 | 4.66 |
| SHA-256 (sha2) | 0.164 | 0.401 | 0.792 | 1.10 | 1.23 | 1.23 |
| SipHash-1-3-128 (siphasher) | 0.260 | 0.828 | 1.71 | 2.66 | 3.20 | 3.02 |

#### Part 2 — canonical encoding vs hashing, graph-node struct (6 fields; name 16–32 B; deps 4–12 × u32), ns per node

| pipeline | avg encoded bytes | encode ns | encode+hash ns | hash share |
|---|---|---|---|---|
| hand LE encoder → XXH3-64 | 86.0 | 18.8 | 25.9 | 28% |
| hand LE encoder → XXH3-128 | 86.0 | 18.6 | 29.7 | 37% |
| hand LE encoder → BLAKE3 | 86.0 | 18.8 | 163 | 88% |
| hand LE encoder → SHA-256 | 86.0 | 19.5 | 143 | 86% |
| streaming fields into Xxh3Default (no buffer) | 86.0 | — | 99.0 | — |
| postcard::to_slice (reused 512 B buf) → XXH3-64 | 73.3 | 95.9 | 106 | 10% |
| bincode 2 serde encode_into_slice (reused buf) → XXH3-64 | 94.0 | 12.4 | 21.3 | 42% |
| serde_json::to_writer (reused Vec, struct order) → XXH3-64 | 179 | 226 | 241 | 6% |
| #[derive(Hash)] → FxHasher (in-process only) | — | — | 7.43 | — |
| #[derive(Hash)] → foldhash::quality (in-process only) | — | — | 15.7 | — |
| postcard::to_allocvec → XXH3-64 | 73.3 | 202 | 212 | 5% |
| bincode 2 serde (fixint LE) → XXH3-64 | 94.0 | 154 | 145 | 0% |
| serde_json::to_vec (struct order) → XXH3-64 | 179 | 286 | 300 | 5% |
| serde_json sorted keys (via Value/BTreeMap) → XXH3-64 | 179 | 828 | 858 | 3% |
| serde_json sorted keys → SHA-256 | 179 | 806 | 984 | 18% |

("hash share" = (encode+hash − encode)/(encode+hash); serde_json struct-order output is NOT canonical across struct edits; listed for cost only.)
