<!-- bin=a_hashmap_keys cpu="Intel(R) Xeon(R) Processor @ 2.10GHz" rustc="rustc 1.97.0 (2d8144b78 2026-07-07)" rustflags="-C target-cpu=native" compile-time target features beyond SSE2: [sse4.2,avx2,avx512f,aes] loadavg=1.16 0.85 0.91 reps=7 -->

### n = 1048576 keys


#### u32 dense node ids (0..n, shuffled), n=1048576

| variant | insert ns/op | hit ns/op | miss ns/op | hit vs best |
|---|---|---|---|---|
| std RandomState (SipHash-1-3) | 74.4 | 55.3 | 21.3 | 16.30× |
| foldhash::fast | 49.9 | 14.7 | 4.90 | 4.32× |
| foldhash::quality | 47.8 | 15.7 | 5.55 | 4.61× |
| rustc-hash FxBuildHasher | 41.5 | 13.5 | 3.56 | 3.97× |
| ahash RandomState | 48.8 | 14.1 | 5.36 | 4.15× |
| xxhash-rust Xxh3DefaultBuilder | 73.2 | 40.5 | 15.3 | 11.93× |
| twox-hash xxhash64::State | 73.5 | 41.9 | 16.8 | 12.36× |
| hashbrown + DefaultHashBuilder (foldhash) | 45.1 | 13.9 | 5.16 | 4.11× |
| hashbrown + FxBuildHasher | 37.1 | 15.1 | 3.63 | 4.46× |
| nohash (identity; NOT valid for raw ids) | 79.2 | 6.79 | 1.59 | 2.00× |
| dense Vec<u32> index (baseline) | 5.40 | 3.39 | 0.936 | 1.00× |
| sorted Vec + binary_search | 25.4 | 187 | 36.0 | 55.07× |

#### u32 sparse random ids, n=1048576

| variant | insert ns/op | hit ns/op | miss ns/op | hit vs best |
|---|---|---|---|---|
| std RandomState (SipHash-1-3) | 99.2 | 87.9 | 26.1 | 6.47× |
| foldhash::fast | 50.2 | 14.7 | 4.84 | 1.08× |
| foldhash::quality | 54.3 | 17.7 | 5.68 | 1.30× |
| rustc-hash FxBuildHasher | 48.0 | 15.3 | 7.52 | 1.13× |
| ahash RandomState | 50.0 | 13.6 | 5.62 | 1.00× |
| xxhash-rust Xxh3DefaultBuilder | 73.6 | 43.5 | 15.7 | 3.20× |
| twox-hash xxhash64::State | 77.5 | 47.7 | 19.4 | 3.51× |
| hashbrown + DefaultHashBuilder (foldhash) | 46.5 | 16.0 | 5.03 | 1.18× |
| hashbrown + FxBuildHasher | 40.5 | 15.3 | 4.70 | 1.13× |
| nohash (identity; NOT valid for raw ids) | 93.3 | 22.7 | 56.0 | 1.67× |
| sorted Vec + binary_search | 26.3 | 214 | 217 | 15.78× |

#### u64 pre-hashed fingerprints, n=1048576

| variant | insert ns/op | hit ns/op | miss ns/op | hit vs best |
|---|---|---|---|---|
| std RandomState (SipHash-1-3) | 100 | 77.4 | 27.5 | 4.58× |
| foldhash::fast | 52.8 | 18.5 | 6.58 | 1.09× |
| foldhash::quality | 53.0 | 20.6 | 7.09 | 1.22× |
| rustc-hash FxBuildHasher | 53.9 | 18.0 | 6.01 | 1.06× |
| ahash RandomState | 55.0 | 18.1 | 6.86 | 1.07× |
| xxhash-rust Xxh3DefaultBuilder | 92.8 | 51.8 | 19.1 | 3.06× |
| twox-hash xxhash64::State | 95.1 | 57.3 | 21.6 | 3.39× |
| hashbrown + DefaultHashBuilder (foldhash) | 48.3 | 18.7 | 6.64 | 1.11× |
| hashbrown + FxBuildHasher | 52.7 | 18.7 | 6.20 | 1.10× |
| nohash-hasher (identity; valid: key is already a hash) | 53.8 | 16.9 | 5.24 | 1.00× |
| sorted Vec + binary_search | 36.9 | 303 | 284 | 17.93× |

#### (u32,u32) edge tuples, n=1048576

| variant | insert ns/op | hit ns/op | miss ns/op | hit vs best |
|---|---|---|---|---|
| std RandomState (SipHash-1-3) | 110 | 98.0 | 33.2 | 5.51× |
| foldhash::fast | 59.4 | 17.8 | 6.08 | 1.00× |
| foldhash::quality | 58.2 | 20.6 | 6.64 | 1.16× |
| rustc-hash FxBuildHasher | 60.7 | 18.7 | 6.91 | 1.05× |
| ahash RandomState | 68.2 | 19.8 | 7.83 | 1.11× |
| xxhash-rust Xxh3DefaultBuilder | 124 | 73.7 | 25.2 | 4.15× |
| twox-hash xxhash64::State | 234 | 208 | 57.5 | 11.70× |
| hashbrown + DefaultHashBuilder (foldhash) | 53.1 | 18.0 | 5.81 | 1.01× |
| hashbrown + FxBuildHasher | 57.7 | 18.4 | 6.19 | 1.03× |
| sorted Vec + binary_search | 40.5 | 390 | 373 | 21.91× |

#### &str keys, 16–32 bytes, n=1048576

| variant | insert ns/op | hit ns/op | miss ns/op | hit vs best |
|---|---|---|---|---|
| std RandomState (SipHash-1-3) | 405 | 179 | 55.5 | 2.66× |
| foldhash::fast | 175 | 78.5 | 23.6 | 1.17× |
| foldhash::quality | 174 | 82.1 | 23.3 | 1.23× |
| rustc-hash FxBuildHasher | 154 | 71.3 | 19.6 | 1.06× |
| ahash RandomState | 165 | 67.0 | 19.9 | 1.00× |
| xxhash-rust Xxh3DefaultBuilder | 391 | 237 | 65.0 | 3.53× |
| twox-hash xxhash64::State | 402 | 224 | 76.8 | 3.34× |
| hashbrown + DefaultHashBuilder (foldhash) | 170 | 80.8 | 23.6 | 1.21× |
| hashbrown + FxBuildHasher | 192 | 72.8 | 21.0 | 1.09× |
| sorted Vec + binary_search | 231 | 2035 | 2156 | 30.36× |

### n = 16384 keys


#### u32 dense node ids (0..n, shuffled), n=16384

| variant | insert ns/op | hit ns/op | miss ns/op | hit vs best |
|---|---|---|---|---|
| std RandomState (SipHash-1-3) | 39.1 | 12.6 | 10.9 | 24.44× |
| foldhash::fast | 22.4 | 2.79 | 2.37 | 5.40× |
| foldhash::quality | 23.0 | 3.26 | 2.69 | 6.31× |
| rustc-hash FxBuildHasher | 19.0 | 2.45 | 1.44 | 4.75× |
| ahash RandomState | 23.5 | 3.42 | 2.91 | 6.62× |
| xxhash-rust Xxh3DefaultBuilder | 35.5 | 9.47 | 10.9 | 18.33× |
| twox-hash xxhash64::State | 38.5 | 10.2 | 10.7 | 19.66× |
| hashbrown + DefaultHashBuilder (foldhash) | 21.9 | 2.85 | 2.23 | 5.53× |
| hashbrown + FxBuildHasher | 18.0 | 2.60 | 1.43 | 5.04× |
| nohash (identity; NOT valid for raw ids) | 42.8 | 1.72 | 1.15 | 3.33× |
| dense Vec<u32> index (baseline) | 1.50 | 0.516 | 0.606 | 1.00× |
| sorted Vec + binary_search | 16.7 | 26.8 | 18.6 | 51.93× |

#### u32 sparse random ids, n=16384

| variant | insert ns/op | hit ns/op | miss ns/op | hit vs best |
|---|---|---|---|---|
| std RandomState (SipHash-1-3) | 38.5 | 12.2 | 10.8 | 4.79× |
| foldhash::fast | 22.7 | 2.76 | 2.47 | 1.08× |
| foldhash::quality | 22.7 | 3.26 | 2.68 | 1.28× |
| rustc-hash FxBuildHasher | 21.5 | 2.55 | 2.27 | 1.00× |
| ahash RandomState | 23.1 | 3.43 | 2.92 | 1.35× |
| xxhash-rust Xxh3DefaultBuilder | 34.9 | 9.34 | 10.6 | 3.67× |
| twox-hash xxhash64::State | 39.0 | 9.94 | 10.6 | 3.90× |
| hashbrown + DefaultHashBuilder (foldhash) | 21.3 | 2.74 | 2.28 | 1.08× |
| hashbrown + FxBuildHasher | 20.1 | 2.67 | 2.18 | 1.05× |
| nohash (identity; NOT valid for raw ids) | 49.9 | 12.1 | 23.5 | 4.76× |
| sorted Vec + binary_search | 16.6 | 26.8 | 26.7 | 10.54× |

#### u64 pre-hashed fingerprints, n=16384

| variant | insert ns/op | hit ns/op | miss ns/op | hit vs best |
|---|---|---|---|---|
| std RandomState (SipHash-1-3) | 46.9 | 14.9 | 12.9 | 6.42× |
| foldhash::fast | 24.3 | 2.87 | 2.27 | 1.24× |
| foldhash::quality | 24.4 | 3.35 | 2.74 | 1.44× |
| rustc-hash FxBuildHasher | 23.1 | 2.66 | 2.34 | 1.14× |
| ahash RandomState | 25.1 | 3.28 | 2.62 | 1.41× |
| xxhash-rust Xxh3DefaultBuilder | 37.5 | 9.26 | 10.6 | 3.99× |
| twox-hash xxhash64::State | 42.8 | 11.5 | 11.4 | 4.96× |
| hashbrown + DefaultHashBuilder (foldhash) | 23.2 | 2.87 | 2.30 | 1.24× |
| hashbrown + FxBuildHasher | 22.4 | 2.82 | 2.69 | 1.21× |
| nohash-hasher (identity; valid: key is already a hash) | 24.0 | 2.32 | 1.87 | 1.00× |
| sorted Vec + binary_search | 23.3 | 33.2 | 32.9 | 14.26× |

#### (u32,u32) edge tuples, n=16384

| variant | insert ns/op | hit ns/op | miss ns/op | hit vs best |
|---|---|---|---|---|
| std RandomState (SipHash-1-3) | 57.6 | 20.2 | 17.2 | 6.10× |
| foldhash::fast | 24.3 | 3.33 | 2.59 | 1.01× |
| foldhash::quality | 25.5 | 3.91 | 3.08 | 1.18× |
| rustc-hash FxBuildHasher | 24.2 | 3.41 | 2.87 | 1.03× |
| ahash RandomState | 26.0 | 4.42 | 3.62 | 1.34× |
| xxhash-rust Xxh3DefaultBuilder | 55.2 | 17.1 | 18.0 | 5.16× |
| twox-hash xxhash64::State | 103 | 43.2 | 30.0 | 13.06× |
| hashbrown + DefaultHashBuilder (foldhash) | 23.4 | 3.31 | 2.56 | 1.00× |
| hashbrown + FxBuildHasher | 23.0 | 3.59 | 2.86 | 1.09× |
| sorted Vec + binary_search | 25.0 | 60.1 | 59.3 | 18.17× |

#### &str keys, 16–32 bytes, n=16384

| variant | insert ns/op | hit ns/op | miss ns/op | hit vs best |
|---|---|---|---|---|
| std RandomState (SipHash-1-3) | 119 | 40.3 | 35.3 | 3.67× |
| foldhash::fast | 39.0 | 13.3 | 7.48 | 1.21× |
| foldhash::quality | 41.9 | 13.5 | 7.88 | 1.23× |
| rustc-hash FxBuildHasher | 37.8 | 11.6 | 5.54 | 1.05× |
| ahash RandomState | 40.9 | 11.0 | 6.77 | 1.00× |
| xxhash-rust Xxh3DefaultBuilder | 111 | 48.6 | 28.8 | 4.43× |
| twox-hash xxhash64::State | 134 | 53.5 | 38.0 | 4.87× |
| hashbrown + DefaultHashBuilder (foldhash) | 38.1 | 12.8 | 7.61 | 1.17× |
| hashbrown + FxBuildHasher | 37.3 | 11.6 | 5.81 | 1.06× |
| sorted Vec + binary_search | 72.9 | 235 | 205 | 21.44× |

#### Memory, n = 1048576 entries, no pre-sizing (allocator-counted)

| structure | MiB | bytes/entry |
|---|---|---|
| HashMap<u32,u32,Fx> | 18.0 | 18.0 |
| HashMap<u64,u32,Fx> | 34.0 | 34.0 |
| HashMap<(u32,u32),u32,Fx> | 26.0 | 26.0 |
| Vec<u32> dense index | 4.0 | 4.0 |
