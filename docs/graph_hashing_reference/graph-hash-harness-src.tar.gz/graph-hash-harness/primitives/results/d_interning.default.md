<!-- bin=d_interning cpu="Intel(R) Xeon(R) Processor @ 2.10GHz" rustc="rustc 1.97.0 (2d8144b78 2026-07-07)" rustflags="" compile-time target features beyond SSE2: [] loadavg=0.52 0.43 0.87 reps=7 -->

### heavy duplication: 2^20 strings from 2^16-word vocabulary (skewed)

inputs = 1048576, distinct = 65533, avg len = 24.9 B, distinct payload = 1.6 MiB

#### Interning — heavy duplication: 2^20 strings from 2^16-word vocabulary (skewed)

| interner | id type | intern ns/string | resolve ns/id | retained MiB (excl. id vector) | bytes per distinct string |
|---|---|---|---|---|---|
| lasso::Rodeo (default: std RandomState) | u32 dense (Spur) | 90.3 | 1.02 | 4.2 | 66.9 |
| lasso::Rodeo<Spur, FxBuildHasher> | u32 dense (Spur) | 42.9 | 1.02 | 4.2 | 66.9 |
| string-interner StringInterner (default: foldhash, StringBackend) | u32 dense (SymbolU32) | 32.3 | 1.57 | 3.1 | 49.0 |
| HashMap<String,u32,Fx> + Vec<String> reverse | u32 dense | 39.2 | 1.42 | 8.8 | 141 |
| arena String + spans + hashbrown::HashTable<u32> keyed by XXH3-64 (hand) | u32 dense | 32.9 | 4.96 | 3.1 | 49.0 |
| hash-as-id: XXH3-64(str), no table | u64 sparse (not resolvable) | 7.55 | – | 0.0 | 0.000 |
| hash-as-id: XXH3-64(str) + HashMap<u64,String,nohash> reverse | u64 sparse | 22.6 | 4.97 | 5.7 | 91.3 |

Id vector cost for 1048576 references: u32 ids = 4.0 MiB, u64 ids = 8.0 MiB.

### all distinct: 2^20 unique strings

inputs = 1048576, distinct = 1048576, avg len = 26.4 B, distinct payload = 26.4 MiB

#### Interning — all distinct: 2^20 unique strings

| interner | id type | intern ns/string | resolve ns/id | retained MiB (excl. id vector) | bytes per distinct string |
|---|---|---|---|---|---|
| lasso::Rodeo (default: std RandomState) | u32 dense (Spur) | 569 | 2.54 | 67.0 | 67.0 |
| lasso::Rodeo<Spur, FxBuildHasher> | u32 dense (Spur) | 196 | 2.11 | 67.0 | 67.0 |
| string-interner StringInterner (default: foldhash, StringBackend) | u32 dense (SymbolU32) | 169 | 1.65 | 61.0 | 61.0 |
| HashMap<String,u32,Fx> + Vec<String> reverse | u32 dense | 394 | 3.17 | 142.9 | 143 |
| arena String + spans + hashbrown::HashTable<u32> keyed by XXH3-64 (hand) | u32 dense | 288 | 3.37 | 61.0 | 61.0 |
| hash-as-id: XXH3-64(str), no table | u64 sparse (not resolvable) | 8.99 | – | 0.0 | 0.000 |
| hash-as-id: XXH3-64(str) + HashMap<u64,String,nohash> reverse | u64 sparse | 165 | 17.9 | 92.4 | 92.4 |

Id vector cost for 1048576 references: u32 ids = 4.0 MiB, u64 ids = 8.0 MiB.
