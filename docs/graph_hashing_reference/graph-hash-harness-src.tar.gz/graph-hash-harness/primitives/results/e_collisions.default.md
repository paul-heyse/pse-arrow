<!-- bin=e_collisions cpu="Intel(R) Xeon(R) Processor @ 2.10GHz" rustc="rustc 1.97.0 (2d8144b78 2026-07-07)" rustflags="" compile-time target features beyond SSE2: [] loadavg=0.47 0.66 0.78 reps=7 -->

#### Observed colliding pairs vs birthday estimate n(n−1)/2^(b+1); XXH3-64 seeded, mean of 5 seeds

| bits b | n | items | expected pairs | observed (low b bits) | obs/exp | observed (high b bits) | obs/exp | items lost to dedup (low) |
|---|---|---|---|---|---|---|---|---|
| 24 | 16384 | u64 LE counter | 8.00 | 8.20 | 1.03 | 7.60 | 0.95 | 8.20 |
| 24 | 16384 | "node:{i}" string | 8.00 | 7.40 | 0.93 | 8.80 | 1.10 | 7.40 |
| 24 | 65536 | u64 LE counter | 128 | 134 | 1.05 | 127 | 0.99 | 134 |
| 24 | 65536 | "node:{i}" string | 128 | 135 | 1.05 | 128 | 1.00 | 134 |
| 24 | 262144 | u64 LE counter | 2048 | 2101 | 1.03 | 2023 | 0.99 | 2089 |
| 24 | 262144 | "node:{i}" string | 2048 | 2063 | 1.01 | 2029 | 0.99 | 2054 |
| 28 | 65536 | u64 LE counter | 8.00 | 7.60 | 0.95 | 8.00 | 1.00 | 7.60 |
| 28 | 65536 | "node:{i}" string | 8.00 | 8.40 | 1.05 | 5.60 | 0.70 | 8.40 |
| 28 | 262144 | u64 LE counter | 128 | 139 | 1.09 | 125 | 0.98 | 139 |
| 28 | 262144 | "node:{i}" string | 128 | 129 | 1.01 | 130 | 1.01 | 129 |
| 28 | 1048576 | u64 LE counter | 2048 | 2086 | 1.02 | 2112 | 1.03 | 2083 |
| 28 | 1048576 | "node:{i}" string | 2048 | 2032 | 0.99 | 2052 | 1.00 | 2030 |
| 32 | 262144 | u64 LE counter | 8.00 | 8.60 | 1.08 | 9.00 | 1.13 | 8.60 |
| 32 | 262144 | "node:{i}" string | 8.00 | 8.80 | 1.10 | 8.20 | 1.03 | 8.80 |
| 32 | 1048576 | u64 LE counter | 128 | 122 | 0.95 | 134 | 1.04 | 122 |
| 32 | 1048576 | "node:{i}" string | 128 | 131 | 1.02 | 128 | 1.00 | 131 |
| 32 | 4194304 | u64 LE counter | 2048 | 2011 | 0.98 | 2071 | 1.01 | 2011 |
| 32 | 4194304 | "node:{i}" string | 2048 | 2055 | 1.00 | 2031 | 0.99 | 2054 |
| 36 | 1048576 | u64 LE counter | 8.00 | 6.80 | 0.85 | 6.60 | 0.83 | 6.80 |
| 36 | 1048576 | "node:{i}" string | 8.00 | 5.80 | 0.73 | 7.40 | 0.93 | 5.80 |
| 36 | 4194304 | u64 LE counter | 128 | 125 | 0.98 | 127 | 0.99 | 125 |
| 36 | 4194304 | "node:{i}" string | 128 | 134 | 1.05 | 117 | 0.92 | 134 |
| 36 | 16777216 | u64 LE counter | 2048 | 2044 | 1.00 | 2102 | 1.03 | 2044 |
| 36 | 16777216 | "node:{i}" string | 2048 | 2057 | 1.00 | 2026 | 0.99 | 2057 |

#### Map-hasher outputs are not fingerprints: FxHash (rustc-hash 2.x) of integer ids, truncated

| bits b | n | random-model expected pairs | Fx(i) low bits | Fx(i) high bits | Fx(i·4096) low bits | XXH3(i·4096) low bits |
|---|---|---|---|---|---|---|
| 24 | 65536 | 128 | 0 | 0 | 0 | 120 |
| 32 | 1048576 | 128 | 0 | 0 | 0 | 135 |

#### String keys "node:{i}", colliding pairs under truncation (low bits / high bits)

| bits b | n | random-model expected | FxHash (rustc-hash 2) | foldhash::fast fixed | foldhash::quality fixed | XXH3-64 |
|---|---|---|---|---|---|---|
| 24 | 65536 | 128 | 119 / 140 | 131 / 117 | 131 / 116 | 120 / 143 |
| 32 | 1048576 | 128 | 154 / 124 | 114 / 133 | 133 / 139 | 132 / 123 |

#### Extrapolation: expected colliding pairs / P(≥1 collision), random-oracle model

| bits | n = 1e6 | n = 1e8 | n = 1e9 | n = 1e12 |
|---|---|---|---|---|
| 32 | 116 / 1.00 | 1.16e6 / 1.00 | 1.16e8 / 1.00 | 1.16e14 / 1.00 |
| 48 | 0.002 / 0.002 | 17.8 / 1.000 | 1776 / 1.00 | 1.78e9 / 1.00 |
| 64 | 2.71e-8 / 2.71e-8 | 2.71e-4 / 2.71e-4 | 0.027 / 0.027 | 27105 / 1.00 |
| 96 | 6.31e-18 / 6.31e-18 | 6.31e-14 / 6.31e-14 | 6.31e-12 / 6.31e-12 | 6.31e-6 / 6.31e-6 |
| 128 | 1.47e-27 / 1.47e-27 | 1.47e-23 / 1.47e-23 | 1.47e-21 / 1.47e-21 | 1.47e-15 / 1.47e-15 |

#### Items n at which P(≥1 collision) reaches p

| bits | p = 1e-6 | p = 1e-3 | p = 0.5 |
|---|---|---|---|
| 32 | 92.7 | 2932 | 77163 |
| 64 | 6.07e6 | 1.92e8 | 5.06e9 |
| 128 | 2.61e16 | 8.25e17 | 2.17e19 |
