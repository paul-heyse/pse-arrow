<!-- bin=c_fingerprint cpu="Intel(R) Xeon(R) Processor @ 2.10GHz" rustc="rustc 1.97.0 (2d8144b78 2026-07-07)" rustflags="-C target-cpu=native" compile-time target features beyond SSE2: [sse4.2,avx2,avx512f,aes] loadavg=0.90 0.75 0.88 reps=7 -->

#### Part 1a — one-shot latency, ns per call, cache-hot window max(16 KiB, 2×size)

| algorithm | 16 B | 64 B | 256 B | 1 KiB | 16 KiB | 1 MiB |
|---|---|---|---|---|---|---|
| XXH3-64 xxhash-rust | 4.24 | 6.70 | 15.7 | 32.0 | 349 | 24122 |
| XXH3-64 twox-hash | 4.54 | 6.87 | 26.2 | 46.0 | 474 | 34102 |
| XXH3-128 xxhash-rust | 6.71 | 9.88 | 25.2 | 42.3 | 405 | 25995 |
| XXH3-128 twox-hash | 7.31 | 9.93 | 28.1 | 47.6 | 457 | 33510 |
| XXH64 xxhash-rust | 7.58 | 16.9 | 36.8 | 108 | 1578 | 96688 |
| XXH64 twox-hash | 7.39 | 17.9 | 38.3 | 163 | 3061 | 205104 |
| BLAKE3 (1 thread) | 91.6 | 69.7 | 294 | 1077 | 3054 | 247896 |
| SHA-256 (sha2) | 81.8 | 118 | 261 | 838 | 12301 | 959442 |
| SipHash-1-3-128 (siphasher) | 22.3 | 34.1 | 87.4 | 329 | 4765 | 419314 |

#### Part 1b — throughput GiB/s, cache-hot window max(16 KiB, 2×size)

| algorithm | 16 B | 64 B | 256 B | 1 KiB | 16 KiB | 1 MiB |
|---|---|---|---|---|---|---|
| XXH3-64 xxhash-rust | 3.51 | 8.90 | 15.2 | 29.8 | 43.7 | 40.5 |
| XXH3-64 twox-hash | 3.28 | 8.68 | 9.10 | 20.7 | 32.2 | 28.6 |
| XXH3-128 xxhash-rust | 2.22 | 6.03 | 9.47 | 22.6 | 37.7 | 37.6 |
| XXH3-128 twox-hash | 2.04 | 6.00 | 8.48 | 20.0 | 33.4 | 29.1 |
| XXH64 xxhash-rust | 1.97 | 3.53 | 6.49 | 8.85 | 9.67 | 10.1 |
| XXH64 twox-hash | 2.02 | 3.33 | 6.23 | 5.84 | 4.98 | 4.76 |
| BLAKE3 (1 thread) | 0.163 | 0.855 | 0.812 | 0.885 | 5.00 | 3.94 |
| SHA-256 (sha2) | 0.182 | 0.504 | 0.914 | 1.14 | 1.24 | 1.02 |
| SipHash-1-3-128 (siphasher) | 0.670 | 1.75 | 2.73 | 2.90 | 3.20 | 2.33 |

#### Part 1a — one-shot latency, ns per call, 4 MiB window (beyond per-core L2)

| algorithm | 16 B | 64 B | 256 B | 1 KiB | 16 KiB | 1 MiB |
|---|---|---|---|---|---|---|
| XXH3-64 xxhash-rust | 10.7 | 16.9 | 37.8 | 74.1 | 468 | 31496 |
| XXH3-64 twox-hash | 10.9 | 18.5 | 48.9 | 97.2 | 654 | 40245 |
| XXH3-128 xxhash-rust | 15.1 | 24.5 | 56.1 | 94.9 | 559 | 36049 |
| XXH3-128 twox-hash | 17.7 | 24.6 | 64.5 | 104 | 673 | 39443 |
| XXH64 xxhash-rust | 16.9 | 31.2 | 70.8 | 152 | 1529 | 95470 |
| XXH64 twox-hash | 16.0 | 40.6 | 74.5 | 208 | 3140 | 200875 |
| BLAKE3 (1 thread) | 102 | 104 | 323 | 1127 | 3264 | 190125 |
| SHA-256 (sha2) | 101 | 152 | 308 | 915 | 12627 | 772861 |
| SipHash-1-3-128 (siphasher) | 56.3 | 73.2 | 135 | 362 | 4815 | 292947 |

#### Part 1b — throughput GiB/s, 4 MiB window (beyond per-core L2)

| algorithm | 16 B | 64 B | 256 B | 1 KiB | 16 KiB | 1 MiB |
|---|---|---|---|---|---|---|
| XXH3-64 xxhash-rust | 1.39 | 3.53 | 6.31 | 12.9 | 32.6 | 31.0 |
| XXH3-64 twox-hash | 1.36 | 3.22 | 4.87 | 9.82 | 23.3 | 24.3 |
| XXH3-128 xxhash-rust | 0.984 | 2.43 | 4.25 | 10.1 | 27.3 | 27.1 |
| XXH3-128 twox-hash | 0.843 | 2.42 | 3.69 | 9.18 | 22.7 | 24.8 |
| XXH64 xxhash-rust | 0.881 | 1.91 | 3.37 | 6.29 | 9.98 | 10.2 |
| XXH64 twox-hash | 0.933 | 1.47 | 3.20 | 4.59 | 4.86 | 4.86 |
| BLAKE3 (1 thread) | 0.146 | 0.571 | 0.737 | 0.846 | 4.68 | 5.14 |
| SHA-256 (sha2) | 0.147 | 0.391 | 0.773 | 1.04 | 1.21 | 1.26 |
| SipHash-1-3-128 (siphasher) | 0.265 | 0.814 | 1.76 | 2.63 | 3.17 | 3.33 |

#### Part 2 — canonical encoding vs hashing, graph-node struct (6 fields; name 16–32 B; deps 4–12 × u32), ns per node

| pipeline | avg encoded bytes | encode ns | encode+hash ns | hash share |
|---|---|---|---|---|
| hand LE encoder → XXH3-64 | 86.0 | 18.9 | 25.8 | 27% |
| hand LE encoder → XXH3-128 | 86.0 | 18.8 | 29.1 | 35% |
| hand LE encoder → BLAKE3 | 86.0 | 19.3 | 170 | 89% |
| hand LE encoder → SHA-256 | 86.0 | 19.4 | 142 | 86% |
| streaming fields into Xxh3Default (no buffer) | 86.0 | — | 99.8 | — |
| postcard::to_slice (reused 512 B buf) → XXH3-64 | 73.3 | 97.7 | 108 | 10% |
| bincode 2 serde encode_into_slice (reused buf) → XXH3-64 | 94.0 | 17.0 | 24.6 | 31% |
| serde_json::to_writer (reused Vec, struct order) → XXH3-64 | 179 | 238 | 256 | 7% |
| #[derive(Hash)] → FxHasher (in-process only) | — | — | 7.06 | — |
| #[derive(Hash)] → foldhash::quality (in-process only) | — | — | 15.8 | — |
| postcard::to_allocvec → XXH3-64 | 73.3 | 228 | 231 | 1% |
| bincode 2 serde (fixint LE) → XXH3-64 | 94.0 | 215 | 220 | 3% |
| serde_json::to_vec (struct order) → XXH3-64 | 179 | 278 | 293 | 5% |
| serde_json sorted keys (via Value/BTreeMap) → XXH3-64 | 179 | 836 | 891 | 6% |
| serde_json sorted keys → SHA-256 | 179 | 833 | 1016 | 18% |

("hash share" = (encode+hash − encode)/(encode+hash); serde_json struct-order output is NOT canonical across struct edits; listed for cost only.)
