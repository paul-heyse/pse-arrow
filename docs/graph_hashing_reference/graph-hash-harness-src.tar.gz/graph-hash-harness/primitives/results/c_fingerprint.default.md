<!-- bin=c_fingerprint cpu="Intel(R) Xeon(R) Processor @ 2.10GHz" rustc="rustc 1.97.0 (2d8144b78 2026-07-07)" rustflags="" compile-time target features beyond SSE2: [] loadavg=0.66 0.47 0.87 reps=7 -->

#### Part 1a — one-shot latency, ns per call, cache-hot window max(16 KiB, 2×size)

| algorithm | 16 B | 64 B | 256 B | 1 KiB | 16 KiB | 1 MiB |
|---|---|---|---|---|---|---|
| XXH3-64 xxhash-rust | 4.31 | 6.59 | 22.4 | 57.9 | 816 | 54295 |
| XXH3-64 twox-hash | 4.55 | 6.77 | 21.3 | 41.0 | 459 | 35369 |
| XXH3-128 xxhash-rust | 6.63 | 9.56 | 26.9 | 62.4 | 820 | 53532 |
| XXH3-128 twox-hash | 7.03 | 9.99 | 29.4 | 49.2 | 460 | 34649 |
| XXH64 xxhash-rust | 6.99 | 17.0 | 37.5 | 105 | 1487 | 96997 |
| XXH64 twox-hash | 6.88 | 16.6 | 36.7 | 107 | 1481 | 94374 |
| BLAKE3 (1 thread) | 62.0 | 71.1 | 284 | 1071 | 3054 | 183216 |
| SHA-256 (sha2) | 76.9 | 115 | 255 | 817 | 12293 | 762155 |
| SipHash-1-3-128 (siphasher) | 22.6 | 33.7 | 88.2 | 307 | 4728 | 296778 |

#### Part 1b — throughput GiB/s, cache-hot window max(16 KiB, 2×size)

| algorithm | 16 B | 64 B | 256 B | 1 KiB | 16 KiB | 1 MiB |
|---|---|---|---|---|---|---|
| XXH3-64 xxhash-rust | 3.46 | 9.04 | 10.6 | 16.5 | 18.7 | 18.0 |
| XXH3-64 twox-hash | 3.28 | 8.80 | 11.2 | 23.3 | 33.2 | 27.6 |
| XXH3-128 xxhash-rust | 2.25 | 6.24 | 8.87 | 15.3 | 18.6 | 18.2 |
| XXH3-128 twox-hash | 2.12 | 5.97 | 8.11 | 19.4 | 33.2 | 28.2 |
| XXH64 xxhash-rust | 2.13 | 3.51 | 6.35 | 9.10 | 10.3 | 10.1 |
| XXH64 twox-hash | 2.17 | 3.60 | 6.49 | 8.91 | 10.3 | 10.3 |
| BLAKE3 (1 thread) | 0.240 | 0.838 | 0.839 | 0.890 | 5.00 | 5.33 |
| SHA-256 (sha2) | 0.194 | 0.520 | 0.935 | 1.17 | 1.24 | 1.28 |
| SipHash-1-3-128 (siphasher) | 0.661 | 1.77 | 2.70 | 3.10 | 3.23 | 3.29 |

#### Part 1a — one-shot latency, ns per call, 4 MiB window (beyond per-core L2)

| algorithm | 16 B | 64 B | 256 B | 1 KiB | 16 KiB | 1 MiB |
|---|---|---|---|---|---|---|
| XXH3-64 xxhash-rust | 10.6 | 15.8 | 56.6 | 115 | 940 | 58429 |
| XXH3-64 twox-hash | 10.7 | 16.1 | 48.9 | 91.6 | 717 | 42679 |
| XXH3-128 xxhash-rust | 15.0 | 23.6 | 61.3 | 121 | 955 | 57525 |
| XXH3-128 twox-hash | 15.7 | 22.9 | 66.7 | 105 | 744 | 39686 |
| XXH64 xxhash-rust | 14.7 | 31.5 | 69.2 | 141 | 1538 | 97039 |
| XXH64 twox-hash | 14.5 | 31.6 | 69.0 | 148 | 1521 | 95920 |
| BLAKE3 (1 thread) | 94.1 | 102 | 311 | 1087 | 3231 | 190237 |
| SHA-256 (sha2) | 90.7 | 147 | 297 | 855 | 12312 | 780158 |
| SipHash-1-3-128 (siphasher) | 56.7 | 69.9 | 138 | 356 | 4831 | 303543 |

#### Part 1b — throughput GiB/s, 4 MiB window (beyond per-core L2)

| algorithm | 16 B | 64 B | 256 B | 1 KiB | 16 KiB | 1 MiB |
|---|---|---|---|---|---|---|
| XXH3-64 xxhash-rust | 1.41 | 3.76 | 4.21 | 8.26 | 16.2 | 16.7 |
| XXH3-64 twox-hash | 1.40 | 3.71 | 4.87 | 10.4 | 21.3 | 22.9 |
| XXH3-128 xxhash-rust | 0.996 | 2.52 | 3.89 | 7.86 | 16.0 | 17.0 |
| XXH3-128 twox-hash | 0.952 | 2.60 | 3.57 | 9.05 | 20.5 | 24.6 |
| XXH64 xxhash-rust | 1.01 | 1.90 | 3.44 | 6.75 | 9.92 | 10.1 |
| XXH64 twox-hash | 1.03 | 1.89 | 3.45 | 6.42 | 10.0 | 10.2 |
| BLAKE3 (1 thread) | 0.158 | 0.583 | 0.766 | 0.877 | 4.72 | 5.13 |
| SHA-256 (sha2) | 0.164 | 0.406 | 0.804 | 1.12 | 1.24 | 1.25 |
| SipHash-1-3-128 (siphasher) | 0.263 | 0.853 | 1.73 | 2.68 | 3.16 | 3.22 |

#### Part 2 — canonical encoding vs hashing, graph-node struct (6 fields; name 16–32 B; deps 4–12 × u32), ns per node

| pipeline | avg encoded bytes | encode ns | encode+hash ns | hash share |
|---|---|---|---|---|
| hand LE encoder → XXH3-64 | 86.0 | 18.9 | 26.3 | 28% |
| hand LE encoder → XXH3-128 | 86.0 | 19.0 | 30.7 | 38% |
| hand LE encoder → BLAKE3 | 86.0 | 19.0 | 165 | 88% |
| hand LE encoder → SHA-256 | 86.0 | 19.6 | 146 | 87% |
| streaming fields into Xxh3Default (no buffer) | 86.0 | — | 103 | — |
| postcard::to_slice (reused 512 B buf) → XXH3-64 | 73.3 | 96.5 | 107 | 10% |
| bincode 2 serde encode_into_slice (reused buf) → XXH3-64 | 94.0 | 12.8 | 21.7 | 41% |
| serde_json::to_writer (reused Vec, struct order) → XXH3-64 | 179 | 246 | 246 | 0% |
| #[derive(Hash)] → FxHasher (in-process only) | — | — | 7.55 | — |
| #[derive(Hash)] → foldhash::quality (in-process only) | — | — | 16.1 | — |
| postcard::to_allocvec → XXH3-64 | 73.3 | 208 | 213 | 2% |
| bincode 2 serde (fixint LE) → XXH3-64 | 94.0 | 144 | 184 | 22% |
| serde_json::to_vec (struct order) → XXH3-64 | 179 | 296 | 301 | 2% |
| serde_json sorted keys (via Value/BTreeMap) → XXH3-64 | 179 | 825 | 857 | 4% |
| serde_json sorted keys → SHA-256 | 179 | 899 | 1018 | 12% |

("hash share" = (encode+hash − encode)/(encode+hash); serde_json struct-order output is NOT canonical across struct edits; listed for cost only.)
