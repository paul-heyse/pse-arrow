<!-- bin=h_key_patterns cpu="Intel(R) Xeon(R) Processor @ 2.10GHz" rustc="rustc 1.97.0 (2d8144b78 2026-07-07)" rustflags="" compile-time target features beyond SSE2: [] loadavg=1.68 1.37 1.06 reps=5 -->

#### HashSet<u64>, n = 1048576: insert / hit / miss ns per op

| key pattern | FxBuildHasher | foldhash::fast | std SipHash | nohash (identity) | Xxh3DefaultBuilder |
|---|---|---|---|---|---|
| sequential i | 41.0 / 13.1 / 4.30 | 41.6 / 13.9 / 5.73 | 61.4 / 54.6 / 22.1 | 77.6 / 8.08 / 2.36 | 73.8 / 44.1 / 17.9 |
| random 64-bit (fingerprints) | 43.0 / 13.1 / 5.51 | 45.1 / 13.5 / 5.73 | 61.0 / 51.7 / 21.0 | 43.5 / 12.3 / 5.20 | 69.6 / 43.3 / 18.1 |
| packed edge (u<<32) OR v, u,v<1024 | 44.8 / 13.6 / 5.84 | 44.3 / 14.5 / 5.95 | 61.7 / 52.1 / 21.2 | ABORTED: 6436 ns/insert, only 312320 keys in 2 s | 74.4 / 40.6 / 17.3 |
| i << 32 | 43.3 / 14.3 / 4.44 | 48.2 / 12.7 / 5.10 | 66.0 / 68.5 / 27.7 | ABORTED: 38909 ns/insert, only 52224 keys in 2 s | 83.7 / 41.2 / 17.3 |
| i << 40 | 89.7 / 22.8 / 38.9 | 39.9 / 16.2 / 5.34 | 66.4 / 55.7 / 21.9 | ABORTED: 27618 ns/insert, only 72704 keys in 2 s | 78.9 / 42.5 / 18.1 |
| i * 4096 (aligned offsets) | 43.0 / 16.1 / 4.40 | 44.2 / 14.3 / 5.76 | 69.4 / 54.2 / 23.6 | ABORTED: 5170 ns/insert, only 387072 keys in 2 s | 78.1 / 45.7 / 18.0 |
| type tag ((i%4)<<56) OR i/4 | 42.1 / 12.4 / 4.33 | 42.3 / 13.7 / 5.80 | 61.1 / 52.9 / 21.5 | ABORTED: 3325 ns/insert, only 604160 keys in 2 s | 67.2 / 39.1 / 16.9 |
