<!-- bin=b_bfs cpu="Intel(R) Xeon(R) Processor @ 2.10GHz" rustc="rustc 1.97.0 (2d8144b78 2026-07-07)" rustflags="" compile-time target features beyond SSE2: [] loadavg=0.66 0.70 0.79 reps=7 -->

Graph: N = 1048576 nodes, M = 8388608 directed edges (uniform random endpoints, SplitMix64 seed 42), BFS from node 0 over out-edges.
Reached 1048244 nodes (99.97%).

#### Part 1 — visited set (adjacency = hand CSR), N=1048576, M=8388608

| visited set | BFS ms | vs best | ns / edge scanned | visited-set MiB |
|---|---|---|---|---|
| Vec<bool> | 88.2 | 1.00× | 10.5 | 1.0 |
| fixedbitset::FixedBitSet | 92.3 | 1.05× | 11.0 | 0.1 |
| roaring::RoaringBitmap | 325 | 3.69× | 38.8 | 0.1 |
| epoch stamps Vec<u32> | 115 | 1.31× | 13.7 | 4.0 |
| HashSet<u32> std SipHash | 616 | 6.98× | 73.4 | 10.0 |
| HashSet<u32> foldhash::fast | 304 | 3.44× | 36.2 | 10.0 |
| HashSet<u32> foldhash::quality | 324 | 3.68× | 38.7 | 10.0 |
| HashSet<u32> FxBuildHasher | 273 | 3.09× | 32.5 | 10.0 |
| HashSet<u32> FxBuildHasher, with_capacity(N) | 284 | 3.22× | 33.9 | 10.0 |
| HashSet<u32> ahash | 333 | 3.78× | 39.7 | 10.0 |
| HashSet<u32> Xxh3DefaultBuilder | 568 | 6.45× | 67.8 | 10.0 |
| HashSet<u32> twox xxhash64::State | 378 | 4.29× | 45.1 | 10.0 |
| HashSet<u32> nohash (identity) | 271 | 3.07× | 32.3 | 10.0 |
| hashbrown::HashSet<u32> default (foldhash) | 294 | 3.33× | 35.0 | 10.0 |

#### Part 1b — visited-set reset cost, N=1048576

| reset | µs |
|---|---|
| Vec<bool>::fill(false) | 85.2 |
| FixedBitSet::clear() | 8.91 |
| epoch += 1 | 0.050 |
| HashSet::clear() (full set, keeps capacity) | 73.4 |

#### Part 2 — adjacency layout (visited = Vec<bool>), N=1048576, M=8388608, 3 reps

| adjacency | build ms | BFS ms | retained MiB | peak MiB during build | bytes/edge |
|---|---|---|---|---|---|
| hand CSR (offsets+targets, counting sort) | 128 | 101 | 36.0 | 40.0 | 4.50 |
| petgraph::csr::Csr (sort+dedup, from_sorted_edges) | 414 | 124 | 40.0 | 104.0 | 5.00 |
| petgraph::Graph (adjacency list, with_capacity) | 155 | 732 | 136.0 | 136.0 | 17.0 |
| HashMap<u32,Vec<u32>> FxBuildHasher | 800 | 230 | 109.7 | 114.0 | 13.7 |
| HashMap<u32,Vec<u32>> foldhash::fast | 885 | 241 | 109.7 | 114.0 | 13.7 |
| HashMap<u32,Vec<u32>> std SipHash | 1397 | 307 | 109.7 | 114.0 | 13.7 |
| Vec<Vec<u32>> (dense ids, no hashing) | 665 | 160 | 67.7 | 67.7 | 8.46 |

#### Part 2b — petgraph::visit::Bfs (library traversal, includes visit-map alloc)

| traversal | BFS ms |
|---|---|
| petgraph::visit::Bfs on Graph (FixedBitSet visit map) | 1082 |
| petgraph::visit::Bfs on csr::Csr (FixedBitSet visit map) | 137 |

#### Part 3 — graph keyed by sparse random u64 ids, N=1048576, M=8388608

| representation | build ms | BFS ms | retained MiB (graph + id map) |
|---|---|---|---|
| HashMap<u64,Vec<u64>> + HashSet<u64>, std SipHash | 1659 | 1015 | 153.4 |
| HashMap<u64,Vec<u64>> + HashSet<u64>, FxBuildHasher | 912 | 548 | 153.4 |
| HashMap<u64,Vec<u64>> + HashSet<u64>, foldhash::fast | 961 | 545 | 153.4 |
| HashMap<u64,Vec<u64>> + HashSet<u64>, nohash (ids are random) | 884 | 500 | 153.4 |
| relabel u64→u32 (HashMap<u64,u32,Fx>) + hand CSR + Vec<bool> | 515 | 92.6 | 70.0 |
