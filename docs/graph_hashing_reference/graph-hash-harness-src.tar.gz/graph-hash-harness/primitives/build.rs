use std::process::Command;
fn main() {
    let rustc = std::env::var("RUSTC").unwrap_or_else(|_| "rustc".into());
    let v = Command::new(rustc).arg("-V").output().map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string()).unwrap_or_default();
    println!("cargo:rustc-env=RUSTC_VERSION={v}");
    println!("cargo:rustc-env=BUILD_RUSTFLAGS={}", std::env::var("CARGO_ENCODED_RUSTFLAGS").unwrap_or_default().replace('\x1f', " "));
    println!("cargo:rerun-if-changed=build.rs");
}
