# Query

::: deltalake.QueryBuilder