# `buoyant_kernel_engine::parquet`

Full upstream contracts; raw type trees and source locators in [structured records](buoyant_kernel_engine.parquet.json).

<a id="op-2ff90c9ab5fbea67fca98f95"></a>
## parquet

`module` · `buoyant_kernel_engine::parquet` · buoyant_kernel_engine 1.0.0+58f07cd6

Access: **public**. Canonical source location is not automatically a valid import path.

```rust
mod parquet
```

[Exact source](https://github.com/buoyant-data/delta-kernel-rs/blob/8ba063f8f84fec222000f66d40d70911d7c79675//home/paul/.cargo/git/checkouts/delta-kernel-rs-ed98d9651ec5fb51/8ba063f/default-engine/src/parquet.rs#L1).

Source: `/home/paul/.cargo/git/checkouts/delta-kernel-rs-ed98d9651ec5fb51/8ba063f/default-engine/src/parquet.rs:1`. [Exact documentation build](https://github.com/delta-io/delta-rs/tree/58f07cd62bfbce3649a7e1c87c696288068ae184).

Default Parquet handler implementation
