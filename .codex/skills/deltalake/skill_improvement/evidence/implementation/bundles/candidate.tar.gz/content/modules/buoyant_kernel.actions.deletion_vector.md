# `buoyant_kernel::actions::deletion_vector`

Full upstream contracts; raw type trees and source locators in [structured records](buoyant_kernel.actions.deletion_vector.json).

<a id="op-af02747e8a40c54032c334c4"></a>
## deletion_vector

`module` · `buoyant_kernel::actions::deletion_vector` · buoyant_kernel 1.0.0+58f07cd6

Access: **public**. Canonical source location is not automatically a valid import path.

```rust
mod deletion_vector
```

[Exact source](https://github.com/buoyant-data/delta-kernel-rs/blob/8ba063f8f84fec222000f66d40d70911d7c79675//home/paul/.cargo/git/checkouts/delta-kernel-rs-ed98d9651ec5fb51/8ba063f/kernel/src/actions/deletion_vector.rs#L1).

Source: `/home/paul/.cargo/git/checkouts/delta-kernel-rs-ed98d9651ec5fb51/8ba063f/kernel/src/actions/deletion_vector.rs:1`. [Exact documentation build](https://github.com/delta-io/delta-rs/tree/58f07cd62bfbce3649a7e1c87c696288068ae184).

Code relating to parsing and using deletion vectors
