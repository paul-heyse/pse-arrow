# `buoyant_kernel::arrow_compat::arrow_compat_shims`

Full upstream contracts; raw type trees and source locators in [structured records](buoyant_kernel.arrow_compat.arrow_compat_shims.json).

<a id="op-99be354b7791cdc74e6d6788"></a>
## arrow_compat_shims

`module` · `buoyant_kernel::arrow_compat::arrow_compat_shims` · buoyant_kernel 1.0.0+58f07cd6

Access: **internal_module**. Canonical source location is not automatically a valid import path.

```rust
mod arrow_compat_shims
```

[Exact source](https://github.com/buoyant-data/delta-kernel-rs/blob/8ba063f8f84fec222000f66d40d70911d7c79675//home/paul/.cargo/git/checkouts/delta-kernel-rs-ed98d9651ec5fb51/8ba063f/kernel/src/arrow_compat.rs#L4).

Source: `/home/paul/.cargo/git/checkouts/delta-kernel-rs-ed98d9651ec5fb51/8ba063f/kernel/src/arrow_compat.rs:4`. [Exact documentation build](https://github.com/delta-io/delta-rs/tree/58f07cd62bfbce3649a7e1c87c696288068ae184).

No upstream documentation on this item; consult its owner/trait contract.
