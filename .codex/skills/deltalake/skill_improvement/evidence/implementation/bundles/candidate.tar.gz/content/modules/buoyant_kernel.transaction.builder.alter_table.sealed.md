# `buoyant_kernel::transaction::builder::alter_table::sealed`

Full upstream contracts; raw type trees and source locators in [structured records](buoyant_kernel.transaction.builder.alter_table.sealed.json).

<a id="op-560429ec4cec3bd74bc2d2e5"></a>
## sealed

`module` · `buoyant_kernel::transaction::builder::alter_table::sealed` · buoyant_kernel 1.0.0+58f07cd6

Access: **internal_module**. Canonical source location is not automatically a valid import path.

```rust
mod sealed
```

[Exact source](https://github.com/buoyant-data/delta-kernel-rs/blob/8ba063f8f84fec222000f66d40d70911d7c79675//home/paul/.cargo/git/checkouts/delta-kernel-rs-ed98d9651ec5fb51/8ba063f/kernel/src/transaction/builder/alter_table.rs#L61).

Source: `/home/paul/.cargo/git/checkouts/delta-kernel-rs-ed98d9651ec5fb51/8ba063f/kernel/src/transaction/builder/alter_table.rs:61`. [Exact documentation build](https://github.com/delta-io/delta-rs/tree/58f07cd62bfbce3649a7e1c87c696288068ae184).

No upstream documentation on this item; consult its owner/trait contract.
