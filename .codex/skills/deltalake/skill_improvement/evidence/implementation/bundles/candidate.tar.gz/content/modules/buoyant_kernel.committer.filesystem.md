# `buoyant_kernel::committer::filesystem`

Full upstream contracts; raw type trees and source locators in [structured records](buoyant_kernel.committer.filesystem.json).

<a id="op-89ee5941647a1d528bf18d69"></a>
## filesystem

`module` · `buoyant_kernel::committer::filesystem` · buoyant_kernel 1.0.0+58f07cd6

Access: **internal_module**. Canonical source location is not automatically a valid import path.

```rust
mod filesystem
```

[Exact source](https://github.com/buoyant-data/delta-kernel-rs/blob/8ba063f8f84fec222000f66d40d70911d7c79675//home/paul/.cargo/git/checkouts/delta-kernel-rs-ed98d9651ec5fb51/8ba063f/kernel/src/committer/filesystem.rs#L1).

Source: `/home/paul/.cargo/git/checkouts/delta-kernel-rs-ed98d9651ec5fb51/8ba063f/kernel/src/committer/filesystem.rs:1`. [Exact documentation build](https://github.com/delta-io/delta-rs/tree/58f07cd62bfbce3649a7e1c87c696288068ae184).

File system committer for non-catalog-managed tables.
