# `buoyant_kernel::scan::field_classifiers`

Full upstream contracts; raw type trees and source locators in [structured records](buoyant_kernel.scan.field_classifiers.json).

<a id="op-f18a9d93dc96d86b90a8d845"></a>
## field_classifiers

`module` · `buoyant_kernel::scan::field_classifiers` · buoyant_kernel 1.0.0+58f07cd6

Access: **internal_module**. Canonical source location is not automatically a valid import path.

```rust
mod field_classifiers
```

[Exact source](https://github.com/buoyant-data/delta-kernel-rs/blob/8ba063f8f84fec222000f66d40d70911d7c79675//home/paul/.cargo/git/checkouts/delta-kernel-rs-ed98d9651ec5fb51/8ba063f/kernel/src/scan/field_classifiers.rs#L1).

Source: `/home/paul/.cargo/git/checkouts/delta-kernel-rs-ed98d9651ec5fb51/8ba063f/kernel/src/scan/field_classifiers.rs:1`. [Exact documentation build](https://github.com/delta-io/delta-rs/tree/58f07cd62bfbce3649a7e1c87c696288068ae184).

Field classifier implementations for different scan types (regular and CDF scans)
