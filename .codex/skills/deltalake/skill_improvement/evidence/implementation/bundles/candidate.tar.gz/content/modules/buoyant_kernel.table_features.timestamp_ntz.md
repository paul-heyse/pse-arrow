# `buoyant_kernel::table_features::timestamp_ntz`

Full upstream contracts; raw type trees and source locators in [structured records](buoyant_kernel.table_features.timestamp_ntz.json).

<a id="op-d47920c05c254ccd2a87a621"></a>
## timestamp_ntz

`module` · `buoyant_kernel::table_features::timestamp_ntz` · buoyant_kernel 1.0.0+58f07cd6

Access: **internal_module**. Canonical source location is not automatically a valid import path.

```rust
mod timestamp_ntz
```

[Exact source](https://github.com/buoyant-data/delta-kernel-rs/blob/8ba063f8f84fec222000f66d40d70911d7c79675//home/paul/.cargo/git/checkouts/delta-kernel-rs-ed98d9651ec5fb51/8ba063f/kernel/src/table_features/timestamp_ntz.rs#L1).

Source: `/home/paul/.cargo/git/checkouts/delta-kernel-rs-ed98d9651ec5fb51/8ba063f/kernel/src/table_features/timestamp_ntz.rs:1`. [Exact documentation build](https://github.com/delta-io/delta-rs/tree/58f07cd62bfbce3649a7e1c87c696288068ae184).

Validation for TIMESTAMP_NTZ feature support
