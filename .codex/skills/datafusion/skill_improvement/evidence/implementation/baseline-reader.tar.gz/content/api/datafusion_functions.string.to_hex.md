# `datafusion_functions::string::to_hex`

Crate `datafusion-functions` · 1 public items · structured records in [`model/datafusion_functions.string.to_hex.json`](../model/datafusion_functions.string.to_hex.json)

## ToHexFunc

`struct` · `datafusion_functions::string::to_hex::ToHexFunc`

```rust
struct ToHexFunc
```

**Implements**: `datafusion_expr::udf::ScalarUDFImpl`

**Derives**: Debug, Default, Eq, Hash, PartialEq, StructuralPartialEq

**Methods** (1)

```rust
fn new() -> Self
```

**via `datafusion_expr::udf::ScalarUDFImpl`**

```rust
fn documentation(&self) -> Option<&Documentation>
fn invoke_with_args(&self, args: ScalarFunctionArgs) -> Result<ColumnarValue>
fn name(&self) -> &str
fn return_type(&self, _arg_types: &[DataType]) -> Result<DataType>
fn signature(&self) -> &Signature
```

---
