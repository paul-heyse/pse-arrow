# Follow execution and recorder lifetimes

The implementation groups active execution streams and holds recording state through stream ownership. Plan handles, stream handles and exported spans have distinct lifetimes.

Reviewed 2026-09-18. reviewed decision brief; runtime scope is limited to named tests.

## Alternatives

| Mechanism | Applicable condition | Distinction |
|---|---|---|
| consume to end | Complete stream work is needed | End of stream and destruction can release recording state. |
| early drop | Only partial results are consumed | Finalized telemetry may describe partial work. |
| retained plan | The plan is reused | Retaining a plan is distinct from retaining its active streams. |

## Contract

**Evidence boundary.** InstrumentedExec is internal; its source is evidence, not a constructible consumer API.
Claim `tracing.lifecycle.1`; source_observation; evidence: source.

**Ownership.** The retained implementation reserves an active recorder group before inner execute; errors release reservations. Stream completion/drop releases recording ownership.
Claim `tracing.lifecycle.2`; source_observation; evidence: source.

**Executed scope.** Two partitions containing three batches retain the execution span while streams live. Completion closes it while a plan clone still lives; displayed preview rows are capped across the group.
Claim `tracing.lifecycle.observed`; runtime_observation; evidence: consumer.

## Implementation

- Use public instrumentation macros in consumers.
- Record identities and lifecycle callbacks to distinguish independent executions and parents.

## Limits and unknowns

- Arbitrary custom ExecutionPlan implementations and cancellation timing remain workload-specific.

## Exact contracts

- [`datafusion_tracing::instrumented_exec::InstrumentedExec`](../operations/datafusion_tracing.instrumented_exec.InstrumentedExec.md#op-6b12316c8f26fe0ad5f029de) — `struct InstrumentedExec`

## Evidence

`upstream` refers to the exact contracts above, preserving source spans and raw types.
- [source](../../content/corpus/source/datafusion-tracing/instrumented_exec.rs): Retained exact-release source or documentation; local runtime assertions are linked separately.
  Tests: 
- [consumer](../../skill_improvement/evidence/implementation/probe-results.json): Two partitions containing three batches retain the execution span while streams live. Completion closes it while a plan clone still lives; displayed preview rows are capped across the group.
  Tests: partition_preview_cap_and_live_stream_lifetime, early_drop_partial_partition_and_repeated_execution, independent_execution_groups_do_not_mix_previews
- [fixture](../../build/fixtures/probe-crate/tests/contracts.rs): Public consumer implementation and discriminating assertions; captures and resolved profile accompany the receipt.
  Tests: 
