.. Copyright (c) 2016, Johan Mabille, Sylvain Corlay 

   Distributed under the terms of the BSD 3-Clause License.

   The full license is in the file LICENSE, distributed with this software.

Alignment Manipulation
======================

Aligned Memory Allocator
------------------------

.. doxygenclass:: xsimd::aligned_allocator
   :project: xsimd
   :members:

Alignment Checker
-----------------

.. doxygenfunction:: xsimd::is_aligned
   :project: xsimd
